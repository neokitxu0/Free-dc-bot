const Embed = require('../../utils/Embed');

module.exports = {
  name: 'addrole',
  description: 'Add a role to a member',
  usage: 'addrole <user> <role>',
  category: 'admin',
  userPermissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid member.')] });
    const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]) || message.guild.roles.cache.find(r => r.name.toLowerCase() === args.slice(1).join(' ').toLowerCase());
    if (!role) return message.reply({ embeds: [Embed.error('Invalid Role', 'Please mention a valid role.')] });
    if (role.position >= message.guild.members.me.roles.highest.position) return message.reply({ embeds: [Embed.error('Cannot Add', 'That role is higher than or equal to my highest role.')] });
    if (target.roles.cache.has(role.id)) return message.reply({ embeds: [Embed.warn('Already Has Role', `**${target.user.tag}** already has ${role}.`)] });
    await target.roles.add(role).catch(e => message.reply({ embeds: [Embed.error('Failed', e.message)] }));
    message.reply({ embeds: [Embed.success('Role Added', `${role} has been added to **${target.user.tag}**.`)] });
  }
};
