const Embed = require('../../utils/Embed');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'announce',
  description: 'Send an announcement to a channel',
  usage: 'announce <#channel> <message>',
  category: 'admin',
  userPermissions: ['ManageMessages'],
  botPermissions: ['SendMessages'],
  cooldown: 10,
  async execute(client, message, args) {
    const channel = message.mentions.channels.first();
    if (!channel) return message.reply({ embeds: [Embed.error('Missing Channel', 'Please mention a channel.')] });
    const text = args.slice(1).join(' ');
    if (!text) return message.reply({ embeds: [Embed.error('Missing Message', 'Please provide announcement text.')] });
    const embed = new EmbedBuilder()
      .setColor(client.config.embedColor || '#5865F2')
      .setTitle('📢 Announcement')
      .setDescription(text)
      .setFooter({ text: `Announced by ${message.author.tag}` })
      .setTimestamp();
    await channel.send({ embeds: [embed] });
    await message.delete().catch(() => {});
    message.channel.send({ embeds: [Embed.success('Announced', `Announcement sent to ${channel}.`)] }).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
  }
};
