const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'ban',
  description: 'Ban a member from the server',
  usage: 'ban <user> [days] [reason]',
  category: 'admin',
  userPermissions: ['BanMembers'],
  botPermissions: ['BanMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid member.')] });
    if (!target.bannable) return message.reply({ embeds: [Embed.error('Cannot Ban', 'I cannot ban this member.')] });
    if (target.id === message.author.id) return message.reply({ embeds: [Embed.error('Error', 'You cannot ban yourself.')] });

    let days = 0;
    let reason = 'No reason provided';
    const remaining = args.slice(1);
    if (remaining.length > 0 && !isNaN(remaining[0]) && Number(remaining[0]) >= 0) {
      days = Math.min(7, parseInt(remaining[0]));
      reason = remaining.slice(1).join(' ') || 'No reason provided';
    } else {
      reason = remaining.join(' ') || 'No reason provided';
    }

    try {
      await target.user.send({ embeds: [Embed.warn('Banned', `You have been banned from **${message.guild.name}**.\nReason: ${reason}`)] }).catch(() => {});
      await target.ban({ deleteMessageDays: days, reason: `${message.author.tag}: ${reason}` });

      const logs = DataManager.ensure('modlogs', `${message.guild.id}-${target.id}`, []);
      logs.push({ type: 'ban', mod: message.author.id, reason, time: Date.now() });
      DataManager.set('modlogs', `${message.guild.id}-${target.id}`, logs);

      message.reply({ embeds: [Embed.success('User Banned', `**${target.user.tag}** has been banned.\nReason: ${reason}\nDeleted messages: ${days} days`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Ban Failed', err.message)] });
    }
  }
};
