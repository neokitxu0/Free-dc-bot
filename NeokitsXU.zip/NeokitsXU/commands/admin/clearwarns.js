const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'clearwarns',
  aliases: ['clearwarnings'],
  description: 'Clear all warnings for a member',
  usage: 'clearwarns <user>',
  category: 'admin',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid member.')] });
    const key = `${message.guild.id}-${target.id}`;
    const warns = DataManager.get('warnings', key, []);
    if (!warns.length) return message.reply({ embeds: [Embed.warn('No Warnings', `**${target.user.tag}** has no warnings to clear.`)] });
    DataManager.set('warnings', key, []);
    message.reply({ embeds: [Embed.success('Warnings Cleared', `All **${warns.length}** warning(s) for **${target.user.tag}** have been cleared.`)] });
  }
};
