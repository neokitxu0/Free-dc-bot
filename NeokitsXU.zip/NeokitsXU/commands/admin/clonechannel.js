const Embed = require('../../utils/Embed');

module.exports = {
  name: 'clonechannel',
  description: 'Clone a channel',
  usage: 'clonechannel [#channel] [name]',
  category: 'admin',
  userPermissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  cooldown: 10,
  async execute(client, message, args) {
    const channel = message.mentions.channels.first() || message.channel;
    const name = args.filter(a => !a.startsWith('<')).join('-') || channel.name + '-clone';
    try {
      const cloned = await channel.clone({ name, reason: `Cloned by ${message.author.tag}` });
      message.reply({ embeds: [Embed.success('Channel Cloned', `Cloned ${channel} → ${cloned} (\`${cloned.id}\`)`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Clone Failed', err.message)] });
    }
  }
};
