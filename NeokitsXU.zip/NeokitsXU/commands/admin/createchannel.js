const Embed = require('../../utils/Embed');
const { ChannelType } = require('discord.js');

module.exports = {
  name: 'createchannel',
  aliases: ['cc'],
  description: 'Create a new channel',
  usage: 'createchannel <name> [text|voice|category] [#category]',
  category: 'admin',
  userPermissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  cooldown: 10,
  async execute(client, message, args) {
    const name = args[0];
    if (!name) return message.reply({ embeds: [Embed.error('Missing Name', 'Provide a channel name.')] });
    const typeArg = (args[1] || 'text').toLowerCase();
    const typeMap = { text: ChannelType.GuildText, voice: ChannelType.GuildVoice, category: ChannelType.GuildCategory };
    const type = typeMap[typeArg] || ChannelType.GuildText;
    const parent = message.mentions.channels.first()?.type === 4 ? message.mentions.channels.first().id : undefined;
    try {
      const channel = await message.guild.channels.create({ name, type, parent, reason: `Created by ${message.author.tag}` });
      message.reply({ embeds: [Embed.success('Channel Created', `${channel} (\`${channel.id}\`) has been created.`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Failed', err.message)] });
    }
  }
};
