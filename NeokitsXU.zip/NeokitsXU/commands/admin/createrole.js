const Embed = require('../../utils/Embed');

module.exports = {
  name: 'createrole',
  aliases: ['cr'],
  description: 'Create a new role',
  usage: 'createrole <name> [color] [hoist] [mentionable]',
  category: 'admin',
  userPermissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  cooldown: 10,
  async execute(client, message, args) {
    const name = args[0];
    if (!name) return message.reply({ embeds: [Embed.error('Missing Name', 'Provide a role name.')] });
    const color = args[1] && /^#?[0-9A-F]{6}$/i.test(args[1]) ? args[1] : null;
    const hoist = args[2] === 'true';
    const mentionable = args[3] === 'true';
    try {
      const role = await message.guild.roles.create({ name, color: color || null, hoist, mentionable, reason: `Created by ${message.author.tag}` });
      message.reply({ embeds: [Embed.success('Role Created', `${role} (\`${role.id}\`) created.\nColor: ${color || 'None'}\nHoisted: ${hoist}\nMentionable: ${mentionable}`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Failed', err.message)] });
    }
  }
};
