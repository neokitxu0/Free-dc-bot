const Embed = require('../../utils/Embed');

module.exports = {
  name: 'deletechannel',
  description: 'Delete a channel',
  usage: 'deletechannel [#channel] [reason]',
  category: 'admin',
  userPermissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  cooldown: 10,
  async execute(client, message, args) {
    const channel = message.mentions.channels.first() || message.channel;
    const reason = args.filter(a => !a.startsWith('<')).join(' ') || 'No reason provided';
    const name = channel.name;
    try {
      await channel.delete(`${message.author.tag}: ${reason}`);
      if (channel.id !== message.channel.id) message.reply({ embeds: [Embed.success('Channel Deleted', `**#${name}** has been deleted.\nReason: ${reason}`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Failed', err.message)] });
    }
  }
};
