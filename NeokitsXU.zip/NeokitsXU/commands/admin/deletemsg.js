const Embed = require('../../utils/Embed');

module.exports = {
  name: 'deletemsg',
  description: 'Delete a specific message by ID',
  usage: 'deletemsg <messageID> [#channel]',
  category: 'admin',
  userPermissions: ['ManageMessages'],
  botPermissions: ['ManageMessages'],
  cooldown: 5,
  async execute(client, message, args) {
    const msgId = args[0];
    if (!msgId) return message.reply({ embeds: [Embed.error('Missing ID', 'Provide a message ID.')] });
    const channel = message.mentions.channels.first() || message.channel;
    try {
      const msg = await channel.messages.fetch(msgId);
      await msg.delete();
      message.reply({ embeds: [Embed.success('Deleted', `Message \`${msgId}\` has been deleted.`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Failed', `Could not delete message: ${err.message}`)] });
    }
  }
};
