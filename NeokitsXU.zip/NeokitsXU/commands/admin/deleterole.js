const Embed = require('../../utils/Embed');

module.exports = {
  name: 'deleterole',
  aliases: ['dr'],
  description: 'Delete a role from the server',
  usage: 'deleterole <role> [reason]',
  category: 'admin',
  userPermissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  cooldown: 10,
  async execute(client, message, args) {
    const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]) || message.guild.roles.cache.find(r => r.name.toLowerCase() === args.join(' ').toLowerCase());
    if (!role) return message.reply({ embeds: [Embed.error('Invalid Role', 'Please mention a valid role.')] });
    if (role.managed) return message.reply({ embeds: [Embed.error('Cannot Delete', 'That role is managed by an integration.')] });
    if (role.position >= message.guild.members.me.roles.highest.position) return message.reply({ embeds: [Embed.error('Cannot Delete', 'That role is higher than my highest role.')] });
    const reason = args.filter(a => !a.startsWith('<') && !/^\d+$/.test(a)).join(' ') || 'No reason provided';
    const name = role.name;
    try {
      await role.delete(`${message.author.tag}: ${reason}`);
      message.reply({ embeds: [Embed.success('Role Deleted', `Role **${name}** has been deleted.\nReason: ${reason}`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Failed', err.message)] });
    }
  }
};
