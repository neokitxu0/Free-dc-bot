const Embed = require('../../utils/Embed');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'embed',
  description: 'Send a custom embed message',
  usage: 'embed <#channel> <title> | <description> | [color]',
  category: 'admin',
  userPermissions: ['ManageMessages'],
  botPermissions: ['SendMessages'],
  cooldown: 5,
  async execute(client, message, args) {
    const channel = message.mentions.channels.first() || message.channel;
    const text = message.mentions.channels.size ? args.slice(1).join(' ') : args.join(' ');
    if (!text) return message.reply({ embeds: [Embed.error('Usage', 'embed [#channel] <title> | <description> | [color]')] });
    const parts = text.split('|').map(p => p.trim());
    const title = parts[0] || 'Embed';
    const description = parts[1] || '';
    const color = parts[2] || client.config.embedColor || '#5865F2';
    const e = new EmbedBuilder().setColor(color).setTitle(title);
    if (description) e.setDescription(description);
    e.setFooter({ text: `Requested by ${message.author.tag}` }).setTimestamp();
    await channel.send({ embeds: [e] });
    if (channel.id !== message.channel.id) message.reply({ embeds: [Embed.success('Sent', `Embed sent to ${channel}.`)] });
    else message.delete().catch(() => {});
  }
};
