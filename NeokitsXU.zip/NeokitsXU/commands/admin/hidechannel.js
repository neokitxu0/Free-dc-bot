const Embed = require('../../utils/Embed');

module.exports = {
  name: 'hidechannel',
  description: 'Hide a channel from everyone',
  usage: 'hidechannel [channel] [reason]',
  category: 'admin',
  userPermissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  cooldown: 5,
  async execute(client, message, args) {
    const channel = message.mentions.channels.first() || message.channel;
    const reason = args.filter(a => !a.startsWith('<')).join(' ') || 'No reason provided';
    await channel.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: false }, { reason }).catch(e => message.reply({ embeds: [Embed.error('Failed', e.message)] }));
    message.reply({ embeds: [Embed.success('Channel Hidden', `${channel} is now hidden.\nReason: ${reason}`)] });
  }
};
