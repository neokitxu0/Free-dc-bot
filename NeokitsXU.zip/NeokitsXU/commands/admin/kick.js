const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'kick',
  description: 'Kick a member from the server',
  usage: 'kick <user> [reason]',
  category: 'admin',
  userPermissions: ['KickMembers'],
  botPermissions: ['KickMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid member.')] });
    if (!target.kickable) return message.reply({ embeds: [Embed.error('Cannot Kick', 'I cannot kick this member.')] });
    if (target.id === message.author.id) return message.reply({ embeds: [Embed.error('Error', 'You cannot kick yourself.')] });
    const reason = args.slice(1).join(' ') || 'No reason provided';
    try {
      await target.user.send({ embeds: [Embed.warn('Kicked', `You have been kicked from **${message.guild.name}**.\nReason: ${reason}`)] }).catch(() => {});
      await target.kick(`${message.author.tag}: ${reason}`);
      const logs = DataManager.ensure('modlogs', `${message.guild.id}-${target.id}`, []);
      logs.push({ type: 'kick', mod: message.author.id, reason, time: Date.now() });
      DataManager.set('modlogs', `${message.guild.id}-${target.id}`, logs);
      message.reply({ embeds: [Embed.success('User Kicked', `**${target.user.tag}** has been kicked.\nReason: ${reason}`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Kick Failed', err.message)] });
    }
  }
};
