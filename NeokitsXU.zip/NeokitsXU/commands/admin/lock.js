const Embed = require('../../utils/Embed');

module.exports = {
  name: 'lock',
  description: 'Lock a channel preventing members from sending messages',
  usage: 'lock [channel] [reason]',
  category: 'admin',
  userPermissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  cooldown: 5,
  async execute(client, message, args) {
    const channel = message.mentions.channels.first() || message.channel;
    const reason = args.filter(a => !a.startsWith('<')).join(' ') || 'No reason provided';
    try {
      await channel.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: false }, { reason: `${message.author.tag}: ${reason}` });
      channel.send({ embeds: [Embed.warn('Channel Locked', `🔒 This channel has been locked.\nReason: ${reason}`)] });
      if (channel.id !== message.channel.id) message.reply({ embeds: [Embed.success('Locked', `${channel} has been locked.`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Lock Failed', err.message)] });
    }
  }
};
