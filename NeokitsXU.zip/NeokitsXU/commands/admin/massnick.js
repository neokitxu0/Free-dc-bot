const Embed = require('../../utils/Embed');

module.exports = {
  name: 'massnick',
  description: 'Change all member nicknames to a new name',
  usage: 'massnick <nickname|reset>',
  category: 'admin',
  userPermissions: ['ManageNicknames'],
  botPermissions: ['ManageNicknames'],
  cooldown: 60,
  async execute(client, message, args) {
    const nick = args.join(' ') || null;
    if (!args.length) return message.reply({ embeds: [Embed.error('Usage', 'massnick <nickname> or massnick reset')] });
    const reset = nick?.toLowerCase() === 'reset';
    const members = await message.guild.members.fetch();
    let changed = 0;
    const msg = await message.reply({ embeds: [Embed.info('Processing', `Changing nicknames for ${members.size} members...`)] });
    for (const [, member] of members) {
      if (member.id === message.guild.ownerId) continue;
      if (!member.manageable) continue;
      await member.setNickname(reset ? null : nick).then(() => changed++).catch(() => {});
    }
    msg.edit({ embeds: [Embed.success('Mass Nick Complete', `Changed **${changed}** member nicknames to: **${reset ? 'reset' : nick}**`)] });
  }
};
