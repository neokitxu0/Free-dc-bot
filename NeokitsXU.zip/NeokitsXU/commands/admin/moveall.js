const Embed = require('../../utils/Embed');

module.exports = {
  name: 'moveall',
  description: 'Move all members from one voice channel to another',
  usage: 'moveall <from channel ID> <to channel ID>',
  category: 'admin',
  userPermissions: ['MoveMembers'],
  botPermissions: ['MoveMembers'],
  cooldown: 10,
  async execute(client, message, args) {
    const fromId = args[0];
    const toId = args[1];
    if (!fromId || !toId) return message.reply({ embeds: [Embed.error('Usage', 'moveall <from channelID> <to channelID>')] });
    const from = message.guild.channels.cache.get(fromId);
    const to = message.guild.channels.cache.get(toId);
    if (!from || from.type !== 2) return message.reply({ embeds: [Embed.error('Invalid', 'Source must be a voice channel.')] });
    if (!to || to.type !== 2) return message.reply({ embeds: [Embed.error('Invalid', 'Destination must be a voice channel.')] });
    const members = from.members;
    if (!members.size) return message.reply({ embeds: [Embed.warn('Empty Channel', 'No members in the source channel.')] });
    let moved = 0;
    for (const [, member] of members) {
      await member.voice.setChannel(to).then(() => moved++).catch(() => {});
    }
    message.reply({ embeds: [Embed.success('Moved Members', `Moved **${moved}** member(s) from **${from.name}** to **${to.name}**.`)] });
  }
};
