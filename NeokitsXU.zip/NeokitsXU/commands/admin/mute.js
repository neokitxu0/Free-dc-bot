const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');
const ms = require('ms');

module.exports = {
  name: 'mute',
  description: 'Timeout (mute) a member',
  usage: 'mute <user> <duration> [reason]',
  category: 'admin',
  userPermissions: ['ModerateMembers'],
  botPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid member.')] });
    if (!target.moderatable) return message.reply({ embeds: [Embed.error('Cannot Mute', 'I cannot mute this member.')] });
    const duration = args[1];
    if (!duration) return message.reply({ embeds: [Embed.error('Missing Duration', 'Please provide a duration (e.g. 10m, 1h).')] });
    const dur = ms(duration);
    if (!dur || dur > 2419200000) return message.reply({ embeds: [Embed.error('Invalid Duration', 'Duration must be between 1s and 28 days.')] });
    const reason = args.slice(2).join(' ') || 'No reason provided';
    try {
      await target.timeout(dur, `${message.author.tag}: ${reason}`);
      const logs = DataManager.ensure('modlogs', `${message.guild.id}-${target.id}`, []);
      logs.push({ type: 'mute', mod: message.author.id, reason, duration, time: Date.now() });
      DataManager.set('modlogs', `${message.guild.id}-${target.id}`, logs);
      message.reply({ embeds: [Embed.success('Member Muted', `**${target.user.tag}** has been muted for **${duration}**.\nReason: ${reason}`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Mute Failed', err.message)] });
    }
  }
};
