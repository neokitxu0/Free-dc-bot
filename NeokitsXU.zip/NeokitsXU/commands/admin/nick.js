const Embed = require('../../utils/Embed');

module.exports = {
  name: 'nick',
  aliases: ['nickname'],
  description: 'Change a member\'s nickname',
  usage: 'nick <user> [nickname]',
  category: 'admin',
  userPermissions: ['ManageNicknames'],
  botPermissions: ['ManageNicknames'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid member.')] });
    if (!target.manageable) return message.reply({ embeds: [Embed.error('Cannot Change', 'I cannot change this member\'s nickname.')] });
    const nickname = args.slice(1).join(' ') || null;
    const old = target.nickname || target.user.username;
    await target.setNickname(nickname, `Changed by ${message.author.tag}`).catch(e => message.reply({ embeds: [Embed.error('Failed', e.message)] }));
    message.reply({ embeds: [Embed.success('Nickname Changed', `**${target.user.tag}**\nOld: \`${old}\`\nNew: \`${nickname || target.user.username}\``)] });
  }
};
