const Embed = require('../../utils/Embed');

module.exports = {
  name: 'nuke',
  description: 'Clone a channel and delete the original, clearing all messages',
  usage: 'nuke [reason]',
  category: 'admin',
  userPermissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  cooldown: 10,
  async execute(client, message, args) {
    const reason = args.join(' ') || 'No reason provided';
    try {
      const position = message.channel.position;
      const newChannel = await message.channel.clone({ reason: `Nuke by ${message.author.tag}: ${reason}` });
      await newChannel.setPosition(position);
      await message.channel.delete(`Nuke by ${message.author.tag}`);
      newChannel.send({ embeds: [Embed.success('Channel Nuked', `💣 Channel nuked by **${message.author.tag}**.\nReason: ${reason}`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Nuke Failed', err.message)] });
    }
  }
};
