const Embed = require('../../utils/Embed');

module.exports = {
  name: 'purge',
  aliases: ['clear', 'prune'],
  description: 'Bulk delete messages from a channel',
  usage: 'purge <amount> [user]',
  category: 'admin',
  userPermissions: ['ManageMessages'],
  botPermissions: ['ManageMessages'],
  cooldown: 5,
  async execute(client, message, args) {
    const amount = parseInt(args[0]);
    if (isNaN(amount) || amount < 1 || amount > 100) return message.reply({ embeds: [Embed.error('Invalid Amount', 'Please provide a number between 1 and 100.')] });
    const target = message.mentions.members.first();
    let messages = await message.channel.messages.fetch({ limit: 100 });
    if (target) messages = messages.filter(m => m.author.id === target.id);
    const toDelete = [...messages.values()].slice(0, amount);
    const twoWeeksAgo = Date.now() - 1209600000;
    const validMessages = toDelete.filter(m => m.createdTimestamp > twoWeeksAgo);
    if (!validMessages.length) return message.reply({ embeds: [Embed.error('No Messages', 'No eligible messages to delete (messages must be under 14 days old).')] });
    try {
      const deleted = await message.channel.bulkDelete(validMessages, true);
      await message.delete().catch(() => {});
      const reply = await message.channel.send({ embeds: [Embed.success('Messages Purged', `Deleted **${deleted.size}** message(s)${target ? ` from **${target.user.tag}**` : ''}.`)] });
      setTimeout(() => reply.delete().catch(() => {}), 5000);
    } catch (err) {
      message.reply({ embeds: [Embed.error('Purge Failed', err.message)] });
    }
  }
};
