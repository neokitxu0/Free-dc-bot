const Embed = require('../../utils/Embed');

module.exports = {
  name: 'role',
  description: 'Toggle a role on a member (add or remove)',
  usage: 'role <user> <role>',
  category: 'admin',
  userPermissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid member.')] });
    const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]) || message.guild.roles.cache.find(r => r.name.toLowerCase() === args.slice(1).join(' ').toLowerCase());
    if (!role) return message.reply({ embeds: [Embed.error('Invalid Role', 'Please provide a valid role.')] });
    if (role.position >= message.guild.members.me.roles.highest.position) return message.reply({ embeds: [Embed.error('Cannot Modify', 'That role is equal to or higher than my highest role.')] });
    const hasRole = target.roles.cache.has(role.id);
    if (hasRole) { await target.roles.remove(role); message.reply({ embeds: [Embed.success('Role Removed', `Removed ${role} from **${target.user.tag}**.`)] }); }
    else { await target.roles.add(role); message.reply({ embeds: [Embed.success('Role Added', `Added ${role} to **${target.user.tag}**.`)] }); }
  }
};
