const Embed = require('../../utils/Embed');

module.exports = {
  name: 'say',
  description: 'Make the bot say something in a channel',
  usage: 'say [#channel] <message>',
  category: 'admin',
  userPermissions: ['ManageMessages'],
  botPermissions: ['SendMessages'],
  cooldown: 5,
  async execute(client, message, args) {
    const channel = message.mentions.channels.first() || message.channel;
    const text = message.mentions.channels.size ? args.slice(1).join(' ') : args.join(' ');
    if (!text) return message.reply({ embeds: [Embed.error('Missing Text', 'Provide text to say.')] });
    await channel.send(text);
    await message.delete().catch(() => {});
  }
};
