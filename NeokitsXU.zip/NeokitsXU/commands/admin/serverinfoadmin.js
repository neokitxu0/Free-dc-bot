const Embed = require('../../utils/Embed');

module.exports = {
  name: 'serverinfoadmin',
  aliases: ['siadmin'],
  description: 'Detailed server information for admins',
  usage: 'serverinfoadmin',
  category: 'admin',
  userPermissions: ['Administrator'],
  cooldown: 10,
  async execute(client, message) {
    const g = message.guild;
    await g.fetch();
    const bans = await g.bans.fetch().catch(() => null);
    const invites = await g.invites.fetch().catch(() => null);
    const webhooks = await g.fetchWebhooks().catch(() => null);
    const e = Embed.custom({
      title: `⚙️ Admin Info — ${g.name}`,
      thumbnail: g.iconURL({ dynamic: true }),
      fields: [
        { name: 'ID', value: g.id, inline: true },
        { name: 'Owner', value: `<@${g.ownerId}>`, inline: true },
        { name: 'Created', value: `<t:${Math.floor(g.createdTimestamp / 1000)}:R>`, inline: true },
        { name: 'Members', value: `Total: ${g.memberCount}\nBots: ${g.members.cache.filter(m => m.user.bot).size}`, inline: true },
        { name: 'Channels', value: `Text: ${g.channels.cache.filter(c => c.type === 0).size}\nVoice: ${g.channels.cache.filter(c => c.type === 2).size}`, inline: true },
        { name: 'Roles', value: `${g.roles.cache.size}`, inline: true },
        { name: 'Bans', value: `${bans?.size ?? 'N/A'}`, inline: true },
        { name: 'Invites', value: `${invites?.size ?? 'N/A'}`, inline: true },
        { name: 'Webhooks', value: `${webhooks?.size ?? 'N/A'}`, inline: true },
        { name: 'Boost Tier', value: `Level ${g.premiumTier} (${g.premiumSubscriptionCount} boosts)`, inline: true },
        { name: 'Verification', value: g.verificationLevel.toString(), inline: true },
        { name: 'MFA Level', value: g.mfaLevel.toString(), inline: true },
      ]
    });
    message.reply({ embeds: [e] });
  }
};
