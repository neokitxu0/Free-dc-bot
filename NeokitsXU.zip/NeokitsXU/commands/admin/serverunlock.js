const Embed = require('../../utils/Embed');

module.exports = {
  name: 'serverunlock',
  description: 'Unlock all channels in the server',
  usage: 'serverunlock [reason]',
  category: 'admin',
  userPermissions: ['Administrator'],
  botPermissions: ['ManageChannels'],
  cooldown: 30,
  async execute(client, message, args) {
    const reason = args.join(' ') || 'Server unlockdown';
    const channels = message.guild.channels.cache.filter(c => c.type === 0);
    let count = 0;
    for (const [, ch] of channels) {
      try {
        await ch.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: null }, { reason });
        count++;
      } catch {}
    }
    message.reply({ embeds: [Embed.success('Server Unlocked', `🔓 Unlocked **${count}** channels.\nReason: ${reason}`)] });
  }
};
