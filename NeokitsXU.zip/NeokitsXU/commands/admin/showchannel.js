const Embed = require('../../utils/Embed');

module.exports = {
  name: 'showchannel',
  description: 'Make a hidden channel visible again',
  usage: 'showchannel [channel] [reason]',
  category: 'admin',
  userPermissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  cooldown: 5,
  async execute(client, message, args) {
    const channel = message.mentions.channels.first() || message.channel;
    const reason = args.filter(a => !a.startsWith('<')).join(' ') || 'No reason provided';
    await channel.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: null }, { reason }).catch(e => message.reply({ embeds: [Embed.error('Failed', e.message)] }));
    message.reply({ embeds: [Embed.success('Channel Shown', `${channel} is now visible.\nReason: ${reason}`)] });
  }
};
