const Embed = require('../../utils/Embed');

module.exports = {
  name: 'slowmode',
  description: 'Set slowmode for a channel',
  usage: 'slowmode <seconds|off> [channel]',
  category: 'admin',
  userPermissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  cooldown: 5,
  async execute(client, message, args) {
    const channel = message.mentions.channels.first() || message.channel;
    const val = args[0];
    if (!val) return message.reply({ embeds: [Embed.error('Missing Args', 'Provide seconds (0-21600) or `off`.')] });
    const seconds = val === 'off' ? 0 : parseInt(val);
    if (isNaN(seconds) || seconds < 0 || seconds > 21600) return message.reply({ embeds: [Embed.error('Invalid', 'Slowmode must be between 0 and 21600 seconds.')] });
    await channel.setRateLimitPerUser(seconds).catch(e => message.reply({ embeds: [Embed.error('Failed', e.message)] }));
    message.reply({ embeds: [Embed.success('Slowmode Set', seconds === 0 ? `${channel} slowmode disabled.` : `${channel} slowmode set to **${seconds}s**.`)] });
  }
};
