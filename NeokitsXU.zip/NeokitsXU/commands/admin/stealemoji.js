const Embed = require('../../utils/Embed');

module.exports = {
  name: 'stealemoji',
  aliases: ['steal'],
  description: 'Add an emoji from another server to this server',
  usage: 'stealemoji <emoji> [name]',
  category: 'admin',
  userPermissions: ['ManageEmojisAndStickers'],
  botPermissions: ['ManageEmojisAndStickers'],
  cooldown: 10,
  async execute(client, message, args) {
    const emojiArg = args[0];
    if (!emojiArg) return message.reply({ embeds: [Embed.error('Missing Args', 'Provide an emoji to steal.')] });
    const match = emojiArg.match(/<a?:(\w+):(\d+)>/);
    if (!match) return message.reply({ embeds: [Embed.error('Invalid Emoji', 'Please provide a valid custom emoji.')] });
    const animated = emojiArg.startsWith('<a:');
    const emojiName = args[1] || match[1];
    const emojiId = match[2];
    const url = `https://cdn.discordapp.com/emojis/${emojiId}.${animated ? 'gif' : 'png'}`;
    try {
      const emoji = await message.guild.emojis.create({ attachment: url, name: emojiName });
      message.reply({ embeds: [Embed.success('Emoji Stolen', `Added emoji ${emoji} as \`:${emoji.name}:\``)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Failed', err.message)] });
    }
  }
};
