const Embed = require('../../utils/Embed');
const ms = require('ms');

module.exports = {
  name: 'timeout',
  aliases: ['to'],
  description: 'Timeout a member for a specified duration',
  usage: 'timeout <user> <duration> [reason]',
  category: 'admin',
  userPermissions: ['ModerateMembers'],
  botPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid member.')] });
    if (!target.moderatable) return message.reply({ embeds: [Embed.error('Cannot Timeout', 'I cannot timeout this member.')] });
    const duration = args[1];
    if (!duration) return message.reply({ embeds: [Embed.error('Missing Duration', 'Provide a duration, e.g. 10m, 1h, 1d.')] });
    const dur = ms(duration);
    if (!dur || dur > 2419200000) return message.reply({ embeds: [Embed.error('Invalid Duration', 'Max duration is 28 days.')] });
    const reason = args.slice(2).join(' ') || 'No reason provided';
    await target.timeout(dur, reason).catch(e => message.reply({ embeds: [Embed.error('Failed', e.message)] }));
    message.reply({ embeds: [Embed.success('Timeout Applied', `**${target.user.tag}** timed out for **${duration}**.\nReason: ${reason}`)] });
  }
};
