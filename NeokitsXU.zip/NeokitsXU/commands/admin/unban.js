const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'unban',
  description: 'Unban a user from the server',
  usage: 'unban <userID> [reason]',
  category: 'admin',
  userPermissions: ['BanMembers'],
  botPermissions: ['BanMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const userId = args[0];
    if (!userId) return message.reply({ embeds: [Embed.error('Missing Args', 'Provide a user ID to unban.')] });
    const reason = args.slice(1).join(' ') || 'No reason provided';
    try {
      const ban = await message.guild.bans.fetch(userId).catch(() => null);
      if (!ban) return message.reply({ embeds: [Embed.error('Not Banned', 'That user is not banned.')] });
      await message.guild.members.unban(userId, `${message.author.tag}: ${reason}`);
      const logs = DataManager.ensure('modlogs', `${message.guild.id}-${userId}`, []);
      logs.push({ type: 'unban', mod: message.author.id, reason, time: Date.now() });
      DataManager.set('modlogs', `${message.guild.id}-${userId}`, logs);
      message.reply({ embeds: [Embed.success('User Unbanned', `**${ban.user.tag}** has been unbanned.\nReason: ${reason}`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Unban Failed', err.message)] });
    }
  }
};
