const Embed = require('../../utils/Embed');

module.exports = {
  name: 'unlock',
  description: 'Unlock a previously locked channel',
  usage: 'unlock [channel] [reason]',
  category: 'admin',
  userPermissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  cooldown: 5,
  async execute(client, message, args) {
    const channel = message.mentions.channels.first() || message.channel;
    const reason = args.filter(a => !a.startsWith('<')).join(' ') || 'No reason provided';
    try {
      await channel.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: null }, { reason: `${message.author.tag}: ${reason}` });
      channel.send({ embeds: [Embed.success('Channel Unlocked', `🔓 This channel has been unlocked.\nReason: ${reason}`)] });
      if (channel.id !== message.channel.id) message.reply({ embeds: [Embed.success('Unlocked', `${channel} has been unlocked.`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Unlock Failed', err.message)] });
    }
  }
};
