const Embed = require('../../utils/Embed');

module.exports = {
  name: 'unmute',
  description: 'Remove timeout from a member',
  usage: 'unmute <user> [reason]',
  category: 'admin',
  userPermissions: ['ModerateMembers'],
  botPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid member.')] });
    if (!target.isCommunicationDisabled()) return message.reply({ embeds: [Embed.warn('Not Muted', 'That member is not currently muted.')] });
    const reason = args.slice(1).join(' ') || 'No reason provided';
    try {
      await target.timeout(null, `${message.author.tag}: ${reason}`);
      message.reply({ embeds: [Embed.success('Member Unmuted', `**${target.user.tag}** has been unmuted.\nReason: ${reason}`)] });
    } catch (err) {
      message.reply({ embeds: [Embed.error('Unmute Failed', err.message)] });
    }
  }
};
