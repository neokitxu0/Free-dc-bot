const Embed = require('../../utils/Embed');

module.exports = {
  name: 'untimeout',
  aliases: ['uto'],
  description: 'Remove timeout from a member',
  usage: 'untimeout <user> [reason]',
  category: 'admin',
  userPermissions: ['ModerateMembers'],
  botPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid member.')] });
    if (!target.isCommunicationDisabled()) return message.reply({ embeds: [Embed.warn('Not Timed Out', 'That member has no active timeout.')] });
    const reason = args.slice(1).join(' ') || 'No reason provided';
    await target.timeout(null, reason).catch(e => message.reply({ embeds: [Embed.error('Failed', e.message)] }));
    message.reply({ embeds: [Embed.success('Timeout Removed', `**${target.user.tag}**'s timeout has been removed.\nReason: ${reason}`)] });
  }
};
