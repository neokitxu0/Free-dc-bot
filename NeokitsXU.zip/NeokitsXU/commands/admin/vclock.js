const Embed = require('../../utils/Embed');

module.exports = {
  name: 'vclock',
  description: 'Lock a voice channel by setting user limit to 1',
  usage: 'vclock [channelID]',
  category: 'admin',
  userPermissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  cooldown: 5,
  async execute(client, message, args) {
    const channel = message.guild.channels.cache.get(args[0]) || message.member.voice.channel;
    if (!channel || channel.type !== 2) return message.reply({ embeds: [Embed.error('Invalid', 'Join a voice channel or provide a voice channel ID.')] });
    await channel.setUserLimit(1).catch(e => message.reply({ embeds: [Embed.error('Failed', e.message)] }));
    message.reply({ embeds: [Embed.success('VC Locked', `**${channel.name}** has been locked (user limit: 1).`)] });
  }
};
