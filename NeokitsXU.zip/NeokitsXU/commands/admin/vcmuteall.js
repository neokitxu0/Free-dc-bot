const Embed = require('../../utils/Embed');

module.exports = {
  name: 'vcmuteall',
  description: 'Server-mute all members in a voice channel',
  usage: 'vcmuteall <channelID>',
  category: 'admin',
  userPermissions: ['MuteMembers'],
  botPermissions: ['MuteMembers'],
  cooldown: 10,
  async execute(client, message, args) {
    const channel = message.guild.channels.cache.get(args[0]) || message.member.voice.channel;
    if (!channel || channel.type !== 2) return message.reply({ embeds: [Embed.error('Invalid', 'Please provide a valid voice channel ID or join one.')] });
    let muted = 0;
    for (const [, member] of channel.members) {
      await member.voice.setMute(true).then(() => muted++).catch(() => {});
    }
    message.reply({ embeds: [Embed.success('VC Muted All', `Server-muted **${muted}** member(s) in **${channel.name}**.`)] });
  }
};
