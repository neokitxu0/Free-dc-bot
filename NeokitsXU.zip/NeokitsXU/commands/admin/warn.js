const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'warn',
  description: 'Warn a member',
  usage: 'warn <user> [reason]',
  category: 'admin',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid member.')] });
    if (target.id === message.author.id) return message.reply({ embeds: [Embed.error('Error', 'You cannot warn yourself.')] });
    const reason = args.slice(1).join(' ') || 'No reason provided';
    const key = `${message.guild.id}-${target.id}`;
    const warns = DataManager.ensure('warnings', key, []);
    warns.push({ id: warns.length + 1, mod: message.author.id, reason, time: Date.now() });
    DataManager.set('warnings', key, warns);
    await target.user.send({ embeds: [Embed.warn('Warning Received', `You have been warned in **${message.guild.name}**.\nReason: ${reason}\nTotal warnings: ${warns.length}`)] }).catch(() => {});
    message.reply({ embeds: [Embed.success('Member Warned', `**${target.user.tag}** has been warned. (Total: **${warns.length}**)\nReason: ${reason}`)] });
  }
};
