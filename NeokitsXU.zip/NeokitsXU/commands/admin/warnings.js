const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'warnings',
  aliases: ['warns'],
  description: 'View warnings for a member',
  usage: 'warnings <user>',
  category: 'admin',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    const key = `${message.guild.id}-${target.id}`;
    const warns = DataManager.get('warnings', key, []);
    if (!warns.length) return message.reply({ embeds: [Embed.info('No Warnings', `**${target.user.tag}** has no warnings.`)] });
    const fields = warns.slice(-10).map(w => ({
      name: `Warning #${w.id}`,
      value: `Reason: ${w.reason}\nMod: <@${w.mod}>\nDate: <t:${Math.floor(w.time / 1000)}:R>`,
      inline: false
    }));
    message.reply({ embeds: [Embed.custom({ title: `Warnings — ${target.user.tag}`, description: `Total: **${warns.length}**`, fields, color: '#FEE75C' })] });
  }
};
