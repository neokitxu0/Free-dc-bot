const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

module.exports = {
  name: 'balance',
  aliases: ['bal', 'coins', 'wallet'],
  description: 'Check your or someone else\'s balance',
  usage: 'balance [@user]',
  category: 'economy',
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.users.first() || message.author;
    const eco = EconomyManager.getUser(target.id, message.guild.id);
    message.reply({ embeds: [Embed.custom({
      title: `💰 Balance — ${target.username}`,
      fields: [
        { name: '💵 Wallet', value: `${eco.balance || 0} coins`, inline: true },
        { name: '🏦 Bank', value: `${eco.bank || 0} coins`, inline: true },
        { name: '💎 Total', value: `${(eco.balance || 0) + (eco.bank || 0)} coins`, inline: true }
      ],
      thumbnail: target.displayAvatarURL({ dynamic: true })
    })] });
  }
};
