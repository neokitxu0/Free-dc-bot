const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

module.exports = {
  name: 'bank',
  description: 'View your bank account details',
  usage: 'bank [@user]',
  category: 'economy',
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.users.first() || message.author;
    const eco = EconomyManager.getUser(target.id, message.guild.id);
    const total = (eco.balance || 0) + (eco.bank || 0);
    message.reply({ embeds: [Embed.custom({
      title: `🏦 Bank — ${target.username}`,
      fields: [
        { name: '💵 Wallet', value: `${eco.balance || 0} coins`, inline: true },
        { name: '🏦 Bank Balance', value: `${eco.bank || 0} coins`, inline: true },
        { name: '💎 Total Net Worth', value: `${total} coins`, inline: false },
        { name: '✨ Prestige', value: `${eco.prestige || 0}`, inline: true },
        { name: '🔥 Daily Streak', value: `${eco.dailyStreak || 0} days`, inline: true },
      ]
    })] });
  }
};
