const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

const responses = [
  { text: "Here, take some change.", success: true },
  { text: "You remind me of myself 10 years ago. Take this.", success: true },
  { text: "Get a job!", success: false },
  { text: "Absolutely not.", success: false },
  { text: "Fine, just this once.", success: true },
  { text: "I don't have anything for you.", success: false },
];

module.exports = {
  name: 'beg',
  description: 'Beg for coins',
  usage: 'beg',
  category: 'economy',
  cooldown: 0,
  async execute(client, message) {
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    const now = Date.now();
    const cooldown = 60000;
    if (eco.lastBeg && (now - eco.lastBeg) < cooldown) {
      const remaining = Math.ceil((cooldown - (now - eco.lastBeg)) / 1000);
      return message.reply({ embeds: [Embed.warn('Too Soon', `You can beg again in **${remaining}s**.`)] });
    }
    const resp = responses[Math.floor(Math.random() * responses.length)];
    eco.lastBeg = now;
    if (resp.success) {
      const amount = 10 + Math.floor(Math.random() * 90);
      eco.balance = (eco.balance || 0) + amount;
      EconomyManager.setUser(message.author.id, message.guild.id, eco);
      return message.reply({ embeds: [Embed.success('Begging...', `"${resp.text}"\nYou received **${amount}** coins!`)] });
    }
    EconomyManager.setUser(message.author.id, message.guild.id, eco);
    message.reply({ embeds: [Embed.warn('Begging...', `"${resp.text}"\nYou received nothing.`)] });
  }
};
