const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const suits = ['♠', '♥', '♦', '♣'];
const ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

function drawCard() {
  return { rank: ranks[Math.floor(Math.random() * ranks.length)], suit: suits[Math.floor(Math.random() * suits.length)] };
}

function handValue(hand) {
  let total = 0, aces = 0;
  for (const card of hand) {
    const v = ['J','Q','K'].includes(card.rank) ? 10 : card.rank === 'A' ? 11 : parseInt(card.rank);
    total += v;
    if (card.rank === 'A') aces++;
  }
  while (total > 21 && aces > 0) { total -= 10; aces--; }
  return total;
}

function handStr(hand) { return hand.map(c => `${c.rank}${c.suit}`).join(' '); }

module.exports = {
  name: 'blackjack',
  aliases: ['bj'],
  description: 'Play blackjack',
  usage: 'blackjack <bet>',
  category: 'economy',
  cooldown: 10,
  async execute(client, message, args) {
    const bet = parseInt(args[0]);
    if (!bet || bet <= 0) return message.reply({ embeds: [Embed.error('Invalid Bet', 'Provide a valid bet amount.')] });
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    if ((eco.balance || 0) < bet) return message.reply({ embeds: [Embed.error('Insufficient Funds', `You only have **${eco.balance || 0}** coins.`)] });
    eco.balance -= bet;
    const playerHand = [drawCard(), drawCard()];
    const dealerHand = [drawCard(), drawCard()];
    const showEmbed = (status, extra = '') => Embed.custom({
      title: '🃏 Blackjack',
      fields: [
        { name: `Your Hand (${handValue(playerHand)})`, value: handStr(playerHand), inline: true },
        { name: `Dealer's Hand`, value: `${handStr([dealerHand[0]])} ??`, inline: true }
      ],
      description: extra,
      color: status === 'playing' ? '#5865F2' : status === 'win' ? '#57F287' : '#ED4245'
    });
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('bj_hit').setLabel('Hit').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('bj_stand').setLabel('Stand').setStyle(ButtonStyle.Secondary)
    );
    if (handValue(playerHand) === 21) {
      const winnings = Math.floor(bet * 2.5);
      eco.balance += winnings;
      EconomyManager.setUser(message.author.id, message.guild.id, eco);
      return message.reply({ embeds: [Embed.custom({ title: '🃏 Blackjack!', description: `**Blackjack!** You win **${winnings}** coins!\nBalance: **${eco.balance}**`, color: '#FFD700' })] });
    }
    const m = await message.reply({ embeds: [showEmbed('playing')], components: [row] });
    const filter = i => i.user.id === message.author.id;
    const collector = m.createMessageComponentCollector({ filter, time: 30000 });
    collector.on('collect', async i => {
      if (i.customId === 'bj_hit') {
        playerHand.push(drawCard());
        const pv = handValue(playerHand);
        if (pv > 21) {
          EconomyManager.setUser(message.author.id, message.guild.id, eco);
          await i.update({ embeds: [Embed.custom({ title: '🃏 Bust!', description: `Your hand: **${handStr(playerHand)}** (${pv})\nYou busted! Lost **${bet}** coins.\nBalance: **${eco.balance}**`, color: '#ED4245' })], components: [] });
          return collector.stop();
        }
        await i.update({ embeds: [showEmbed('playing')], components: [row] });
      } else {
        while (handValue(dealerHand) < 17) dealerHand.push(drawCard());
        const pv = handValue(playerHand), dv = handValue(dealerHand);
        let result, winnings = 0;
        if (dv > 21 || pv > dv) { winnings = bet * 2; result = `🎉 You win! +**${winnings}** coins`; }
        else if (pv === dv) { winnings = bet; result = `🤝 Push! Bet returned.`; }
        else { result = `😢 Dealer wins. You lost **${bet}** coins.`; }
        eco.balance += winnings;
        EconomyManager.setUser(message.author.id, message.guild.id, eco);
        await i.update({ embeds: [Embed.custom({
          title: '🃏 Blackjack Result',
          fields: [
            { name: `Your Hand (${pv})`, value: handStr(playerHand), inline: true },
            { name: `Dealer's Hand (${dv})`, value: handStr(dealerHand), inline: true }
          ],
          description: `${result}\nBalance: **${eco.balance}**`,
          color: winnings >= bet * 2 ? '#57F287' : winnings === bet ? '#FEE75C' : '#ED4245'
        })], components: [] });
        collector.stop();
      }
    });
    collector.on('end', (_, reason) => { if (reason === 'time') m.edit({ components: [] }).catch(() => {}); });
  }
};
