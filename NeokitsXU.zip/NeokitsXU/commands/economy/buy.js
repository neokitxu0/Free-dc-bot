const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'buy',
  description: 'Buy an item from the shop',
  usage: 'buy <item name>',
  category: 'economy',
  cooldown: 5,
  async execute(client, message, args) {
    const itemName = args.join(' ').toLowerCase();
    if (!itemName) return message.reply({ embeds: [Embed.error('Missing Item', 'Provide an item name to buy.')] });
    const items = DataManager.get('shop', message.guild.id, []);
    const item = items.find(i => i.name.toLowerCase() === itemName || i.id === parseInt(itemName));
    if (!item) return message.reply({ embeds: [Embed.error('Not Found', `Item \`${itemName}\` not found in the shop.`)] });
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    if ((eco.balance || 0) < item.price) return message.reply({ embeds: [Embed.error('Insufficient Funds', `You need **${item.price}** coins but only have **${eco.balance || 0}**.`)] });
    eco.balance -= item.price;
    eco.inventory = eco.inventory || [];
    eco.inventory.push({ ...item, purchasedAt: Date.now() });
    EconomyManager.setUser(message.author.id, message.guild.id, eco);
    message.reply({ embeds: [Embed.success('Purchased!', `You bought **${item.emoji} ${item.name}** for **${item.price}** coins!\nBalance: **${eco.balance}** coins`)] });
  }
};
