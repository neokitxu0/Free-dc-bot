const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

module.exports = {
  name: 'crash',
  description: 'Play the crash game',
  usage: 'crash <bet>',
  category: 'economy',
  cooldown: 10,
  async execute(client, message, args) {
    const bet = parseInt(args[0]);
    if (!bet || bet <= 0) return message.reply({ embeds: [Embed.error('Invalid Bet', 'Provide a valid bet.')] });
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    if ((eco.balance || 0) < bet) return message.reply({ embeds: [Embed.error('Insufficient Funds', `You only have **${eco.balance || 0}** coins.`)] });
    eco.balance -= bet;
    const crashPoint = +(1 + Math.random() * 9).toFixed(2);
    let multiplier = 1.00;
    const steps = [];
    while (multiplier < crashPoint) {
      multiplier = +(multiplier + 0.25).toFixed(2);
      steps.push(multiplier);
      if (steps.length >= 6) break;
    }
    const didCrash = multiplier >= crashPoint;
    const finalMult = didCrash ? +(multiplier - 0.25).toFixed(2) : multiplier;
    const winnings = didCrash ? 0 : Math.floor(bet * finalMult);
    eco.balance += winnings;
    EconomyManager.setUser(message.author.id, message.guild.id, eco);
    message.reply({ embeds: [Embed.custom({
      title: '🚀 Crash',
      description: `Progress: ${steps.map(s => `${s}x`).join(' → ')}\n\n💥 **Crashed at ${crashPoint}x**\n\n${didCrash ? `❌ Lost **${bet}** coins.` : `✅ Cashed out at **${finalMult}x** — Won **${winnings}** coins!`}\nBalance: **${eco.balance}**`,
      color: didCrash ? '#ED4245' : '#57F287'
    })] });
  }
};
