const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

module.exports = {
  name: 'daily',
  description: 'Claim your daily reward',
  usage: 'daily',
  category: 'economy',
  cooldown: 0,
  async execute(client, message) {
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    const now = Date.now();
    const cooldown = 86400000;
    if (eco.lastDaily && (now - eco.lastDaily) < cooldown) {
      const remaining = cooldown - (now - eco.lastDaily);
      const h = Math.floor(remaining / 3600000);
      const m = Math.floor((remaining % 3600000) / 60000);
      return message.reply({ embeds: [Embed.warn('Already Claimed', `Daily reset in **${h}h ${m}m**.`)] });
    }
    const amount = 200 + Math.floor(Math.random() * 300);
    const streak = (eco.dailyStreak || 0) + 1;
    const bonus = Math.min(streak * 10, 500);
    eco.balance = (eco.balance || 0) + amount + bonus;
    eco.lastDaily = now;
    eco.dailyStreak = streak;
    EconomyManager.setUser(message.author.id, message.guild.id, eco);
    message.reply({ embeds: [Embed.success('Daily Reward', `You claimed **${amount + bonus}** coins!\nStreak: **${streak}** day(s) (+${bonus} bonus)\nBalance: **${eco.balance}** coins`)] });
  }
};
