const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

module.exports = {
  name: 'deposit',
  aliases: ['dep'],
  description: 'Deposit coins into your bank',
  usage: 'deposit <amount|all>',
  category: 'economy',
  cooldown: 5,
  async execute(client, message, args) {
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    const balance = eco.balance || 0;
    const amount = args[0]?.toLowerCase() === 'all' ? balance : parseInt(args[0]);
    if (!amount || amount <= 0 || isNaN(amount)) return message.reply({ embeds: [Embed.error('Invalid Amount', 'Provide a valid amount to deposit.')] });
    if (amount > balance) return message.reply({ embeds: [Embed.error('Insufficient Funds', `You only have **${balance}** coins in your wallet.`)] });
    eco.balance = balance - amount;
    eco.bank = (eco.bank || 0) + amount;
    EconomyManager.setUser(message.author.id, message.guild.id, eco);
    message.reply({ embeds: [Embed.success('Deposited', `Deposited **${amount}** coins into your bank.\nWallet: **${eco.balance}** | Bank: **${eco.bank}**`)] });
  }
};
