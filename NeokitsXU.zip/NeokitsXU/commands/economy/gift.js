const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

module.exports = {
  name: 'gift',
  aliases: ['give', 'pay'],
  description: 'Gift coins to another user',
  usage: 'gift <@user> <amount>',
  category: 'economy',
  cooldown: 10,
  async execute(client, message, args) {
    const target = message.mentions.members.first();
    if (!target || target.id === message.author.id) return message.reply({ embeds: [Embed.error('Invalid', 'Mention someone to gift coins to.')] });
    const amount = parseInt(args[1]);
    if (!amount || amount <= 0) return message.reply({ embeds: [Embed.error('Invalid Amount', 'Provide a valid positive amount.')] });
    const myEco = EconomyManager.getUser(message.author.id, message.guild.id);
    if ((myEco.balance || 0) < amount) return message.reply({ embeds: [Embed.error('Insufficient Funds', `You only have **${myEco.balance || 0}** coins.`)] });
    const targetEco = EconomyManager.getUser(target.id, message.guild.id);
    myEco.balance = (myEco.balance || 0) - amount;
    targetEco.balance = (targetEco.balance || 0) + amount;
    EconomyManager.setUser(message.author.id, message.guild.id, myEco);
    EconomyManager.setUser(target.id, message.guild.id, targetEco);
    message.reply({ embeds: [Embed.success('Gift Sent', `You gifted **${amount}** coins to **${target.user.username}**!\nYour balance: **${myEco.balance}** coins`)] });
  }
};
