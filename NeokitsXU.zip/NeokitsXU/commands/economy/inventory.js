const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

module.exports = {
  name: 'inventory',
  aliases: ['inv', 'bag'],
  description: 'View your inventory',
  usage: 'inventory [@user]',
  category: 'economy',
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.users.first() || message.author;
    const eco = EconomyManager.getUser(target.id, message.guild.id);
    const inv = eco.inventory || [];
    if (!inv.length) return message.reply({ embeds: [Embed.info('Empty', `**${target.username}**'s inventory is empty.`)] });
    const grouped = {};
    for (const item of inv) {
      if (!grouped[item.name]) grouped[item.name] = { ...item, count: 0 };
      grouped[item.name].count++;
    }
    const desc = Object.values(grouped).map(i => `${i.emoji || '📦'} **${i.name}** x${i.count}`).join('\n');
    message.reply({ embeds: [Embed.custom({ title: `🎒 Inventory — ${target.username}`, description: desc })] });
  }
};
