const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

module.exports = {
  name: 'leaderboard',
  aliases: ['lb', 'richest'],
  description: 'View the economy leaderboard',
  usage: 'leaderboard',
  category: 'economy',
  cooldown: 10,
  async execute(client, message) {
    const all = EconomyManager.getAll(message.guild.id);
    const sorted = Object.entries(all).sort((a, b) => ((b[1].balance || 0) + (b[1].bank || 0)) - ((a[1].balance || 0) + (a[1].bank || 0))).slice(0, 10);
    if (!sorted.length) return message.reply({ embeds: [Embed.info('Empty', 'No economy data yet.')] });
    const medals = ['🥇', '🥈', '🥉'];
    const desc = sorted.map(([id, data], i) => {
      const user = client.users.cache.get(id);
      const total = (data.balance || 0) + (data.bank || 0);
      return `${medals[i] || `**${i+1}.**`} ${user ? user.tag : `<@${id}>`} — **${total}** coins`;
    }).join('\n');
    message.reply({ embeds: [Embed.custom({ title: `💰 Economy Leaderboard — ${message.guild.name}`, description: desc })] });
  }
};
