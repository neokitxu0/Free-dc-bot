const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

module.exports = {
  name: 'monthly',
  description: 'Claim your monthly reward',
  usage: 'monthly',
  category: 'economy',
  cooldown: 0,
  async execute(client, message) {
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    const now = Date.now();
    const cooldown = 2592000000;
    if (eco.lastMonthly && (now - eco.lastMonthly) < cooldown) {
      const remaining = cooldown - (now - eco.lastMonthly);
      const d = Math.floor(remaining / 86400000);
      return message.reply({ embeds: [Embed.warn('Already Claimed', `Monthly reset in **${d}d**.`)] });
    }
    const amount = 15000 + Math.floor(Math.random() * 5000);
    eco.balance = (eco.balance || 0) + amount;
    eco.lastMonthly = now;
    EconomyManager.setUser(message.author.id, message.guild.id, eco);
    message.reply({ embeds: [Embed.success('Monthly Reward', `You claimed **${amount}** coins!\nBalance: **${eco.balance}** coins`)] });
  }
};
