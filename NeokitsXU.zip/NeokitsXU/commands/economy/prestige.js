const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

module.exports = {
  name: 'prestige',
  description: 'Prestige your economy — reset balance for a bonus',
  usage: 'prestige',
  category: 'economy',
  cooldown: 5,
  async execute(client, message) {
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    const required = 100000;
    const total = (eco.balance || 0) + (eco.bank || 0);
    if (total < required) return message.reply({ embeds: [Embed.warn('Not Enough', `You need at least **${required}** total coins to prestige. You have **${total}**.`)] });
    eco.balance = 0; eco.bank = 0;
    eco.prestige = (eco.prestige || 0) + 1;
    eco.prestigeBonus = (eco.prestige * 50);
    EconomyManager.setUser(message.author.id, message.guild.id, eco);
    message.reply({ embeds: [Embed.custom({
      title: '✨ Prestige!',
      description: `You've reached **Prestige ${eco.prestige}**!\n\nYour balance has been reset in exchange for:\n• +**${eco.prestigeBonus}** bonus on all work earnings\n• Prestige badge on your profile`,
      color: '#FFD700'
    })] });
  }
};
