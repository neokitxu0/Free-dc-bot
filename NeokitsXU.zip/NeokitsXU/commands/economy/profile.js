const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');
const LevelManager = require('../../utils/LevelManager');

module.exports = {
  name: 'profile',
  aliases: ['pro'],
  description: 'View your economy profile',
  usage: 'profile [@user]',
  category: 'economy',
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.users.first() || message.author;
    const eco = EconomyManager.getUser(target.id, message.guild.id);
    const lvl = LevelManager.getUser(target.id, message.guild.id);
    const total = (eco.balance || 0) + (eco.bank || 0);
    message.reply({ embeds: [Embed.custom({
      title: `👤 Profile — ${target.username}`,
      thumbnail: target.displayAvatarURL({ dynamic: true }),
      fields: [
        { name: '💵 Wallet', value: `${eco.balance || 0}`, inline: true },
        { name: '🏦 Bank', value: `${eco.bank || 0}`, inline: true },
        { name: '💎 Net Worth', value: `${total}`, inline: true },
        { name: '⭐ Level', value: `${lvl.level || 1}`, inline: true },
        { name: '🔥 Daily Streak', value: `${eco.dailyStreak || 0}`, inline: true },
        { name: '🎒 Items', value: `${(eco.inventory || []).length}`, inline: true },
      ]
    })] });
  }
};
