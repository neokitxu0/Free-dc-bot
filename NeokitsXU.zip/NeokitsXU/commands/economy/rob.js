const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

module.exports = {
  name: 'rob',
  description: 'Rob another user',
  usage: 'rob <@user>',
  category: 'economy',
  cooldown: 0,
  async execute(client, message, args) {
    const target = message.mentions.members.first();
    if (!target || target.id === message.author.id) return message.reply({ embeds: [Embed.error('Invalid', 'Mention someone to rob!')] });
    const myEco = EconomyManager.getUser(message.author.id, message.guild.id);
    const targetEco = EconomyManager.getUser(target.id, message.guild.id);
    const now = Date.now();
    const cooldown = 3600000;
    if (myEco.lastRob && (now - myEco.lastRob) < cooldown) {
      const rem = Math.floor((cooldown - (now - myEco.lastRob)) / 60000);
      return message.reply({ embeds: [Embed.warn('On Cooldown', `You can rob again in **${rem}m**.`)] });
    }
    if ((targetEco.balance || 0) < 100) return message.reply({ embeds: [Embed.error('Poor Target', `**${target.user.username}** is too broke to rob!`)] });
    myEco.lastRob = now;
    if (Math.random() < 0.4) {
      const fine = 100 + Math.floor(Math.random() * 200);
      myEco.balance = Math.max(0, (myEco.balance || 0) - fine);
      EconomyManager.setUser(message.author.id, message.guild.id, myEco);
      return message.reply({ embeds: [Embed.error('Caught!', `You got caught robbing! You paid a **${fine}** coin fine.`)] });
    }
    const stolen = Math.floor(targetEco.balance * (0.1 + Math.random() * 0.2));
    myEco.balance = (myEco.balance || 0) + stolen;
    targetEco.balance = Math.max(0, (targetEco.balance || 0) - stolen);
    EconomyManager.setUser(message.author.id, message.guild.id, myEco);
    EconomyManager.setUser(target.id, message.guild.id, targetEco);
    message.reply({ embeds: [Embed.success('Robbery!', `You robbed **${target.user.username}** for **${stolen}** coins!\nBalance: **${myEco.balance}** coins`)] });
  }
};
