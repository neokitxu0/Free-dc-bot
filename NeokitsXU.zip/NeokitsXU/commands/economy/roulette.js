const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

module.exports = {
  name: 'roulette',
  description: 'Play roulette',
  usage: 'roulette <bet> <red|black|green|number>',
  category: 'economy',
  cooldown: 10,
  async execute(client, message, args) {
    const bet = parseInt(args[0]);
    const choice = args[1]?.toLowerCase();
    if (!bet || bet <= 0 || !choice) return message.reply({ embeds: [Embed.error('Usage', 'roulette <bet> <red|black|green|0-36>')] });
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    if ((eco.balance || 0) < bet) return message.reply({ embeds: [Embed.error('Insufficient Funds', `You only have **${eco.balance || 0}** coins.`)] });
    eco.balance -= bet;
    const spin = Math.floor(Math.random() * 37);
    const reds = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
    const color = spin === 0 ? 'green' : reds.includes(spin) ? 'red' : 'black';
    const emoji = color === 'green' ? '💚' : color === 'red' ? '🔴' : '⚫';
    let winnings = 0, result;
    if (choice === color) {
      const mult = color === 'green' ? 14 : 2;
      winnings = bet * mult;
      result = `✅ ${emoji} You guessed **${choice}**! Won **${winnings}** coins!`;
    } else if (!isNaN(choice) && parseInt(choice) === spin) {
      winnings = bet * 35;
      result = `🎉 Exact number! Won **${winnings}** coins!`;
    } else {
      result = `❌ Result: **${spin}** (${emoji} ${color}). Lost **${bet}** coins.`;
    }
    eco.balance += winnings;
    EconomyManager.setUser(message.author.id, message.guild.id, eco);
    message.reply({ embeds: [Embed.custom({ title: `🎡 Roulette — ${spin} ${emoji}`, description: `${result}\nBalance: **${eco.balance}** coins`, color: winnings > 0 ? '#57F287' : '#ED4245' })] });
  }
};
