const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

const prizes = [100, 200, 500, 1000, 2500, 5000, 10000];

module.exports = {
  name: 'scratch',
  description: 'Buy a scratch card',
  usage: 'scratch',
  category: 'economy',
  cooldown: 15,
  async execute(client, message) {
    const cost = 50;
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    if ((eco.balance || 0) < cost) return message.reply({ embeds: [Embed.error('Insufficient Funds', `Scratch cards cost **${cost}** coins.`)] });
    eco.balance -= cost;
    const grid = Array.from({ length: 9 }, () => prizes[Math.floor(Math.random() * prizes.length)]);
    const counts = {};
    for (const p of grid) counts[p] = (counts[p] || 0) + 1;
    const match3 = Object.entries(counts).find(([, c]) => c >= 3);
    const winnings = match3 ? parseInt(match3[0]) : 0;
    eco.balance += winnings;
    EconomyManager.setUser(message.author.id, message.guild.id, eco);
    const rows = [[grid[0], grid[1], grid[2]], [grid[3], grid[4], grid[5]], [grid[6], grid[7], grid[8]]];
    const display = rows.map(r => r.map(n => `\`${n}\``).join(' | ')).join('\n');
    message.reply({ embeds: [Embed.custom({
      title: '🎟️ Scratch Card',
      description: `${display}\n\n${winnings > 0 ? `🎉 Match 3! Won **${winnings}** coins!` : '❌ No match. Better luck next time!'}\nBalance: **${eco.balance}**`,
      color: winnings > 0 ? '#57F287' : '#ED4245'
    })] });
  }
};
