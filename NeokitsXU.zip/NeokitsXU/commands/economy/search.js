const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

const locations = ['in the couch cushions', 'under the bed', 'in the trash', 'in your old jeans', 'in the park', 'in a store', 'in the attic', 'behind the TV'];

module.exports = {
  name: 'search',
  description: 'Search for coins in various places',
  usage: 'search',
  category: 'economy',
  cooldown: 0,
  async execute(client, message) {
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    const now = Date.now();
    const cooldown = 300000;
    if (eco.lastSearch && (now - eco.lastSearch) < cooldown) {
      const rem = Math.ceil((cooldown - (now - eco.lastSearch)) / 1000);
      return message.reply({ embeds: [Embed.warn('Too Soon', `Search again in **${rem}s**.`)] });
    }
    const loc = locations[Math.floor(Math.random() * locations.length)];
    eco.lastSearch = now;
    if (Math.random() < 0.3) {
      EconomyManager.setUser(message.author.id, message.guild.id, eco);
      return message.reply({ embeds: [Embed.warn('Nothing Found', `You searched ${loc} and found nothing!`)] });
    }
    const amount = 20 + Math.floor(Math.random() * 180);
    eco.balance = (eco.balance || 0) + amount;
    EconomyManager.setUser(message.author.id, message.guild.id, eco);
    message.reply({ embeds: [Embed.success('Found Coins!', `You searched ${loc} and found **${amount}** coins!\nBalance: **${eco.balance}**`)] });
  }
};
