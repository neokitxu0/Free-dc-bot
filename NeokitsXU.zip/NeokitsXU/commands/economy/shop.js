const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'shop',
  description: 'View the server shop',
  usage: 'shop [page]',
  category: 'economy',
  cooldown: 5,
  async execute(client, message, args) {
    const items = DataManager.get('shop', message.guild.id, [
      { id: 1, name: 'Lucky Charm', price: 500, description: 'Increases luck for the day', emoji: '🍀' },
      { id: 2, name: 'XP Booster', price: 1000, description: '2x XP for 1 hour', emoji: '⚡' },
      { id: 3, name: 'VIP Badge', price: 5000, description: 'Exclusive VIP badge for your profile', emoji: '👑' },
      { id: 4, name: 'Mystery Box', price: 2000, description: 'Contains a random prize', emoji: '📦' },
    ]);
    if (!items.length) return message.reply({ embeds: [Embed.info('Empty Shop', 'No items in the shop yet.')] });
    const fields = items.map(i => ({ name: `${i.emoji} ${i.name} — ${i.price} coins`, value: i.description, inline: false }));
    message.reply({ embeds: [Embed.custom({ title: `🛒 Server Shop — ${message.guild.name}`, description: `Use \`${client.config.prefix}buy <item name>\` to purchase.`, fields })] });
  }
};
