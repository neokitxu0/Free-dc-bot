const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

const symbols = ['🍒', '🍋', '🍊', '🍇', '💎', '⭐', '7️⃣'];

module.exports = {
  name: 'slots',
  description: 'Play the slot machine',
  usage: 'slots <bet>',
  category: 'economy',
  cooldown: 10,
  async execute(client, message, args) {
    const bet = parseInt(args[0]);
    if (!bet || bet <= 0) return message.reply({ embeds: [Embed.error('Invalid Bet', 'Provide a valid bet amount.')] });
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    if ((eco.balance || 0) < bet) return message.reply({ embeds: [Embed.error('Insufficient Funds', `You only have **${eco.balance || 0}** coins.`)] });
    eco.balance -= bet;
    const spin = () => symbols[Math.floor(Math.random() * symbols.length)];
    const s = [spin(), spin(), spin()];
    let winnings = 0, result = '❌ No match';
    if (s[0] === s[1] && s[1] === s[2]) {
      const multipliers = { '💎': 10, '7️⃣': 7, '⭐': 5, '🍒': 3, '🍋': 2, '🍊': 2, '🍇': 2 };
      winnings = bet * (multipliers[s[0]] || 2);
      result = `🎉 Three of a kind! +**${winnings}** coins`;
    } else if (s[0] === s[1] || s[1] === s[2] || s[0] === s[2]) {
      winnings = Math.floor(bet * 0.5);
      result = `✅ Pair! +**${winnings}** coins`;
    }
    eco.balance += winnings;
    EconomyManager.setUser(message.author.id, message.guild.id, eco);
    message.reply({ embeds: [Embed.custom({
      title: '🎰 Slot Machine',
      description: `**| ${s[0]} | ${s[1]} | ${s[2]} |**\n\n${result}\nBalance: **${eco.balance}** coins`,
      color: winnings > 0 ? '#57F287' : '#ED4245'
    })] });
  }
};
