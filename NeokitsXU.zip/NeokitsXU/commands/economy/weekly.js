const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

module.exports = {
  name: 'weekly',
  description: 'Claim your weekly reward',
  usage: 'weekly',
  category: 'economy',
  cooldown: 0,
  async execute(client, message) {
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    const now = Date.now();
    const cooldown = 604800000;
    if (eco.lastWeekly && (now - eco.lastWeekly) < cooldown) {
      const remaining = cooldown - (now - eco.lastWeekly);
      const d = Math.floor(remaining / 86400000);
      const h = Math.floor((remaining % 86400000) / 3600000);
      return message.reply({ embeds: [Embed.warn('Already Claimed', `Weekly reset in **${d}d ${h}h**.`)] });
    }
    const amount = 2000 + Math.floor(Math.random() * 1000);
    eco.balance = (eco.balance || 0) + amount;
    eco.lastWeekly = now;
    EconomyManager.setUser(message.author.id, message.guild.id, eco);
    message.reply({ embeds: [Embed.success('Weekly Reward', `You claimed **${amount}** coins!\nBalance: **${eco.balance}** coins`)] });
  }
};
