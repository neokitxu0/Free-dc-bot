const Embed = require('../../utils/Embed');
const EconomyManager = require('../../utils/EconomyManager');

const jobs = [
  "You fixed bugs for 8 hours straight.",
  "You delivered packages around the city.",
  "You tutored students in math.",
  "You cooked food at a restaurant.",
  "You drove for a ride-share service.",
  "You walked dogs in the park.",
  "You cleaned office buildings.",
  "You helped at a local farm.",
  "You streamed games online.",
  "You freelanced as a graphic designer.",
];

module.exports = {
  name: 'work',
  description: 'Work to earn coins',
  usage: 'work',
  category: 'economy',
  cooldown: 0,
  async execute(client, message) {
    const eco = EconomyManager.getUser(message.author.id, message.guild.id);
    const now = Date.now();
    const cooldown = 3600000;
    if (eco.lastWork && (now - eco.lastWork) < cooldown) {
      const remaining = cooldown - (now - eco.lastWork);
      const m = Math.floor(remaining / 60000);
      const s = Math.floor((remaining % 60000) / 1000);
      return message.reply({ embeds: [Embed.warn('Too Tired', `You need to rest! Work again in **${m}m ${s}s**.`)] });
    }
    const earned = 100 + Math.floor(Math.random() * 200);
    const job = jobs[Math.floor(Math.random() * jobs.length)];
    eco.balance = (eco.balance || 0) + earned;
    eco.lastWork = now;
    EconomyManager.setUser(message.author.id, message.guild.id, eco);
    message.reply({ embeds: [Embed.success('Work Complete', `${job}\n\nYou earned **${earned}** coins!\nBalance: **${eco.balance}** coins`)] });
  }
};
