const Embed = require('../../utils/Embed');

const responses = [
  { text: 'It is certain.', positive: true }, { text: 'It is decidedly so.', positive: true },
  { text: 'Without a doubt.', positive: true }, { text: 'Yes, definitely.', positive: true },
  { text: 'You may rely on it.', positive: true }, { text: 'As I see it, yes.', positive: true },
  { text: 'Most likely.', positive: true }, { text: 'Outlook good.', positive: true },
  { text: 'Yes.', positive: true }, { text: 'Signs point to yes.', positive: true },
  { text: 'Reply hazy, try again.', positive: null }, { text: 'Ask again later.', positive: null },
  { text: 'Better not tell you now.', positive: null }, { text: 'Cannot predict now.', positive: null },
  { text: "Concentrate and ask again.", positive: null },
  { text: "Don't count on it.", positive: false }, { text: 'My reply is no.', positive: false },
  { text: 'My sources say no.', positive: false }, { text: 'Outlook not so good.', positive: false },
  { text: 'Very doubtful.', positive: false }
];

module.exports = {
  name: '8ball',
  aliases: ['ask', 'magic8'],
  description: 'Ask the magic 8-ball a question',
  usage: '8ball <question>',
  category: 'fun',
  cooldown: 3,
  async execute(client, message, args) {
    const question = args.join(' ');
    if (!question) return message.reply({ embeds: [Embed.error('Missing Question', 'Ask the magic 8-ball something!')] });
    const resp = responses[Math.floor(Math.random() * responses.length)];
    const color = resp.positive === true ? '#57F287' : resp.positive === false ? '#ED4245' : '#FEE75C';
    const emoji = resp.positive === true ? '✅' : resp.positive === false ? '❌' : '🔮';
    message.reply({ embeds: [Embed.custom({ title: '🎱 Magic 8-Ball', description: `**Question:** ${question}\n\n${emoji} **${resp.text}**`, color })] });
  }
};
