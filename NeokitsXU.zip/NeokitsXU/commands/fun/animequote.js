const Embed = require('../../utils/Embed');

const quotes = [
  { text: "The only ones who should kill are those who are prepared to be killed.", author: "Lelouch — Code Geass" },
  { text: "It's not the face that makes someone a monster, it's the choices they make with their lives.", author: "Naruto Uzumaki" },
  { text: "Hard work is worthless for those that don't believe in themselves.", author: "Naruto Uzumaki" },
  { text: "People who continue to put their lives on the line to defend their ideals are truly free.", author: "Erwin Smith — AoT" },
  { text: "Even if I can't see you... Even if we're separated far apart... I'll always be watching you.", author: "Mavis Vermillion — Fairy Tail" },
  { text: "Whatever you lose, you'll find it again. But what you throw away you'll never get back.", author: "Himura Kenshin" },
  { text: "If you don't take risks, you can't create a future.", author: "Monkey D. Luffy — One Piece" },
  { text: "A dropout will beat a genius through hard work.", author: "Rock Lee — Naruto" },
];

module.exports = {
  name: 'animequote',
  description: 'Get a random anime quote',
  usage: 'animequote',
  category: 'fun',
  cooldown: 5,
  async execute(client, message) {
    const q = quotes[Math.floor(Math.random() * quotes.length)];
    message.reply({ embeds: [Embed.custom({ title: '⛩️ Anime Quote', description: `*"${q.text}"*\n\n— **${q.author}**`, color: '#E74C3C' })] });
  }
};
