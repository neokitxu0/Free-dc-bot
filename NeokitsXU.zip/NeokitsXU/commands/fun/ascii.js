const Embed = require('../../utils/Embed');

module.exports = {
  name: 'ascii',
  description: 'Convert text to ASCII art',
  usage: 'ascii <text>',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const text = args.join(' ').slice(0, 20);
    if (!text) return message.reply({ embeds: [Embed.error('Missing Text', 'Provide text to convert.')] });
    const blocks = text.split('').map(c => c === ' ' ? '   ' : `${c.toUpperCase()}`).join(' ');
    message.reply({ embeds: [Embed.custom({ title: '🔡 ASCII Art', description: `\`\`\`\n${blocks}\n\`\`\`` })] });
  }
};
