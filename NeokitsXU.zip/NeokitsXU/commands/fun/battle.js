const Embed = require('../../utils/Embed');

module.exports = {
  name: 'battle',
  description: 'Battle between two users',
  usage: 'battle <@user1> <@user2>',
  category: 'fun',
  cooldown: 10,
  async execute(client, message, args) {
    const u1 = message.mentions.users.first();
    const u2 = message.mentions.users.at(1);
    if (!u1 || !u2 || u1.id === u2.id) return message.reply({ embeds: [Embed.error('Invalid', 'Mention two different users to battle!')] });
    const winner = Math.random() < 0.5 ? u1 : u2;
    const loser = winner.id === u1.id ? u2 : u1;
    const attacks = [
      `${winner.username} landed a critical hit on ${loser.username}!`,
      `${winner.username} dodged all of ${loser.username}'s attacks and countered!`,
      `${winner.username} pulled out the ultimate move and obliterated ${loser.username}!`,
    ];
    const attack = attacks[Math.floor(Math.random() * attacks.length)];
    message.reply({ embeds: [Embed.custom({
      title: `⚔️ Battle: ${u1.username} vs ${u2.username}`,
      description: `${attack}\n\n🏆 **${winner.username} wins!**\n💀 ${loser.username} has been defeated.`
    })] });
  }
};
