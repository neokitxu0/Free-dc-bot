const Embed = require('../../utils/Embed');

module.exports = {
  name: 'captcha',
  description: 'Fake captcha challenge',
  usage: 'captcha [@user]',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.member;
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    const code = Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    message.reply({ embeds: [Embed.custom({
      title: '🤖 CAPTCHA Verification',
      description: `${target.user} please verify you are human!\n\n\`\`\`\n ${code.split('').join(' ')} \n\`\`\`\n\n*Type the code above to prove you're not a robot!*`,
      footer: { text: 'I\'m not a robot ✓' },
      color: '#4285F4'
    })] });
  }
};
