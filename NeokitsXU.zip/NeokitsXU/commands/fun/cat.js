const Embed = require('../../utils/Embed');

const catImages = [
  'https://cdn2.thecatapi.com/images/aen.jpg',
  'https://cdn2.thecatapi.com/images/dga.jpg',
  'https://cdn2.thecatapi.com/images/MTY3ODIyMQ.jpg',
  'https://cdn2.thecatapi.com/images/9e6.jpg',
  'https://cdn2.thecatapi.com/images/bpc.jpg',
];

module.exports = {
  name: 'cat',
  description: 'Get a random cat image',
  usage: 'cat',
  category: 'fun',
  cooldown: 5,
  async execute(client, message) {
    const img = catImages[Math.floor(Math.random() * catImages.length)];
    message.reply({ embeds: [Embed.custom({ title: '🐱 Random Cat', image: img, color: '#FF9ECC' })] });
  }
};
