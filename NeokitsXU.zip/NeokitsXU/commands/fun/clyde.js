const Embed = require('../../utils/Embed');

module.exports = {
  name: 'clyde',
  description: 'Make Clyde say something',
  usage: 'clyde <message>',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const text = args.join(' ');
    if (!text) return message.reply({ embeds: [Embed.error('Missing Text', 'Provide a message for Clyde.')] });
    message.reply({ embeds: [Embed.custom({
      author: { name: 'Clyde', iconURL: 'https://discord.com/assets/5ccabf62108d5a8074ddd4af2d898560.png' },
      description: text,
      color: '#5865F2'
    })] });
  }
};
