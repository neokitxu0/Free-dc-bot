const Embed = require('../../utils/Embed');

module.exports = {
  name: 'compatibility',
  aliases: ['compat'],
  description: 'Check compatibility between two things',
  usage: 'compatibility <thing1> and <thing2>',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const input = args.join(' ');
    if (!input.includes(' and ')) return message.reply({ embeds: [Embed.error('Usage', 'compatibility <thing1> and <thing2>')] });
    const [a, b] = input.split(' and ').map(s => s.trim());
    const seed = (a + b).toLowerCase().split('').reduce((x, c) => x + c.charCodeAt(0), 0);
    const percent = seed % 101;
    const bar = '💚'.repeat(Math.floor(percent / 10)) + '🖤'.repeat(10 - Math.floor(percent / 10));
    const rating = percent >= 90 ? 'Made for each other! 💑' : percent >= 70 ? 'Great match! ✨' : percent >= 50 ? 'Could work! 😊' : percent >= 30 ? 'A bit of a stretch... 😬' : 'Disaster waiting to happen 💀';
    message.reply({ embeds: [Embed.custom({
      title: '💞 Compatibility',
      description: `**${a}** ❤️ **${b}**\n\n${bar}\n\n**${percent}%** — ${rating}`
    })] });
  }
};
