const Embed = require('../../utils/Embed');

const compliments = [
  "You are literally the best person I've ever encountered.",
  "You have a genuinely great sense of humor.",
  "You light up the room with your presence.",
  "You make every place you go a little better.",
  "You have the best ideas.",
  "Your creativity is awe-inspiring.",
  "Somehow you make time stop and fly at the same time.",
  "You are enough. You always have been.",
  "You deserve the world and then some.",
  "The world is a brighter place because you're in it."
];

module.exports = {
  name: 'compliment',
  description: 'Compliment a user',
  usage: 'compliment [@user]',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.member;
    const c = compliments[Math.floor(Math.random() * compliments.length)];
    message.reply({ embeds: [Embed.custom({ title: `💐 Compliment — ${target.user.username}`, description: c, color: '#FF9ECC' })] });
  }
};
