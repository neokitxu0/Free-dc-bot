const Embed = require('../../utils/Embed');

const dares = [
  "Change your nickname to something embarrassing for 1 hour.",
  "Send a voice message saying 'I love Discord bots' in a baby voice.",
  "React to the last 10 messages with 🥦.",
  "Post your most recent photo in this channel.",
  "Call a friend and say 'I need you right now' and hang up.",
  "Let the person to your right post anything as your status for 1 hour.",
  "Speak in rhymes for the next 5 minutes.",
  "DM someone random in this server a wholesome message.",
  "Send a crying selfie to this channel.",
  "Pretend to be a bot for the next 3 messages.",
];

module.exports = {
  name: 'dare',
  description: 'Get a random dare',
  usage: 'dare',
  category: 'fun',
  cooldown: 5,
  async execute(client, message) {
    const d = dares[Math.floor(Math.random() * dares.length)];
    message.reply({ embeds: [Embed.custom({ title: '🔥 Dare', description: d, color: '#FF4500' })] });
  }
};
