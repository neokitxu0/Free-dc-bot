const Embed = require('../../utils/Embed');

const dogImages = [
  'https://images.dog.ceo/breeds/retriever-golden/n02099601_1722.jpg',
  'https://images.dog.ceo/breeds/husky/n02110185_10047.jpg',
  'https://images.dog.ceo/breeds/labrador/n02099712_4323.jpg',
  'https://images.dog.ceo/breeds/poodle-standard/n02113799_2280.jpg',
  'https://images.dog.ceo/breeds/corgi-cardigan/n02113186_1030.jpg',
];

module.exports = {
  name: 'dog',
  description: 'Get a random dog image',
  usage: 'dog',
  category: 'fun',
  cooldown: 5,
  async execute(client, message) {
    const img = dogImages[Math.floor(Math.random() * dogImages.length)];
    message.reply({ embeds: [Embed.custom({ title: '🐶 Random Dog', image: img, color: '#FEE75C' })] });
  }
};
