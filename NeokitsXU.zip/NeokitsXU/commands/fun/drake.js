const Embed = require('../../utils/Embed');

module.exports = {
  name: 'drake',
  description: 'Drake meme format',
  usage: 'drake <dislike> | <like>',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const parts = args.join(' ').split('|').map(s => s.trim());
    if (parts.length < 2) return message.reply({ embeds: [Embed.error('Usage', 'drake <dislike thing> | <like thing>')] });
    message.reply({ embeds: [Embed.custom({
      title: '🐉 Drake Meme',
      description: `🚫 ❌ **${parts[0]}**\n\n✅ 😍 **${parts[1]}**`,
      color: '#1a1a1a'
    })] });
  }
};
