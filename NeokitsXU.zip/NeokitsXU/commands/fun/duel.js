const Embed = require('../../utils/Embed');
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  name: 'duel',
  description: 'Challenge someone to a duel',
  usage: 'duel <@user>',
  category: 'fun',
  cooldown: 15,
  async execute(client, message, args) {
    const opponent = message.mentions.members.first();
    if (!opponent || opponent.id === message.author.id) return message.reply({ embeds: [Embed.error('Invalid', 'Mention someone to duel!')] });
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('duel_accept').setLabel('Accept').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('duel_decline').setLabel('Decline').setStyle(ButtonStyle.Danger)
    );
    const m = await message.reply({ content: `${opponent}`, embeds: [Embed.custom({ title: '⚔️ Duel Challenge!', description: `**${message.author.tag}** has challenged **${opponent.user.tag}** to a duel!\n\n${opponent}, do you accept?` })], components: [row] });
    const filter = i => i.user.id === opponent.id;
    const collector = m.createMessageComponentCollector({ filter, time: 30000 });
    collector.on('collect', async i => {
      if (i.customId === 'duel_accept') {
        const winner = Math.random() < 0.5 ? message.author : opponent.user;
        await i.update({ embeds: [Embed.custom({ title: '⚔️ Duel Result', description: `🏆 **${winner.tag}** won the duel!` })], components: [] });
      } else {
        await i.update({ embeds: [Embed.warn('Duel Declined', `**${opponent.user.tag}** declined the duel.`)], components: [] });
      }
      collector.stop();
    });
    collector.on('end', async (_, reason) => {
      if (reason === 'time') m.edit({ components: [] }).catch(() => {});
    });
  }
};
