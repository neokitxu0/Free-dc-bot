const Embed = require('../../utils/Embed');

const map = {
  a:'🇦',b:'🇧',c:'🇨',d:'🇩',e:'🇪',f:'🇫',g:'🇬',h:'🇭',i:'🇮',j:'🇯',k:'🇰',l:'🇱',m:'🇲',
  n:'🇳',o:'🇴',p:'🇵',q:'🇶',r:'🇷',s:'🇸',t:'🇹',u:'🇺',v:'🇻',w:'🇼',x:'🇽',y:'🇾',z:'🇿',
  '0':'0️⃣','1':'1️⃣','2':'2️⃣','3':'3️⃣','4':'4️⃣','5':'5️⃣','6':'6️⃣','7':'7️⃣','8':'8️⃣','9':'9️⃣',
  ' ':'   ','!':'❗','?':'❓'
};

module.exports = {
  name: 'emojify',
  description: 'Convert text to emoji letters',
  usage: 'emojify <text>',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const text = args.join(' ');
    if (!text) return message.reply({ embeds: [Embed.error('Missing Text', 'Provide text to emojify.')] });
    const result = text.toLowerCase().split('').map(c => map[c] || c).join(' ');
    if (result.length > 1900) return message.reply({ embeds: [Embed.error('Too Long', 'Text is too long to emojify.')] });
    message.reply({ embeds: [Embed.custom({ title: '🔡 Emojified', description: result })] });
  }
};
