const Embed = require('../../utils/Embed');

const facts = [
  "Honey never spoils. Archaeologists have found 3000-year-old honey in Egyptian tombs.",
  "A group of flamingos is called a flamboyance.",
  "The shortest war in history lasted 38–45 minutes, between Britain and Zanzibar in 1896.",
  "Octopuses have three hearts, blue blood, and nine brains.",
  "A day on Venus is longer than a year on Venus.",
  "Hot water can freeze faster than cold water under certain conditions (Mpemba effect).",
  "Bananas are berries, but strawberries are not.",
  "Cleopatra lived closer in time to the Moon landing than to the construction of the Great Pyramid.",
  "The human body contains about 37 trillion cells.",
  "There are more possible chess games than atoms in the observable universe.",
];

module.exports = {
  name: 'fact',
  description: 'Get a random fun fact',
  usage: 'fact',
  category: 'fun',
  cooldown: 5,
  async execute(client, message) {
    const fact = facts[Math.floor(Math.random() * facts.length)];
    message.reply({ embeds: [Embed.custom({ title: '📚 Random Fact', description: fact, color: '#5865F2' })] });
  }
};
