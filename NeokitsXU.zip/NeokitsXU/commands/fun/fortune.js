const Embed = require('../../utils/Embed');

const fortunes = [
  "A great opportunity is coming your way soon.",
  "Today is a good day to make new friends.",
  "Your hard work will pay off in unexpected ways.",
  "Success comes to those who persevere.",
  "Be careful with your words today — they carry great power.",
  "A surprise is waiting for you around the corner.",
  "The stars are aligned in your favor today.",
  "An old friend will reach out to you soon.",
  "Trust your instincts — they will not lead you astray.",
  "The effort you put in now will bear great fruit.",
];

const luckNumbers = () => Array.from({ length: 6 }, () => Math.floor(Math.random() * 49) + 1).join(', ');

module.exports = {
  name: 'fortune',
  description: 'Get your fortune for today',
  usage: 'fortune',
  category: 'fun',
  cooldown: 10,
  async execute(client, message) {
    const f = fortunes[Math.floor(Math.random() * fortunes.length)];
    message.reply({ embeds: [Embed.custom({
      title: '🔮 Your Fortune',
      description: f,
      fields: [{ name: 'Lucky Numbers', value: luckNumbers(), inline: true }],
      color: '#9B59B6'
    })] });
  }
};
