const Embed = require('../../utils/Embed');

const foxImages = [
  'https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Vulpes_vulpes_ssp_fulvus.jpg/320px-Vulpes_vulpes_ssp_fulvus.jpg',
  'https://upload.wikimedia.org/wikipedia/commons/thumb/0/03/Red_Fox_%28Vulpes_vulpes%29_-_50.jpg/320px-Red_Fox_%28Vulpes_vulpes%29_-_50.jpg',
];

module.exports = {
  name: 'fox',
  description: 'Get a random fox image',
  usage: 'fox',
  category: 'fun',
  cooldown: 5,
  async execute(client, message) {
    const img = foxImages[Math.floor(Math.random() * foxImages.length)];
    message.reply({ embeds: [Embed.custom({ title: '🦊 Random Fox', image: img, color: '#FF6B35' })] });
  }
};
