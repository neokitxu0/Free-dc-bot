const Embed = require('../../utils/Embed');

module.exports = {
  name: 'gayrate',
  description: 'Get a random gay percentage (just for fun)',
  usage: 'gayrate [@user]',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const user = message.mentions.users.first() || message.author;
    const seed = (user.id + '___gay').split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    const percent = seed % 101;
    const bar = '🏳️‍🌈'.repeat(Math.ceil(percent / 10));
    message.reply({ embeds: [Embed.custom({ title: `🏳️‍🌈 Gay Rate — ${user.username}`, description: `${bar}\n\n**${percent}%** gay!`, footer: { text: 'Just for fun!' } })] });
  }
};
