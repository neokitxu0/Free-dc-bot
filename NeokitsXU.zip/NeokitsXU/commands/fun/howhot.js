const Embed = require('../../utils/Embed');

module.exports = {
  name: 'howhot',
  description: 'Check how hot someone is',
  usage: 'howhot [@user]',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const user = message.mentions.users.first() || message.author;
    const seed = (user.id + Math.floor(Date.now() / 86400000)).split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    const percent = seed % 101;
    const bar = '🔥'.repeat(Math.floor(percent / 10)) + '💧'.repeat(10 - Math.floor(percent / 10));
    const rating = percent >= 90 ? 'On fire 🔥' : percent >= 70 ? 'Very hot 😍' : percent >= 50 ? 'Pretty hot 😊' : percent >= 30 ? 'Average 😐' : 'Ice cold 🧊';
    message.reply({ embeds: [Embed.custom({ title: `🌡️ How Hot — ${user.username}`, description: `${bar}\n\n**${percent}%** — ${rating}` })] });
  }
};
