const Embed = require('../../utils/Embed');

module.exports = {
  name: 'iq',
  description: 'Check your IQ (not scientifically accurate)',
  usage: 'iq [@user]',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const user = message.mentions.users.first() || message.author;
    const seed = (user.id + Math.floor(Date.now() / 86400000)).toString().split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    const iq = (seed % 201) + 50;
    const comment = iq >= 200 ? "Literally omniscient 🧠" : iq >= 150 ? "Genius 🎓" : iq >= 120 ? "Above average 📚" : iq >= 100 ? "Average 😊" : iq >= 80 ? "Below average 🤔" : "Potato brain 🥔";
    message.reply({ embeds: [Embed.custom({ title: `🧠 IQ Test — ${user.username}`, description: `**IQ: ${iq}**\n${comment}` })] });
  }
};
