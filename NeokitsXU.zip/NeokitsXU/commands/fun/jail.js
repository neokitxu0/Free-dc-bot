const Embed = require('../../utils/Embed');

module.exports = {
  name: 'jail',
  description: 'Put someone in jail',
  usage: 'jail [@user]',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const user = message.mentions.users.first() || message.author;
    message.reply({ embeds: [Embed.custom({
      title: '🚔 ARRESTED',
      description: `**${user.tag}** has been sent to jail!\n\n\`\`\`\n🔒 |   USER   | 🔒\n   | ${user.username.slice(0,8).padEnd(8)} |\n   +---------+\n\`\`\``,
      thumbnail: user.displayAvatarURL({ dynamic: true }),
      color: '#808080',
      footer: { text: 'Bail set at 1,000 coins' }
    })] });
  }
};
