const Embed = require('../../utils/Embed');

const jokes = [
  { setup: "Why don't scientists trust atoms?", punchline: "Because they make up everything!" },
  { setup: "I told my wife she was drawing her eyebrows too high.", punchline: "She looked surprised." },
  { setup: "Why can't a nose be 12 inches long?", punchline: "Because then it would be a foot!" },
  { setup: "What do you call fake spaghetti?", punchline: "An impasta!" },
  { setup: "Why did the scarecrow win an award?", punchline: "Because he was outstanding in his field!" },
  { setup: "I'm reading a book on anti-gravity.", punchline: "It's impossible to put down!" },
  { setup: "Why do cows wear bells?", punchline: "Because their horns don't work!" },
  { setup: "What do you call a bear with no teeth?", punchline: "A gummy bear!" },
  { setup: "Why did the bicycle fall over?", punchline: "Because it was two-tired!" },
  { setup: "What did the ocean say to the beach?", punchline: "Nothing, it just waved!" },
];

module.exports = {
  name: 'joke',
  description: 'Get a random joke',
  usage: 'joke',
  category: 'fun',
  cooldown: 5,
  async execute(client, message) {
    const joke = jokes[Math.floor(Math.random() * jokes.length)];
    message.reply({ embeds: [Embed.custom({ title: '😂 Joke', description: `**${joke.setup}**\n\n||${joke.punchline}||` })] });
  }
};
