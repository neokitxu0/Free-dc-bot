const Embed = require('../../utils/Embed');

module.exports = {
  name: 'luck',
  description: 'Check your luck today',
  usage: 'luck [@user]',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const user = message.mentions.users.first() || message.author;
    const seed = (user.id + Math.floor(Date.now() / 86400000)).split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    const percent = seed % 101;
    const emoji = percent >= 80 ? '🍀' : percent >= 60 ? '✨' : percent >= 40 ? '😊' : percent >= 20 ? '😬' : '🤡';
    const comment = percent >= 80 ? 'Extremely lucky!' : percent >= 60 ? 'Pretty lucky!' : percent >= 40 ? 'Average luck.' : percent >= 20 ? 'Unlucky day...' : 'Stay home today.';
    message.reply({ embeds: [Embed.custom({ title: `${emoji} Luck — ${user.username}`, description: `**${percent}% lucky** today!\n${comment}` })] });
  }
};
