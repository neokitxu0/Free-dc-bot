const Embed = require('../../utils/Embed');

const memes = [
  { title: "One Does Not Simply", url: "https://i.imgflip.com/1bij.jpg" },
  { title: "Drake Approves", url: "https://i.imgflip.com/30b1gx.jpg" },
  { title: "Distracted Boyfriend", url: "https://i.imgflip.com/1ur9b0.jpg" },
  { title: "This Is Fine", url: "https://i.imgflip.com/wxica.jpg" },
  { title: "Success Kid", url: "https://i.imgflip.com/1bhw.jpg" },
  { title: "First World Problems", url: "https://i.imgflip.com/1bip.jpg" },
  { title: "Hide the Pain Harold", url: "https://i.imgflip.com/gk5el.jpg" },
  { title: "Change My Mind", url: "https://i.imgflip.com/24y43o.jpg" },
];

module.exports = {
  name: 'meme',
  description: 'Get a random meme',
  usage: 'meme',
  category: 'fun',
  cooldown: 5,
  async execute(client, message) {
    const meme = memes[Math.floor(Math.random() * memes.length)];
    message.reply({ embeds: [Embed.custom({ title: meme.title, image: meme.url })] });
  }
};
