const Embed = require('../../utils/Embed');

module.exports = {
  name: 'mock',
  description: 'MoCk TeXt LiKe A sPoNgEbOb MeMe',
  usage: 'mock <text>',
  category: 'fun',
  cooldown: 3,
  async execute(client, message, args) {
    const text = args.join(' ');
    if (!text) return message.reply({ embeds: [Embed.error('Missing Text', 'Provide text to mock.')] });
    const mocked = text.split('').map((c, i) => i % 2 === 0 ? c.toLowerCase() : c.toUpperCase()).join('');
    message.reply({ embeds: [Embed.custom({ title: '🧽 mOcK', description: mocked })] });
  }
};
