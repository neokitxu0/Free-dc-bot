const Embed = require('../../utils/Embed');

const prizes = [
  { name: '🏆 JACKPOT!', desc: 'You found the jackpot! 10,000 coins!', coins: 10000, rarity: 'Legendary' },
  { name: '💎 Diamond', desc: 'A rare diamond! 5,000 coins!', coins: 5000, rarity: 'Epic' },
  { name: '🥇 Gold Bar', desc: 'A shiny gold bar! 2,000 coins!', coins: 2000, rarity: 'Rare' },
  { name: '🎁 Gift Box', desc: 'A nice gift! 500 coins!', coins: 500, rarity: 'Common' },
  { name: '🪨 A Rock', desc: 'Just a plain rock...', coins: 1, rarity: 'Trash' },
  { name: '💀 Empty', desc: 'Nothing inside. Better luck next time!', coins: 0, rarity: 'Empty' },
];

module.exports = {
  name: 'mysterybox',
  description: 'Open a mystery box for a random prize',
  usage: 'mysterybox',
  category: 'fun',
  cooldown: 30,
  async execute(client, message) {
    const weights = [1, 3, 7, 20, 35, 34];
    const total = weights.reduce((a, b) => a + b, 0);
    let rand = Math.random() * total;
    let prize;
    for (let i = 0; i < prizes.length; i++) {
      rand -= weights[i];
      if (rand <= 0) { prize = prizes[i]; break; }
    }
    prize = prize || prizes[prizes.length - 1];
    message.reply({ embeds: [Embed.custom({
      title: `📦 Mystery Box — ${prize.name}`,
      description: `${prize.desc}\n\n**Rarity:** ${prize.rarity}${prize.coins > 0 ? `\n**Coins:** +${prize.coins}` : ''}`,
      color: prize.rarity === 'Legendary' ? '#FFD700' : prize.rarity === 'Epic' ? '#9B59B6' : prize.rarity === 'Rare' ? '#3498DB' : '#95A5A6'
    })] });
  }
};
