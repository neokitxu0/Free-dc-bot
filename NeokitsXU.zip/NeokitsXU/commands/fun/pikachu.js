const Embed = require('../../utils/Embed');

module.exports = {
  name: 'pikachu',
  description: 'Pika pika!',
  usage: 'pikachu',
  category: 'fun',
  cooldown: 5,
  async execute(client, message) {
    message.reply({ embeds: [Embed.custom({
      title: '⚡ Pikachu!',
      description: '```\n   (\\(\\  \n   (•.•) \n  o_(\")(\")\n```\n**Pika Pika!** ⚡',
      image: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png',
      color: '#FFD700'
    })] });
  }
};
