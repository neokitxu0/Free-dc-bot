const Embed = require('../../utils/Embed');

const quotes = [
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
  { text: "In the middle of every difficulty lies opportunity.", author: "Albert Einstein" },
  { text: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius" },
  { text: "Life is what happens when you're busy making other plans.", author: "John Lennon" },
  { text: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt" },
  { text: "Spread love everywhere you go. Let no one ever come to you without leaving happier.", author: "Mother Teresa" },
  { text: "When you reach the end of your rope, tie a knot in it and hang on.", author: "Franklin D. Roosevelt" },
  { text: "Always remember that you are absolutely unique. Just like everyone else.", author: "Margaret Mead" },
  { text: "Don't judge each day by the harvest you reap but by the seeds that you plant.", author: "Robert Louis Stevenson" },
  { text: "In the end, it's not the years in your life that count. It's the life in your years.", author: "Abraham Lincoln" },
];

module.exports = {
  name: 'quote',
  description: 'Get a random inspirational quote',
  usage: 'quote',
  category: 'fun',
  cooldown: 5,
  async execute(client, message) {
    const q = quotes[Math.floor(Math.random() * quotes.length)];
    message.reply({ embeds: [Embed.custom({ title: '💬 Quote', description: `*"${q.text}"*\n\n— **${q.author}**`, color: '#5865F2' })] });
  }
};
