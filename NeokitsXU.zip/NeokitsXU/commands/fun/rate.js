const Embed = require('../../utils/Embed');

module.exports = {
  name: 'rate',
  description: 'Rate anything out of 10',
  usage: 'rate <thing>',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const thing = args.join(' ') || 'nothing';
    const seed = thing.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    const rating = seed % 11;
    const bar = '⭐'.repeat(rating) + '☆'.repeat(10 - rating);
    const comment = rating === 10 ? 'Perfect!' : rating >= 7 ? 'Pretty good!' : rating >= 4 ? 'Mediocre.' : 'Yikes.';
    message.reply({ embeds: [Embed.custom({ title: `⭐ Rating — ${thing}`, description: `${bar}\n\n**${rating}/10** — ${comment}` })] });
  }
};
