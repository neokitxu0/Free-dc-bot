const Embed = require('../../utils/Embed');

module.exports = {
  name: 'reverse',
  description: 'Reverse a piece of text',
  usage: 'reverse <text>',
  category: 'fun',
  cooldown: 3,
  async execute(client, message, args) {
    const text = args.join(' ');
    if (!text) return message.reply({ embeds: [Embed.error('Missing Text', 'Provide text to reverse.')] });
    const reversed = text.split('').reverse().join('');
    message.reply({ embeds: [Embed.custom({ title: '🔄 Reversed', description: `**Input:** ${text}\n**Output:** ${reversed}` })] });
  }
};
