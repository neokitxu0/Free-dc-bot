const Embed = require('../../utils/Embed');

module.exports = {
  name: 'rickroll',
  description: 'Rickroll someone',
  usage: 'rickroll [@user]',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.users.first();
    const intro = target ? `${target}, ` : '';
    message.reply({ embeds: [Embed.custom({
      title: '🎵 Special Video For You!',
      description: `${intro}You got rickrolled!\n\nhttps://www.youtube.com/watch?v=dQw4w9WgXcQ`,
      color: '#FF0000'
    })] });
  }
};
