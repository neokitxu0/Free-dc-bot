const Embed = require('../../utils/Embed');

const roasts = [
  "You're the reason they put instructions on shampoo.",
  "I'd roast you, but my mom said I'm not allowed to burn trash.",
  "You're like a cloud — when you disappear, it's a beautiful day.",
  "I'd call you a tool, but they're actually useful.",
  "You're not stupid; you just have bad luck thinking.",
  "You have the right to remain silent because whatever you say will probably be stupid.",
  "I thought of you today. It reminded me to take out the trash.",
  "Your secrets are always safe with me. I never even listen when you tell me them.",
  "You're a gray sprinkle on a rainbow cupcake.",
  "I was going to give you a nasty look but I see you already have one.",
];

module.exports = {
  name: 'roast',
  description: 'Roast a user',
  usage: 'roast [@user]',
  category: 'fun',
  cooldown: 10,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.member;
    const roast = roasts[Math.floor(Math.random() * roasts.length)];
    message.reply({ embeds: [Embed.custom({ title: `🔥 Roast — ${target.user.username}`, description: roast, footer: { text: 'All in good fun!' } })] });
  }
};
