const Embed = require('../../utils/Embed');

module.exports = {
  name: 'ship',
  description: 'Ship two users and calculate compatibility',
  usage: 'ship <@user1> [@user2]',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const user1 = message.mentions.users.first() || message.author;
    const user2 = message.mentions.users.at(1) || (message.mentions.users.size < 2 ? message.author : null);
    if (!user1 || !user2 || user1.id === user2.id) return message.reply({ embeds: [Embed.error('Invalid', 'Mention two different users to ship!')] });
    const seed = (user1.id + user2.id).split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    const percent = seed % 101;
    const bar = '█'.repeat(Math.floor(percent / 10)) + '░'.repeat(10 - Math.floor(percent / 10));
    const emoji = percent >= 80 ? '💞' : percent >= 50 ? '💕' : percent >= 30 ? '💔' : '💀';
    const shipName = user1.username.slice(0, Math.ceil(user1.username.length / 2)) + user2.username.slice(Math.floor(user2.username.length / 2));
    message.reply({ embeds: [Embed.custom({
      title: `${emoji} Ship — ${shipName}`,
      description: `**${user1.tag}** ❤️ **${user2.tag}**\n\n\`[${bar}]\` **${percent}%**`
    })] });
  }
};
