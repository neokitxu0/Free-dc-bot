const Embed = require('../../utils/Embed');

module.exports = {
  name: 'simprate',
  description: 'Check how much of a simp someone is',
  usage: 'simprate [@user]',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const user = message.mentions.users.first() || message.author;
    const seed = (user.id + 'simp').split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    const percent = seed % 101;
    const rating = percent >= 90 ? 'Ultra Simp 💀' : percent >= 70 ? 'Certified Simp 👀' : percent >= 50 ? 'Mild Simp 😅' : percent >= 30 ? 'Barely a Simp 😌' : 'Not a Simp! 😎';
    message.reply({ embeds: [Embed.custom({ title: `💘 Simp Rate — ${user.username}`, description: `**${percent}%** simp\n${rating}`, footer: { text: 'Just for fun!' } })] });
  }
};
