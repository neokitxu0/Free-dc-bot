const Embed = require('../../utils/Embed');

const truths = [
  "What's the most embarrassing thing you've done in public?",
  "What's your biggest fear?",
  "Have you ever lied to your best friend?",
  "What's the worst thing you've ever done?",
  "What's your most embarrassing crush?",
  "Have you ever cheated on a test?",
  "What's your biggest regret?",
  "Have you ever talked bad about someone in this server?",
  "What's the most childish thing you still do?",
  "What's a secret you've never told anyone?",
];

module.exports = {
  name: 'truth',
  description: 'Get a random truth question',
  usage: 'truth',
  category: 'fun',
  cooldown: 5,
  async execute(client, message) {
    const t = truths[Math.floor(Math.random() * truths.length)];
    message.reply({ embeds: [Embed.custom({ title: '🤍 Truth', description: t, color: '#00CED1' })] });
  }
};
