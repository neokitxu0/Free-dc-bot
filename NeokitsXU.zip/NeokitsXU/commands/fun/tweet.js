const Embed = require('../../utils/Embed');

module.exports = {
  name: 'tweet',
  description: 'Fake tweet generator',
  usage: 'tweet [@user] <text>',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const user = message.mentions.users.first() || message.author;
    const text = message.mentions.users.size ? args.slice(1).join(' ') : args.join(' ');
    if (!text) return message.reply({ embeds: [Embed.error('Missing Text', 'Provide text for the tweet.')] });
    const likes = Math.floor(Math.random() * 100000);
    const rts = Math.floor(Math.random() * 50000);
    message.reply({ embeds: [Embed.custom({
      title: `🐦 ${user.username} on Twitter/X`,
      description: `${text}\n\n❤️ **${likes.toLocaleString()}** likes  🔁 **${rts.toLocaleString()}** retweets`,
      thumbnail: user.displayAvatarURL({ dynamic: true }),
      footer: { text: `@${user.username.toLowerCase().replace(/\s/g, '_')} · just now` },
      color: '#1DA1F2'
    })] });
  }
};
