const Embed = require('../../utils/Embed');

module.exports = {
  name: 'wanted',
  description: 'Create a wanted poster for a user',
  usage: 'wanted [@user]',
  category: 'fun',
  cooldown: 5,
  async execute(client, message, args) {
    const user = message.mentions.users.first() || message.author;
    const bounty = Math.floor(Math.random() * 10000000) + 100000;
    message.reply({ embeds: [Embed.custom({
      title: '🤠 WANTED',
      description: `**${user.tag}**\n\nDead or Alive\n\n💰 **Bounty: ${bounty.toLocaleString()} Berries**`,
      thumbnail: user.displayAvatarURL({ dynamic: true }),
      color: '#8B4513',
      footer: { text: 'Issued by the Marines' }
    })] });
  }
};
