const Embed = require('../../utils/Embed');

const wyr = [
  ["fight 1 horse-sized duck", "fight 100 duck-sized horses"],
  ["always be 10 minutes late", "always be 20 minutes early"],
  ["lose all your memories", "never be able to make new ones"],
  ["speak every language", "play every instrument"],
  ["have no internet for a month", "no music for a year"],
  ["always feel too hot", "always feel too cold"],
  ["be invisible", "be able to fly"],
  ["only eat sweet food", "only eat salty food"],
  ["have a rewind button for your life", "a pause button"],
  ["be the most popular person in school", "be the smartest person in school"],
];

module.exports = {
  name: 'wouldyourather',
  aliases: ['wyr'],
  description: 'Would you rather question',
  usage: 'wouldyourather',
  category: 'fun',
  cooldown: 5,
  async execute(client, message) {
    const q = wyr[Math.floor(Math.random() * wyr.length)];
    const m = await message.reply({ embeds: [Embed.custom({ title: '🤔 Would You Rather...', description: `🅰️ **${q[0]}**\n\n— or —\n\n🅱️ **${q[1]}**` })] });
    await m.react('🅰️');
    await m.react('🅱️');
  }
};
