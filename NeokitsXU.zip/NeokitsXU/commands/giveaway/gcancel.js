const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'gcancel',
  description: 'Cancel a giveaway without picking winners',
  usage: 'gcancel <id>',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 5,
  async execute(client, message, args) {
    const id = args[0];
    if (!id) return message.reply({ embeds: [Embed.error('Usage', 'gcancel <id>')] });
    const giveaways = DataManager.get('giveaways', message.guild.id, []);
    const gi = giveaways.findIndex(g => g.id === id && g.status === 'active');
    if (gi === -1) return message.reply({ embeds: [Embed.error('Not Found', `Active giveaway \`${id}\` not found.`)] });
    giveaways[gi].status = 'cancelled';
    DataManager.set('giveaways', message.guild.id, giveaways);
    const channel = message.guild.channels.cache.get(giveaways[gi].channelId);
    const msg = channel ? await channel.messages.fetch(giveaways[gi].messageId).catch(() => null) : null;
    if (msg) await msg.edit({ embeds: [Embed.custom({ title: `❌ GIVEAWAY CANCELLED — ${giveaways[gi].prize}`, description: 'This giveaway has been cancelled.', color: '#808080' })] });
    message.reply({ embeds: [Embed.success('Cancelled', `Giveaway \`${id}\` has been cancelled.`)] });
  }
};
