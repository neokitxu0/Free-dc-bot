const Embed = require('../../utils/Embed');

module.exports = {
  name: 'gcreate',
  description: 'Interactive giveaway creation wizard',
  usage: 'gcreate',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 15,
  async execute(client, message) {
    const filter = m => m.author.id === message.author.id;
    const ask = async (q) => {
      await message.channel.send({ embeds: [Embed.info('Giveaway Wizard', q)] });
      const col = await message.channel.awaitMessages({ filter, max: 1, time: 30000 }).catch(() => null);
      return col?.first()?.content;
    };
    const prize = await ask('What is the **prize**?');
    if (!prize) return message.channel.send({ embeds: [Embed.error('Timed Out', 'Giveaway creation cancelled.')] });
    const durationStr = await ask('How long should the giveaway last? (e.g. `1h`, `30m`, `2d`)');
    if (!durationStr) return message.channel.send({ embeds: [Embed.error('Timed Out', 'Giveaway creation cancelled.')] });
    const winnersStr = await ask('How many winners? (1-20)');
    if (!winnersStr) return message.channel.send({ embeds: [Embed.error('Timed Out', 'Giveaway creation cancelled.')] });
    const fakeArgs = [durationStr, winnersStr, prize];
    const gstart = client.commands.get('gstart');
    if (gstart) await gstart.execute(client, message, fakeArgs);
  }
};
