const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'gdelete',
  description: 'Delete a giveaway',
  usage: 'gdelete <id>',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 5,
  async execute(client, message, args) {
    const id = args[0];
    if (!id) return message.reply({ embeds: [Embed.error('Usage', 'gdelete <id>')] });
    const giveaways = DataManager.get('giveaways', message.guild.id, []);
    const idx = giveaways.findIndex(g => g.id === id);
    if (idx === -1) return message.reply({ embeds: [Embed.error('Not Found', `Giveaway \`${id}\` not found.`)] });
    giveaways.splice(idx, 1);
    DataManager.set('giveaways', message.guild.id, giveaways);
    message.reply({ embeds: [Embed.success('Deleted', `Giveaway \`${id}\` has been deleted.`)] });
  }
};
