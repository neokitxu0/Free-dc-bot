const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');
const ms = require('ms');

module.exports = {
  name: 'gedit',
  description: 'Edit a giveaway',
  usage: 'gedit <id> <winners|prize|duration> <value>',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 5,
  async execute(client, message, args) {
    const id = args[0], field = args[1]?.toLowerCase(), value = args.slice(2).join(' ');
    if (!id || !field || !value) return message.reply({ embeds: [Embed.error('Usage', 'gedit <id> <winners|prize|duration> <value>')] });
    const giveaways = DataManager.get('giveaways', message.guild.id, []);
    const gi = giveaways.findIndex(g => g.id === id && g.status === 'active');
    if (gi === -1) return message.reply({ embeds: [Embed.error('Not Found', `Active giveaway \`${id}\` not found.`)] });
    if (field === 'winners') { const w = parseInt(value); if (!w || w < 1) return message.reply({ embeds: [Embed.error('Invalid', 'Winners must be a positive number.')] }); giveaways[gi].winners = w; }
    else if (field === 'prize') { giveaways[gi].prize = value; }
    else if (field === 'duration') { const d = ms(value); if (!d) return message.reply({ embeds: [Embed.error('Invalid', 'Provide a valid duration.')] }); giveaways[gi].endsAt = Date.now() + d; }
    else return message.reply({ embeds: [Embed.error('Unknown Field', 'Fields: `winners`, `prize`, `duration`.')] });
    DataManager.set('giveaways', message.guild.id, giveaways);
    message.reply({ embeds: [Embed.success('Edited', `Giveaway \`${id}\` **${field}** updated to **${value}**.`)] });
  }
};
