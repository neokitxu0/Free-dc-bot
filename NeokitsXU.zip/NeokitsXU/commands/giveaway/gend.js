const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'gend',
  description: 'End a giveaway early',
  usage: 'gend <id>',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 5,
  async execute(client, message, args) {
    const id = args[0];
    if (!id) return message.reply({ embeds: [Embed.error('Usage', 'gend <giveawayID>')] });
    const giveaways = DataManager.get('giveaways', message.guild.id, []);
    const gi = giveaways.findIndex(g => g.id === id && g.status === 'active');
    if (gi === -1) return message.reply({ embeds: [Embed.error('Not Found', `Active giveaway \`${id}\` not found.`)] });
    const g = giveaways[gi];
    const channel = message.guild.channels.cache.get(g.channelId);
    const msg = channel ? await channel.messages.fetch(g.messageId).catch(() => null) : null;
    if (msg) {
      const reaction = msg.reactions.cache.get('🎉');
      const users = await reaction?.users.fetch();
      const entries = [...(users?.values() || [])].filter(u => !u.bot);
      const pool = [...entries];
      const winnerList = [];
      for (let i = 0; i < Math.min(g.winners, pool.length); i++) {
        const idx = Math.floor(Math.random() * pool.length);
        winnerList.push(pool.splice(idx, 1)[0]);
      }
      const winnerStr = winnerList.length ? winnerList.map(u => u.toString()).join(', ') : 'No entries';
      await msg.edit({ embeds: [Embed.custom({ title: `🎉 GIVEAWAY ENDED — ${g.prize}`, description: `Winners: ${winnerStr}\nHosted by: <@${g.hostId}>`, color: '#FF73FA' })] });
      channel.send({ content: `🎉 Giveaway ended early! Winners: ${winnerStr}` });
    }
    giveaways[gi].status = 'ended';
    DataManager.set('giveaways', message.guild.id, giveaways);
    message.reply({ embeds: [Embed.success('Giveaway Ended', `Giveaway \`${id}\` has been ended.`)] });
  }
};
