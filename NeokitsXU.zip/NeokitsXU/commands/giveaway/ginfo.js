const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'ginfo',
  description: 'Get info about a specific giveaway',
  usage: 'ginfo <id>',
  category: 'giveaway',
  cooldown: 5,
  async execute(client, message, args) {
    const id = args[0];
    if (!id) return message.reply({ embeds: [Embed.error('Usage', 'ginfo <id>')] });
    const g = DataManager.get('giveaways', message.guild.id, []).find(x => x.id === id);
    if (!g) return message.reply({ embeds: [Embed.error('Not Found', `Giveaway \`${id}\` not found.`)] });
    message.reply({ embeds: [Embed.custom({
      title: `🎉 Giveaway Info — ${g.prize}`,
      fields: [
        { name: 'ID', value: g.id, inline: true },
        { name: 'Status', value: g.status.toUpperCase(), inline: true },
        { name: 'Winners', value: `${g.winners}`, inline: true },
        { name: 'Host', value: `<@${g.hostId}>`, inline: true },
        { name: 'Ends/Ended', value: `<t:${Math.floor(g.endsAt / 1000)}:R>`, inline: true },
        ...(g.winnerIds ? [{ name: 'Winners', value: g.winnerIds.map(id => `<@${id}>`).join(', ') }] : [])
      ]
    })] });
  }
};
