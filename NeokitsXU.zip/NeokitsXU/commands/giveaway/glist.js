const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'glist',
  description: 'List all active giveaways',
  usage: 'glist',
  category: 'giveaway',
  cooldown: 5,
  async execute(client, message) {
    const giveaways = DataManager.get('giveaways', message.guild.id, []);
    const active = giveaways.filter(g => g.status === 'active');
    if (!active.length) return message.reply({ embeds: [Embed.info('No Giveaways', 'No active giveaways.')] });
    const fields = active.map(g => ({
      name: `${g.prize} [${g.id}]`,
      value: `Winners: **${g.winners}** | Ends: <t:${Math.floor(g.endsAt / 1000)}:R>`,
      inline: false
    }));
    message.reply({ embeds: [Embed.custom({ title: `🎉 Active Giveaways — ${message.guild.name}`, fields })] });
  }
};
