const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');
const ms = require('ms');
const { v4: uuidv4 } = require('uuid');

module.exports = {
  name: 'gmulti',
  description: 'Start multiple giveaways at once',
  usage: 'gmulti <count> <duration> <winners> <prize>',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 30,
  async execute(client, message, args) {
    const count = parseInt(args[0]);
    const duration = ms(args[1]);
    const winners = parseInt(args[2]);
    const prize = args.slice(3).join(' ');
    if (!count || count < 2 || count > 5 || !duration || !winners || !prize) {
      return message.reply({ embeds: [Embed.error('Usage', 'gmulti <count 2-5> <duration> <winners> <prize>')] });
    }
    const gstart = client.commands.get('gstart');
    let started = 0;
    for (let i = 0; i < count; i++) {
      await gstart?.execute(client, message, [args[1], args[2], prize]).catch(() => {});
      started++;
    }
    message.reply({ embeds: [Embed.success('Multi-Giveaway', `Started **${started}** giveaways for **${prize}**!`)] });
  }
};
