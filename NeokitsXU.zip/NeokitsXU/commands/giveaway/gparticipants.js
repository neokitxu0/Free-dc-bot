const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'gparticipants',
  description: 'List participants of a giveaway',
  usage: 'gparticipants <id>',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 10,
  async execute(client, message, args) {
    const id = args[0];
    if (!id) return message.reply({ embeds: [Embed.error('Usage', 'gparticipants <id>')] });
    const g = DataManager.get('giveaways', message.guild.id, []).find(x => x.id === id);
    if (!g) return message.reply({ embeds: [Embed.error('Not Found', `Giveaway \`${id}\` not found.`)] });
    const channel = message.guild.channels.cache.get(g.channelId);
    if (!channel) return message.reply({ embeds: [Embed.error('No Channel', 'Channel not found.')] });
    const msg = await channel.messages.fetch(g.messageId).catch(() => null);
    if (!msg) return message.reply({ embeds: [Embed.error('No Message', 'Message not found.')] });
    const reaction = msg.reactions.cache.get('🎉');
    const users = await reaction?.users.fetch();
    const entries = [...(users?.values() || [])].filter(u => !u.bot);
    if (!entries.length) return message.reply({ embeds: [Embed.info('No Entries', 'No participants yet.')] });
    const desc = entries.slice(0, 30).map(u => u.tag).join('\n') + (entries.length > 30 ? `\n+${entries.length - 30} more` : '');
    message.reply({ embeds: [Embed.custom({ title: `🎉 Participants — ${g.prize} (${entries.length})`, description: desc })] });
  }
};
