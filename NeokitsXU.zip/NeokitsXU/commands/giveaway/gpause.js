const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'gpause',
  description: 'Pause a giveaway',
  usage: 'gpause <id>',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 5,
  async execute(client, message, args) {
    const id = args[0];
    if (!id) return message.reply({ embeds: [Embed.error('Usage', 'gpause <id>')] });
    const giveaways = DataManager.get('giveaways', message.guild.id, []);
    const gi = giveaways.findIndex(g => g.id === id && g.status === 'active');
    if (gi === -1) return message.reply({ embeds: [Embed.error('Not Found', `Active giveaway \`${id}\` not found.`)] });
    giveaways[gi].status = 'paused';
    DataManager.set('giveaways', message.guild.id, giveaways);
    message.reply({ embeds: [Embed.success('Paused', `Giveaway \`${id}\` has been paused.`)] });
  }
};
