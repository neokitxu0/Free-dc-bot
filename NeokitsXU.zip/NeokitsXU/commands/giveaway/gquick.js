const Embed = require('../../utils/Embed');

module.exports = {
  name: 'gquick',
  description: 'Quickly start a 5-minute 1-winner giveaway',
  usage: 'gquick <prize>',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 10,
  async execute(client, message, args) {
    const prize = args.join(' ');
    if (!prize) return message.reply({ embeds: [Embed.error('Usage', 'gquick <prize>')] });
    const fakeArgs = ['5m', '1', ...args];
    const gstart = client.commands.get('gstart');
    if (gstart) await gstart.execute(client, message, fakeArgs);
  }
};
