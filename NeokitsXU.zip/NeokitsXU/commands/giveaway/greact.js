const Embed = require('../../utils/Embed');

module.exports = {
  name: 'greact',
  description: 'Re-add the 🎉 react to a giveaway message',
  usage: 'greact <id>',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 5,
  async execute(client, message, args) {
    const DataManager = require('../../utils/DataManager');
    const id = args[0];
    if (!id) return message.reply({ embeds: [Embed.error('Usage', 'greact <id>')] });
    const g = DataManager.get('giveaways', message.guild.id, []).find(x => x.id === id);
    if (!g) return message.reply({ embeds: [Embed.error('Not Found', `Giveaway \`${id}\` not found.`)] });
    const channel = message.guild.channels.cache.get(g.channelId);
    const msg = channel ? await channel.messages.fetch(g.messageId).catch(() => null) : null;
    if (!msg) return message.reply({ embeds: [Embed.error('No Message', 'Message not found.')] });
    await msg.react('🎉').catch(() => {});
    message.reply({ embeds: [Embed.success('Reacted', `🎉 re-added to the giveaway message.`)] });
  }
};
