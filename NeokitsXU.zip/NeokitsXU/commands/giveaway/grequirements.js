const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'grequirements',
  description: 'Set role requirements for a giveaway',
  usage: 'grequirements <id> <@role>',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 5,
  async execute(client, message, args) {
    const id = args[0];
    const role = message.mentions.roles.first();
    if (!id || !role) return message.reply({ embeds: [Embed.error('Usage', 'grequirements <id> <@role>')] });
    const giveaways = DataManager.get('giveaways', message.guild.id, []);
    const gi = giveaways.findIndex(g => g.id === id);
    if (gi === -1) return message.reply({ embeds: [Embed.error('Not Found', `Giveaway \`${id}\` not found.`)] });
    giveaways[gi].requireRoleId = role.id;
    DataManager.set('giveaways', message.guild.id, giveaways);
    message.reply({ embeds: [Embed.success('Requirement Set', `Giveaway \`${id}\` now requires ${role} to enter.`)] });
  }
};
