const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'greroll',
  description: 'Reroll winners for a giveaway',
  usage: 'greroll <id> [winners]',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 10,
  async execute(client, message, args) {
    const id = args[0];
    const count = parseInt(args[1]) || 1;
    if (!id) return message.reply({ embeds: [Embed.error('Usage', 'greroll <giveawayID> [winners]')] });
    const giveaways = DataManager.get('giveaways', message.guild.id, []);
    const g = giveaways.find(x => x.id === id && x.status === 'ended');
    if (!g) return message.reply({ embeds: [Embed.error('Not Found', `Ended giveaway \`${id}\` not found.`)] });
    const channel = message.guild.channels.cache.get(g.channelId);
    if (!channel) return message.reply({ embeds: [Embed.error('No Channel', 'Could not find the giveaway channel.')] });
    const msg = await channel.messages.fetch(g.messageId).catch(() => null);
    if (!msg) return message.reply({ embeds: [Embed.error('No Message', 'Could not find the giveaway message.')] });
    const reaction = msg.reactions.cache.get('🎉');
    const users = await reaction?.users.fetch();
    const entries = [...(users?.values() || [])].filter(u => !u.bot);
    if (!entries.length) return message.reply({ embeds: [Embed.warn('No Entries', 'No valid entries to reroll from.')] });
    const pool = [...entries];
    const newWinners = [];
    for (let i = 0; i < Math.min(count, pool.length); i++) {
      const idx = Math.floor(Math.random() * pool.length);
      newWinners.push(pool.splice(idx, 1)[0]);
    }
    const str = newWinners.map(u => u.toString()).join(', ');
    channel.send({ content: `🎉 **Reroll!** New winner(s): ${str}` });
    message.reply({ embeds: [Embed.success('Rerolled', `New winner(s): ${str}`)] });
  }
};
