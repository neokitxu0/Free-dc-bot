const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'gresume',
  description: 'Resume a paused giveaway',
  usage: 'gresume <id>',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 5,
  async execute(client, message, args) {
    const id = args[0];
    if (!id) return message.reply({ embeds: [Embed.error('Usage', 'gresume <id>')] });
    const giveaways = DataManager.get('giveaways', message.guild.id, []);
    const gi = giveaways.findIndex(g => g.id === id && g.status === 'paused');
    if (gi === -1) return message.reply({ embeds: [Embed.error('Not Found', `Paused giveaway \`${id}\` not found.`)] });
    giveaways[gi].status = 'active';
    DataManager.set('giveaways', message.guild.id, giveaways);
    message.reply({ embeds: [Embed.success('Resumed', `Giveaway \`${id}\` has been resumed.`)] });
  }
};
