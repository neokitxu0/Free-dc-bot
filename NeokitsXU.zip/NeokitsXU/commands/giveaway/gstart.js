const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');
const ms = require('ms');
const { v4: uuidv4 } = require('uuid');

module.exports = {
  name: 'gstart',
  description: 'Start a giveaway',
  usage: 'gstart <duration> <winners> <prize>',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 10,
  async execute(client, message, args) {
    const duration = ms(args[0]);
    const winners = parseInt(args[1]);
    const prize = args.slice(2).join(' ');
    if (!duration || !winners || winners < 1 || !prize) return message.reply({ embeds: [Embed.error('Usage', 'gstart <duration> <winners> <prize>\nExample: gstart 1h 3 Nitro')] });
    const endsAt = Date.now() + duration;
    const id = uuidv4().slice(0, 8);
    const embed = Embed.custom({
      title: `🎉 GIVEAWAY — ${prize}`,
      description: `React with 🎉 to enter!\n\nWinners: **${winners}**\nEnds: <t:${Math.floor(endsAt / 1000)}:R>\nHosted by: ${message.author}`,
      footer: { text: `ID: ${id} | Ends at` },
      timestamp: new Date(endsAt),
      color: '#FF73FA'
    });
    const m = await message.channel.send({ embeds: [embed] });
    await m.react('🎉');
    const giveaway = { id, messageId: m.id, channelId: message.channel.id, prize, winners, endsAt, hostId: message.author.id, status: 'active', participants: [] };
    const giveaways = DataManager.ensure('giveaways', message.guild.id, []);
    giveaways.push(giveaway);
    DataManager.set('giveaways', message.guild.id, giveaways);
    setTimeout(async () => {
      const g = DataManager.get('giveaways', message.guild.id, []).find(x => x.id === id);
      if (!g || g.status !== 'active') return;
      const channel = message.guild.channels.cache.get(g.channelId);
      if (!channel) return;
      const msg = await channel.messages.fetch(g.messageId).catch(() => null);
      if (!msg) return;
      const reaction = msg.reactions.cache.get('🎉');
      const users = await reaction?.users.fetch();
      const entries = [...(users?.values() || [])].filter(u => !u.bot);
      const winnerList = [];
      const pool = [...entries];
      for (let i = 0; i < Math.min(g.winners, pool.length); i++) {
        const idx = Math.floor(Math.random() * pool.length);
        winnerList.push(pool.splice(idx, 1)[0]);
      }
      const winnerStr = winnerList.length ? winnerList.map(u => u.toString()).join(', ') : 'No valid entries';
      await msg.edit({ embeds: [Embed.custom({ title: `🎉 GIVEAWAY ENDED — ${g.prize}`, description: `Winners: ${winnerStr}\nHosted by: <@${g.hostId}>`, color: '#FF73FA' })] });
      channel.send({ content: `🎉 Congratulations ${winnerStr}! You won **${g.prize}**!` });
      const gws = DataManager.get('giveaways', message.guild.id, []);
      const gi = gws.findIndex(x => x.id === id);
      if (gi !== -1) { gws[gi].status = 'ended'; gws[gi].winnerIds = winnerList.map(u => u.id); DataManager.set('giveaways', message.guild.id, gws); }
    }, duration);
    message.reply({ embeds: [Embed.success('Giveaway Started', `Giveaway for **${prize}** started! ID: \`${id}\``)] }).then(r => setTimeout(() => r.delete().catch(() => {}), 5000));
  }
};
