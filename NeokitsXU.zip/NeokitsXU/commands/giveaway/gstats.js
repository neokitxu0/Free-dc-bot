const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'gstats',
  description: 'View giveaway statistics for the server',
  usage: 'gstats',
  category: 'giveaway',
  cooldown: 10,
  async execute(client, message) {
    const giveaways = DataManager.get('giveaways', message.guild.id, []);
    const active = giveaways.filter(g => g.status === 'active').length;
    const ended = giveaways.filter(g => g.status === 'ended').length;
    const paused = giveaways.filter(g => g.status === 'paused').length;
    message.reply({ embeds: [Embed.custom({
      title: `🎉 Giveaway Stats — ${message.guild.name}`,
      fields: [
        { name: 'Total', value: `${giveaways.length}`, inline: true },
        { name: 'Active', value: `${active}`, inline: true },
        { name: 'Ended', value: `${ended}`, inline: true },
        { name: 'Paused', value: `${paused}`, inline: true },
      ]
    })] });
  }
};
