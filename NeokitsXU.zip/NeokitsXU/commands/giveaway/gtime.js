const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');
const ms = require('ms');

module.exports = {
  name: 'gtime',
  description: 'Extend or reduce time on a giveaway',
  usage: 'gtime <id> <+/-time>',
  category: 'giveaway',
  userPermissions: ['ManageGuild'],
  cooldown: 5,
  async execute(client, message, args) {
    const id = args[0];
    const timeStr = args[1];
    if (!id || !timeStr) return message.reply({ embeds: [Embed.error('Usage', 'gtime <id> <+10m or -5m>')] });
    const add = timeStr.startsWith('+');
    const subtract = timeStr.startsWith('-');
    const duration = ms(timeStr.replace(/^[+-]/, ''));
    if (!duration) return message.reply({ embeds: [Embed.error('Invalid Time', 'Use format like +10m or -5m.')] });
    const giveaways = DataManager.get('giveaways', message.guild.id, []);
    const gi = giveaways.findIndex(g => g.id === id && g.status === 'active');
    if (gi === -1) return message.reply({ embeds: [Embed.error('Not Found', `Active giveaway \`${id}\` not found.`)] });
    if (add) giveaways[gi].endsAt += duration;
    else if (subtract) giveaways[gi].endsAt = Math.max(Date.now() + 5000, giveaways[gi].endsAt - duration);
    else giveaways[gi].endsAt += duration;
    DataManager.set('giveaways', message.guild.id, giveaways);
    message.reply({ embeds: [Embed.success('Time Updated', `Giveaway \`${id}\` now ends <t:${Math.floor(giveaways[gi].endsAt / 1000)}:R>.`)] });
  }
};
