const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'gtop',
  description: 'Top giveaway winners in this server',
  usage: 'gtop',
  category: 'giveaway',
  cooldown: 10,
  async execute(client, message) {
    const giveaways = DataManager.get('giveaways', message.guild.id, []).filter(g => g.status === 'ended' && g.winnerIds);
    if (!giveaways.length) return message.reply({ embeds: [Embed.info('No Data', 'No ended giveaways yet.')] });
    const counts = {};
    for (const g of giveaways) for (const id of (g.winnerIds || [])) counts[id] = (counts[id] || 0) + 1;
    const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 10);
    const medals = ['🥇','🥈','🥉'];
    const desc = sorted.map(([id, c], i) => `${medals[i] || `**${i+1}.**`} <@${id}> — **${c}** win(s)`).join('\n');
    message.reply({ embeds: [Embed.custom({ title: `🎉 Top Giveaway Winners — ${message.guild.name}`, description: desc })] });
  }
};
