const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'gwinner',
  description: 'View winners of an ended giveaway',
  usage: 'gwinner <id>',
  category: 'giveaway',
  cooldown: 5,
  async execute(client, message, args) {
    const id = args[0];
    if (!id) return message.reply({ embeds: [Embed.error('Usage', 'gwinner <id>')] });
    const g = DataManager.get('giveaways', message.guild.id, []).find(x => x.id === id && x.status === 'ended');
    if (!g) return message.reply({ embeds: [Embed.error('Not Found', `Ended giveaway \`${id}\` not found.`)] });
    const winners = g.winnerIds?.map(id => `<@${id}>`).join(', ') || 'No winners';
    message.reply({ embeds: [Embed.custom({ title: `🎉 Winners — ${g.prize}`, description: winners })] });
  }
};
