const Embed = require('../../utils/Embed');
const LevelManager = require('../../utils/LevelManager');

module.exports = {
  name: 'addlevel',
  description: 'Add levels to a user',
  usage: 'addlevel <@user> <amount>',
  category: 'leveling',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first();
    const amount = parseInt(args[1]);
    if (!target || !amount || amount <= 0) return message.reply({ embeds: [Embed.error('Usage', 'addlevel <@user> <amount>')] });
    const data = LevelManager.getUser(target.id, message.guild.id);
    data.level = (data.level || 1) + amount;
    data.xp = 0;
    LevelManager.setUser(target.id, message.guild.id, data);
    message.reply({ embeds: [Embed.success('Level Added', `Added **${amount}** level(s) to **${target.user.tag}**. Now Level **${data.level}**.`)] });
  }
};
