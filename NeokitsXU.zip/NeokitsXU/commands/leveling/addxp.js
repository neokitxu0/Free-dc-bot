const Embed = require('../../utils/Embed');
const LevelManager = require('../../utils/LevelManager');

module.exports = {
  name: 'addxp',
  description: 'Add XP to a user',
  usage: 'addxp <@user> <amount>',
  category: 'leveling',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first();
    const amount = parseInt(args[1]);
    if (!target || !amount || amount <= 0) return message.reply({ embeds: [Embed.error('Usage', 'addxp <@user> <amount>')] });
    const { leveledUp, newLevel } = LevelManager.addXP(target.id, message.guild.id, amount);
    const data = LevelManager.getUser(target.id, message.guild.id);
    let desc = `Added **${amount}** XP to **${target.user.tag}**. Total: **${data.xp}** XP`;
    if (leveledUp) desc += `\n🎉 They leveled up to **Level ${newLevel}**!`;
    message.reply({ embeds: [Embed.success('XP Added', desc)] });
  }
};
