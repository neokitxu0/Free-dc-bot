const Embed = require('../../utils/Embed');
const LevelManager = require('../../utils/LevelManager');

module.exports = {
  name: 'leaderboardxp',
  aliases: ['lbxp', 'levels'],
  description: 'View the XP leaderboard',
  usage: 'leaderboardxp',
  category: 'leveling',
  cooldown: 10,
  async execute(client, message) {
    const all = LevelManager.getAll(message.guild.id);
    const sorted = Object.entries(all).sort((a, b) => (b[1].level || 1) * 10000 + (b[1].xp || 0) - ((a[1].level || 1) * 10000 + (a[1].xp || 0))).slice(0, 10);
    if (!sorted.length) return message.reply({ embeds: [Embed.info('Empty', 'No level data yet.')] });
    const medals = ['🥇', '🥈', '🥉'];
    const desc = sorted.map(([id, d], i) => {
      const user = client.users.cache.get(id);
      return `${medals[i] || `**${i+1}.**`} ${user ? user.tag : `<@${id}>`} — Level **${d.level || 1}** (${d.xp || 0} XP)`;
    }).join('\n');
    message.reply({ embeds: [Embed.custom({ title: `⭐ Level Leaderboard — ${message.guild.name}`, description: desc })] });
  }
};
