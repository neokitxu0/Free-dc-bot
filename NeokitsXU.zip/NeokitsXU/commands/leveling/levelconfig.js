const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'levelconfig',
  description: 'Configure the leveling system',
  usage: 'levelconfig <xprate|announce|channel> <value>',
  category: 'leveling',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const option = args[0]?.toLowerCase();
    const value = args.slice(1).join(' ');
    if (!option || !value) return message.reply({ embeds: [Embed.error('Usage', 'levelconfig <xprate|announce|channel> <value>')] });
    const cfg = DataManager.ensure('levelconfig', message.guild.id, {});
    if (option === 'xprate') {
      const rate = parseFloat(value);
      if (isNaN(rate) || rate <= 0) return message.reply({ embeds: [Embed.error('Invalid', 'XP rate must be a positive number.')] });
      cfg.xpRate = rate;
    } else if (option === 'announce') {
      cfg.announce = value === 'on';
    } else if (option === 'channel') {
      const ch = message.mentions.channels.first();
      if (!ch) return message.reply({ embeds: [Embed.error('Invalid', 'Mention a channel.')] });
      cfg.channelId = ch.id;
    } else {
      return message.reply({ embeds: [Embed.error('Unknown Option', 'Valid options: `xprate`, `announce`, `channel`.')] });
    }
    DataManager.set('levelconfig', message.guild.id, cfg);
    message.reply({ embeds: [Embed.success('Config Updated', `Set **${option}** to **${value}**.`)] });
  }
};
