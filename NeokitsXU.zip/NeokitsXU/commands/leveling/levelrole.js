const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'levelrole',
  description: 'Set a role reward for reaching a level',
  usage: 'levelrole <level> <@role>',
  category: 'leveling',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const level = parseInt(args[0]);
    const role = message.mentions.roles.first();
    if (!level || level < 1 || !role) return message.reply({ embeds: [Embed.error('Usage', 'levelrole <level> <@role>')] });
    const roles = DataManager.ensure('levelroles', message.guild.id, {});
    roles[level] = role.id;
    DataManager.set('levelroles', message.guild.id, roles);
    message.reply({ embeds: [Embed.success('Level Role Set', `Reaching level **${level}** will now grant ${role}.`)] });
  }
};
