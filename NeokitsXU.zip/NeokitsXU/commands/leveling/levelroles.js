const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'levelroles',
  description: 'View all level roles configured for this server',
  usage: 'levelroles',
  category: 'leveling',
  cooldown: 5,
  async execute(client, message) {
    const roles = DataManager.get('levelroles', message.guild.id, {});
    const entries = Object.entries(roles);
    if (!entries.length) return message.reply({ embeds: [Embed.info('No Level Roles', `No level roles set. Use \`${client.config.prefix}levelrole <level> <@role>\` to add one.`)] });
    const desc = entries.sort((a, b) => a[0] - b[0]).map(([lvl, roleId]) => `Level **${lvl}** → <@&${roleId}>`).join('\n');
    message.reply({ embeds: [Embed.custom({ title: '⭐ Level Roles', description: desc })] });
  }
};
