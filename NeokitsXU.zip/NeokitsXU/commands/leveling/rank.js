const Embed = require('../../utils/Embed');
const LevelManager = require('../../utils/LevelManager');

module.exports = {
  name: 'rank',
  aliases: ['level', 'xprank'],
  description: 'Check your or someone\'s rank',
  usage: 'rank [@user]',
  category: 'leveling',
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.users.first() || message.author;
    const data = LevelManager.getUser(target.id, message.guild.id);
    const level = data.level || 1;
    const xp = data.xp || 0;
    const required = LevelManager.xpRequired(level);
    const percent = Math.floor((xp / required) * 100);
    const bar = '█'.repeat(Math.floor(percent / 10)) + '░'.repeat(10 - Math.floor(percent / 10));
    const allUsers = LevelManager.getAll(message.guild.id);
    const sorted = Object.entries(allUsers).sort((a, b) => (b[1].level || 1) * 1000 + (b[1].xp || 0) - ((a[1].level || 1) * 1000 + (a[1].xp || 0)));
    const pos = sorted.findIndex(([id]) => id === target.id) + 1;
    message.reply({ embeds: [Embed.custom({
      title: `⭐ Rank — ${target.username}`,
      thumbnail: target.displayAvatarURL({ dynamic: true }),
      fields: [
        { name: 'Level', value: `${level}`, inline: true },
        { name: 'XP', value: `${xp} / ${required}`, inline: true },
        { name: 'Server Rank', value: `#${pos}`, inline: true },
        { name: 'Progress', value: `\`[${bar}]\` ${percent}%`, inline: false },
      ]
    })] });
  }
};
