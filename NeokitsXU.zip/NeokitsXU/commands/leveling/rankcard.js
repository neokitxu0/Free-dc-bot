const Embed = require('../../utils/Embed');
const LevelManager = require('../../utils/LevelManager');

module.exports = {
  name: 'rankcard',
  description: 'View your rank card embed',
  usage: 'rankcard [@user]',
  category: 'leveling',
  cooldown: 10,
  async execute(client, message, args) {
    const target = message.mentions.users.first() || message.author;
    const data = LevelManager.getUser(target.id, message.guild.id);
    const level = data.level || 1;
    const xp = data.xp || 0;
    const required = LevelManager.xpRequired(level);
    const percent = Math.floor((xp / required) * 100);
    const bar = '▓'.repeat(Math.floor(percent / 5)) + '░'.repeat(20 - Math.floor(percent / 5));
    const allUsers = LevelManager.getAll(message.guild.id);
    const sorted = Object.entries(allUsers).sort((a, b) => (b[1].level || 1) * 10000 + (b[1].xp || 0) - ((a[1].level || 1) * 10000 + (a[1].xp || 0)));
    const rank = sorted.findIndex(([id]) => id === target.id) + 1;
    message.reply({ embeds: [Embed.custom({
      author: { name: target.tag, iconURL: target.displayAvatarURL({ dynamic: true }) },
      fields: [
        { name: '⭐ Level', value: `${level}`, inline: true },
        { name: '📊 Server Rank', value: `#${rank}`, inline: true },
        { name: '✨ XP', value: `${xp} / ${required}`, inline: true },
        { name: 'Progress', value: `\`[${bar}]\` ${percent}%`, inline: false }
      ],
      thumbnail: target.displayAvatarURL({ dynamic: true }),
      color: '#5865F2'
    })] });
  }
};
