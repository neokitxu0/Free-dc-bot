const Embed = require('../../utils/Embed');
const LevelManager = require('../../utils/LevelManager');

module.exports = {
  name: 'removelevel',
  description: 'Remove levels from a user',
  usage: 'removelevel <@user> <amount>',
  category: 'leveling',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first();
    const amount = parseInt(args[1]);
    if (!target || !amount || amount <= 0) return message.reply({ embeds: [Embed.error('Usage', 'removelevel <@user> <amount>')] });
    const data = LevelManager.getUser(target.id, message.guild.id);
    data.level = Math.max(1, (data.level || 1) - amount);
    data.xp = 0;
    LevelManager.setUser(target.id, message.guild.id, data);
    message.reply({ embeds: [Embed.success('Level Removed', `Removed **${amount}** level(s) from **${target.user.tag}**. Now Level **${data.level}**.`)] });
  }
};
