const Embed = require('../../utils/Embed');
const LevelManager = require('../../utils/LevelManager');

module.exports = {
  name: 'removexp',
  description: 'Remove XP from a user',
  usage: 'removexp <@user> <amount>',
  category: 'leveling',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first();
    const amount = parseInt(args[1]);
    if (!target || !amount || amount <= 0) return message.reply({ embeds: [Embed.error('Usage', 'removexp <@user> <amount>')] });
    const data = LevelManager.getUser(target.id, message.guild.id);
    data.xp = Math.max(0, (data.xp || 0) - amount);
    LevelManager.setUser(target.id, message.guild.id, data);
    message.reply({ embeds: [Embed.success('XP Removed', `Removed **${amount}** XP from **${target.user.tag}**. New XP: **${data.xp}**`)] });
  }
};
