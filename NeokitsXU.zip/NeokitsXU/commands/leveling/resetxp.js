const Embed = require('../../utils/Embed');
const LevelManager = require('../../utils/LevelManager');

module.exports = {
  name: 'resetxp',
  description: 'Reset XP and level for a user',
  usage: 'resetxp <@user|all>',
  category: 'leveling',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    if (args[0]?.toLowerCase() === 'all') {
      LevelManager.resetAll(message.guild.id);
      return message.reply({ embeds: [Embed.success('Reset All', 'All XP and levels have been reset for this server.')] });
    }
    const target = message.mentions.members.first();
    if (!target) return message.reply({ embeds: [Embed.error('Usage', 'resetxp <@user|all>')] });
    LevelManager.setUser(target.id, message.guild.id, { level: 1, xp: 0 });
    message.reply({ embeds: [Embed.success('Reset', `Reset XP for **${target.user.tag}**.`)] });
  }
};
