const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'rewards',
  description: 'View all level rewards for this server',
  usage: 'rewards',
  category: 'leveling',
  cooldown: 5,
  async execute(client, message) {
    const roles = DataManager.get('levelroles', message.guild.id, {});
    const entries = Object.entries(roles).sort((a, b) => parseInt(a[0]) - parseInt(b[0]));
    if (!entries.length) return message.reply({ embeds: [Embed.info('No Rewards', 'No level rewards configured.')] });
    const desc = entries.map(([lvl, id]) => `Level **${lvl}** → <@&${id}>`).join('\n');
    message.reply({ embeds: [Embed.custom({ title: '🎁 Level Rewards', description: desc })] });
  }
};
