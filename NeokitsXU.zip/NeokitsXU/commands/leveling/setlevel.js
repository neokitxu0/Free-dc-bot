const Embed = require('../../utils/Embed');
const LevelManager = require('../../utils/LevelManager');

module.exports = {
  name: 'setlevel',
  description: 'Set a user\'s level',
  usage: 'setlevel <@user> <level>',
  category: 'leveling',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first();
    const level = parseInt(args[1]);
    if (!target || !level || level < 1) return message.reply({ embeds: [Embed.error('Usage', 'setlevel <@user> <level>')] });
    const data = LevelManager.getUser(target.id, message.guild.id);
    data.level = level;
    data.xp = 0;
    LevelManager.setUser(target.id, message.guild.id, data);
    message.reply({ embeds: [Embed.success('Level Set', `Set **${target.user.tag}**'s level to **${level}**.`)] });
  }
};
