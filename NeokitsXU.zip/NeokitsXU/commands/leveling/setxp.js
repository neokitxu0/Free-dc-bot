const Embed = require('../../utils/Embed');
const LevelManager = require('../../utils/LevelManager');

module.exports = {
  name: 'setxp',
  description: 'Set XP for a user',
  usage: 'setxp <@user> <amount>',
  category: 'leveling',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first();
    const amount = parseInt(args[1]);
    if (!target || isNaN(amount) || amount < 0) return message.reply({ embeds: [Embed.error('Usage', 'setxp <@user> <amount>')] });
    const data = LevelManager.getUser(target.id, message.guild.id);
    data.xp = amount;
    LevelManager.setUser(target.id, message.guild.id, data);
    message.reply({ embeds: [Embed.success('XP Set', `Set **${target.user.tag}**'s XP to **${amount}**.`)] });
  }
};
