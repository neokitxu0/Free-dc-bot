const Embed = require('../../utils/Embed');
const LevelManager = require('../../utils/LevelManager');

module.exports = {
  name: 'topxp',
  description: 'View top XP earners',
  usage: 'topxp',
  category: 'leveling',
  cooldown: 10,
  async execute(client, message) {
    const all = LevelManager.getAll(message.guild.id);
    const sorted = Object.entries(all).sort((a, b) => (b[1].level || 1) * 10000 + (b[1].xp || 0) - ((a[1].level || 1) * 10000 + (a[1].xp || 0))).slice(0, 10);
    if (!sorted.length) return message.reply({ embeds: [Embed.info('No Data', 'No XP data yet.')] });
    const medals = ['🥇','🥈','🥉'];
    const desc = sorted.map(([id, d], i) => {
      const u = client.users.cache.get(id);
      return `${medals[i] || `**${i+1}.**`} ${u ? u.tag : `<@${id}>`} — Lv.**${d.level || 1}** • ${d.xp || 0} XP`;
    }).join('\n');
    message.reply({ embeds: [Embed.custom({ title: `⭐ Top XP — ${message.guild.name}`, description: desc })] });
  }
};
