const Embed = require('../../utils/Embed');
const LevelManager = require('../../utils/LevelManager');

module.exports = {
  name: 'xp',
  description: 'Check XP for yourself or another user',
  usage: 'xp [@user]',
  category: 'leveling',
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.users.first() || message.author;
    const data = LevelManager.getUser(target.id, message.guild.id);
    const totalXp = ((data.level || 1) - 1) * 1000 + (data.xp || 0);
    message.reply({ embeds: [Embed.info(`⭐ XP — ${target.username}`, `Level: **${data.level || 1}**\nCurrent XP: **${data.xp || 0}** / **${LevelManager.xpRequired(data.level || 1)}**\nTotal XP: **${totalXp}**`)] });
  }
};
