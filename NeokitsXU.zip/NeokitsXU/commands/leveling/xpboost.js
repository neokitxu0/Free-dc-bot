const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');
const ms = require('ms');

module.exports = {
  name: 'xpboost',
  description: 'Set an XP boost for the server',
  usage: 'xpboost <multiplier> <duration>',
  category: 'leveling',
  userPermissions: ['Administrator'],
  cooldown: 10,
  async execute(client, message, args) {
    const mult = parseFloat(args[0]);
    const duration = ms(args[1]);
    if (isNaN(mult) || mult <= 0 || !duration) return message.reply({ embeds: [Embed.error('Usage', 'xpboost <multiplier> <duration>\nExample: xpboost 2 1h')] });
    const endsAt = Date.now() + duration;
    DataManager.set('xpboost', message.guild.id, { multiplier: mult, endsAt });
    message.reply({ embeds: [Embed.success('XP Boost Active', `**${mult}x** XP boost active for **${args[1]}**!\nEnds <t:${Math.floor(endsAt / 1000)}:R>`)] });
  }
};
