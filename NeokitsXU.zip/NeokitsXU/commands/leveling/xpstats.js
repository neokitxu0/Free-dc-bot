const Embed = require('../../utils/Embed');
const LevelManager = require('../../utils/LevelManager');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'xpstats',
  description: 'View server-wide XP statistics',
  usage: 'xpstats',
  category: 'leveling',
  cooldown: 10,
  async execute(client, message) {
    const all = LevelManager.getAll(message.guild.id);
    const entries = Object.values(all);
    if (!entries.length) return message.reply({ embeds: [Embed.info('No Data', 'No XP data yet.')] });
    const totalXP = entries.reduce((a, b) => a + (b.xp || 0), 0);
    const maxLevel = Math.max(...entries.map(e => e.level || 1));
    const avgLevel = (entries.reduce((a, b) => a + (b.level || 1), 0) / entries.length).toFixed(1);
    const boost = DataManager.get('xpboost', message.guild.id, null);
    const boostActive = boost && boost.endsAt > Date.now();
    message.reply({ embeds: [Embed.custom({
      title: `⭐ XP Stats — ${message.guild.name}`,
      fields: [
        { name: 'Total Users', value: `${entries.length}`, inline: true },
        { name: 'Max Level', value: `${maxLevel}`, inline: true },
        { name: 'Average Level', value: `${avgLevel}`, inline: true },
        { name: 'Total XP', value: `${totalXP.toLocaleString()}`, inline: true },
        { name: 'Active Boost', value: boostActive ? `${boost.multiplier}x (ends <t:${Math.floor(boost.endsAt / 1000)}:R>)` : 'None', inline: false }
      ]
    })] });
  }
};
