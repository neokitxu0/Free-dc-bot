const Embed = require('../../utils/Embed');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'xptoggle',
  description: 'Toggle XP gain on or off',
  usage: 'xptoggle <on|off>',
  category: 'leveling',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const toggle = args[0]?.toLowerCase();
    if (!['on', 'off'].includes(toggle)) return message.reply({ embeds: [Embed.error('Usage', 'xptoggle <on|off>')] });
    client.config.xpEnabled = toggle === 'on';
    const cfgPath = path.join(__dirname, '../../config/config.json');
    fs.writeFileSync(cfgPath, JSON.stringify(client.config, null, 2));
    message.reply({ embeds: [Embed.success('XP Toggle', `XP gain is now **${toggle === 'on' ? 'enabled' : 'disabled'}**.`)] });
  }
};
