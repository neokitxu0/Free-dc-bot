const Embed = require('../../utils/Embed');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'antiemoji',
  description: 'Toggle anti-emoji spam (max emojis per message)',
  usage: 'antiemoji <on|off> [maxEmojis]',
  category: 'moderation',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const toggle = args[0]?.toLowerCase();
    if (!['on', 'off'].includes(toggle)) return message.reply({ embeds: [Embed.error('Usage', 'antiemoji <on|off> [maxEmojis]')] });
    client.config.antiEmoji = client.config.antiEmoji || {};
    client.config.antiEmoji.enabled = toggle === 'on';
    if (args[1]) client.config.antiEmoji.max = parseInt(args[1]) || 10;
    const cfgPath = path.join(__dirname, '../../config/config.json');
    fs.writeFileSync(cfgPath, JSON.stringify(client.config, null, 2));
    message.reply({ embeds: [Embed.success('Anti-Emoji', `Anti-emoji spam: **${toggle === 'on' ? 'enabled' : 'disabled'}**\nMax emojis per message: **${client.config.antiEmoji.max || 10}**`)] });
  }
};
