const Embed = require('../../utils/Embed');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'antihoist',
  description: 'Toggle anti-hoist (prevent users from using symbols to appear at top of member list)',
  usage: 'antihoist <on|off>',
  category: 'moderation',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const toggle = args[0]?.toLowerCase();
    if (!['on', 'off'].includes(toggle)) return message.reply({ embeds: [Embed.error('Usage', 'antihoist <on|off>')] });
    client.config.antiHoist = client.config.antiHoist || {};
    client.config.antiHoist.enabled = toggle === 'on';
    const cfgPath = path.join(__dirname, '../../config/config.json');
    fs.writeFileSync(cfgPath, JSON.stringify(client.config, null, 2));
    message.reply({ embeds: [Embed.success('Anti-Hoist', `Anti-hoist is now **${toggle === 'on' ? 'enabled' : 'disabled'}**.\n${toggle === 'on' ? 'Users with hoisting symbols in their names will be renamed.' : ''}`)] });
  }
};
