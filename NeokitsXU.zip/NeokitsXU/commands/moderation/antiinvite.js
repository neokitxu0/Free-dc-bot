const Embed = require('../../utils/Embed');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'antiinvite',
  description: 'Toggle anti-invite system',
  usage: 'antiinvite <on|off>',
  category: 'moderation',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const toggle = args[0]?.toLowerCase();
    if (!['on', 'off'].includes(toggle)) return message.reply({ embeds: [Embed.error('Usage', 'antiinvite <on|off>')] });
    client.config.antiInvite = client.config.antiInvite || {};
    client.config.antiInvite.enabled = toggle === 'on';
    const cfgPath = path.join(__dirname, '../../config/config.json');
    fs.writeFileSync(cfgPath, JSON.stringify(client.config, null, 2));
    message.reply({ embeds: [Embed.success('Anti-Invite', `Anti-invite system is now **${toggle === 'on' ? 'enabled' : 'disabled'}**.`)] });
  }
};
