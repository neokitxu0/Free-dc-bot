const Embed = require('../../utils/Embed');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'antispam',
  description: 'Toggle or configure anti-spam system',
  usage: 'antispam <on|off> [maxMessages] [interval(ms)]',
  category: 'moderation',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const toggle = args[0]?.toLowerCase();
    if (!['on', 'off'].includes(toggle)) return message.reply({ embeds: [Embed.error('Usage', 'antispam <on|off> [maxMessages] [intervalMs]')] });
    client.config.antiSpam = client.config.antiSpam || {};
    client.config.antiSpam.enabled = toggle === 'on';
    if (args[1]) client.config.antiSpam.maxMessages = parseInt(args[1]) || 5;
    if (args[2]) client.config.antiSpam.interval = parseInt(args[2]) || 5000;
    const cfgPath = path.join(__dirname, '../../config/config.json');
    fs.writeFileSync(cfgPath, JSON.stringify(client.config, null, 2));
    message.reply({ embeds: [Embed.success('Anti-Spam', `Anti-spam: **${toggle === 'on' ? 'enabled' : 'disabled'}**\nMax: **${client.config.antiSpam.maxMessages || 5}** msgs / **${client.config.antiSpam.interval || 5000}ms**`)] });
  }
};
