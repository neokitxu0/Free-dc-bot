const Embed = require('../../utils/Embed');

module.exports = {
  name: 'antiwebhook',
  description: 'Scan and delete all unauthorized webhooks in the server',
  usage: 'antiwebhook',
  category: 'moderation',
  userPermissions: ['ManageWebhooks'],
  botPermissions: ['ManageWebhooks'],
  cooldown: 30,
  async execute(client, message) {
    const webhooks = await message.guild.fetchWebhooks().catch(() => null);
    if (!webhooks) return message.reply({ embeds: [Embed.error('Failed', 'Could not fetch webhooks.')] });
    let deleted = 0;
    for (const [, wh] of webhooks) {
      await wh.delete('Anti-Webhook scan').then(() => deleted++).catch(() => {});
    }
    message.reply({ embeds: [Embed.success('Webhooks Cleared', `Deleted **${deleted}** webhook(s) from **${message.guild.name}**.`)] });
  }
};
