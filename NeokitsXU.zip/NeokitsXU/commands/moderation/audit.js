const Embed = require('../../utils/Embed');

module.exports = {
  name: 'audit',
  description: 'View recent audit log entries',
  usage: 'audit [limit]',
  category: 'moderation',
  userPermissions: ['ViewAuditLog'],
  botPermissions: ['ViewAuditLog'],
  cooldown: 10,
  async execute(client, message, args) {
    const limit = Math.min(parseInt(args[0]) || 10, 25);
    const entries = await message.guild.fetchAuditLogs({ limit }).catch(e => null);
    if (!entries) return message.reply({ embeds: [Embed.error('Failed', 'Could not fetch audit log.')] });
    const fields = entries.entries.map(e => ({
      name: `${e.action}`,
      value: `Executor: ${e.executor?.tag || 'Unknown'}\nTarget: ${e.target?.tag || e.target?.name || e.targetId || 'Unknown'}\nReason: ${e.reason || 'None'}\nTime: <t:${Math.floor(e.createdTimestamp / 1000)}:R>`,
      inline: false
    })).slice(0, 10);
    message.reply({ embeds: [Embed.custom({ title: `Audit Log — ${message.guild.name}`, fields })] });
  }
};
