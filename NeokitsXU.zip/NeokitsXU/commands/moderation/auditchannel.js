const Embed = require('../../utils/Embed');

module.exports = {
  name: 'auditchannel',
  description: 'View audit log entries related to a specific channel',
  usage: 'auditchannel [#channel]',
  category: 'moderation',
  userPermissions: ['ViewAuditLog'],
  botPermissions: ['ViewAuditLog'],
  cooldown: 10,
  async execute(client, message, args) {
    const channel = message.mentions.channels.first() || message.channel;
    const entries = await message.guild.fetchAuditLogs({ limit: 50 }).catch(() => null);
    if (!entries) return message.reply({ embeds: [Embed.error('Failed', 'Could not fetch audit log.')] });
    const filtered = entries.entries.filter(e => e.targetId === channel.id);
    if (!filtered.size) return message.reply({ embeds: [Embed.info('No Entries', `No audit log entries for ${channel}.`)] });
    const fields = filtered.first(10).map(e => ({
      name: `${e.action}`,
      value: `Executor: ${e.executor?.tag || 'Unknown'}\nReason: ${e.reason || 'None'}\nTime: <t:${Math.floor(e.createdTimestamp / 1000)}:R>`,
      inline: false
    }));
    message.reply({ embeds: [Embed.custom({ title: `Audit Log — #${channel.name}`, fields })] });
  }
};
