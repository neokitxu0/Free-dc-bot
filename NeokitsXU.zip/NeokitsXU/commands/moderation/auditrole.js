const Embed = require('../../utils/Embed');

module.exports = {
  name: 'auditrole',
  description: 'View audit log entries related to a specific role',
  usage: 'auditrole <role>',
  category: 'moderation',
  userPermissions: ['ViewAuditLog'],
  botPermissions: ['ViewAuditLog'],
  cooldown: 10,
  async execute(client, message, args) {
    const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]);
    if (!role) return message.reply({ embeds: [Embed.error('Invalid Role', 'Please mention a valid role.')] });
    const entries = await message.guild.fetchAuditLogs({ limit: 50 }).catch(() => null);
    if (!entries) return message.reply({ embeds: [Embed.error('Failed', 'Could not fetch audit log.')] });
    const filtered = entries.entries.filter(e => e.targetId === role.id);
    if (!filtered.size) return message.reply({ embeds: [Embed.info('No Entries', `No audit log entries for role **${role.name}**.`)] });
    const fields = filtered.first(10).map(e => ({
      name: `${e.action}`,
      value: `Executor: ${e.executor?.tag || 'Unknown'}\nReason: ${e.reason || 'None'}\nTime: <t:${Math.floor(e.createdTimestamp / 1000)}:R>`,
      inline: false
    }));
    message.reply({ embeds: [Embed.custom({ title: `Audit Log — ${role.name}`, fields })] });
  }
};
