const Embed = require('../../utils/Embed');

module.exports = {
  name: 'audituser',
  description: 'View audit log entries for a specific user',
  usage: 'audituser <user>',
  category: 'moderation',
  userPermissions: ['ViewAuditLog'],
  botPermissions: ['ViewAuditLog'],
  cooldown: 10,
  async execute(client, message, args) {
    const user = message.mentions.users.first() || client.users.cache.get(args[0]);
    if (!user) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid user.')] });
    const entries = await message.guild.fetchAuditLogs({ limit: 50, user }).catch(() => null);
    if (!entries) return message.reply({ embeds: [Embed.error('Failed', 'Could not fetch audit log.')] });
    const filtered = entries.entries.filter(e => e.executor?.id === user.id || e.targetId === user.id);
    if (!filtered.size) return message.reply({ embeds: [Embed.info('No Entries', `No audit log entries found for **${user.tag}**.`)] });
    const fields = filtered.first(10).map(e => ({
      name: `${e.action}`,
      value: `Executor: ${e.executor?.tag || 'Unknown'}\nReason: ${e.reason || 'None'}\nTime: <t:${Math.floor(e.createdTimestamp / 1000)}:R>`,
      inline: false
    }));
    message.reply({ embeds: [Embed.custom({ title: `Audit Log — ${user.tag}`, fields })] });
  }
};
