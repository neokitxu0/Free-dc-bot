const Embed = require('../../utils/Embed');

module.exports = {
  name: 'avatar',
  aliases: ['av', 'pfp'],
  description: 'Get a user\'s avatar',
  usage: 'avatar [user]',
  category: 'moderation',
  cooldown: 5,
  async execute(client, message, args) {
    const user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
    const member = message.guild.members.cache.get(user.id);
    const serverAv = member?.displayAvatarURL({ dynamic: true, size: 4096 });
    const globalAv = user.displayAvatarURL({ dynamic: true, size: 4096 });
    const e = Embed.custom({
      title: `${user.tag}'s Avatar`,
      image: serverAv || globalAv,
      fields: [
        { name: 'Global Avatar', value: `[Link](${globalAv})`, inline: true },
      ]
    });
    if (serverAv && serverAv !== globalAv) e.addFields({ name: 'Server Avatar', value: `[Link](${serverAv})`, inline: true });
    message.reply({ embeds: [e] });
  }
};
