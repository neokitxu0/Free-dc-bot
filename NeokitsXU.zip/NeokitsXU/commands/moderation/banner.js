const Embed = require('../../utils/Embed');

module.exports = {
  name: 'banner',
  description: 'Get a user\'s banner',
  usage: 'banner [user]',
  category: 'moderation',
  cooldown: 5,
  async execute(client, message, args) {
    const user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
    const fetched = await user.fetch(true).catch(() => user);
    const banner = fetched.bannerURL({ dynamic: true, size: 4096 });
    if (!banner) return message.reply({ embeds: [Embed.warn('No Banner', `**${user.tag}** does not have a banner.`)] });
    message.reply({ embeds: [Embed.custom({ title: `${user.tag}'s Banner`, image: banner, fields: [{ name: 'Link', value: `[Click Here](${banner})` }] })] });
  }
};
