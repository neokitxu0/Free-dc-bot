const Embed = require('../../utils/Embed');

module.exports = {
  name: 'botcount',
  aliases: ['bots'],
  description: 'Show the number of bots in the server',
  usage: 'botcount',
  category: 'moderation',
  cooldown: 5,
  async execute(client, message) {
    const bots = message.guild.members.cache.filter(m => m.user.bot);
    const list = bots.map(b => b.user.tag).slice(0, 20).join('\n') || 'None';
    message.reply({ embeds: [Embed.custom({
      title: `Bots — ${message.guild.name}`,
      description: `**Total Bots: ${bots.size}**\n\n${list}${bots.size > 20 ? `\n...and ${bots.size - 20} more` : ''}`,
    })] });
  }
};
