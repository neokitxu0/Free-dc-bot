const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'caseinfo',
  description: 'View info about a specific case',
  usage: 'caseinfo <caseID>',
  category: 'moderation',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const caseId = args[0]?.toUpperCase();
    if (!caseId) return message.reply({ embeds: [Embed.error('Missing ID', 'Provide a case ID.')] });
    const reports = DataManager.get('reports', message.guild.id, []);
    const c = reports.find(r => r.id === caseId);
    if (!c) return message.reply({ embeds: [Embed.error('Not Found', `Case \`${caseId}\` not found.`)] });
    message.reply({ embeds: [Embed.custom({
      title: `Case ${c.id}`,
      fields: [
        { name: 'Reporter', value: `<@${c.reporter}>`, inline: true },
        { name: 'Target', value: `<@${c.target}>`, inline: true },
        { name: 'Status', value: c.status.toUpperCase(), inline: true },
        { name: 'Reason', value: c.reason },
        { name: 'Time', value: `<t:${Math.floor(c.time / 1000)}:F>`, inline: true },
        ...(c.status === 'closed' ? [{ name: 'Closed By', value: `<@${c.closedBy}>`, inline: true }, { name: 'Close Reason', value: c.closedReason }] : [])
      ]
    })] });
  }
};
