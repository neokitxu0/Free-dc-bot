const Embed = require('../../utils/Embed');
const { ChannelType } = require('discord.js');

module.exports = {
  name: 'channelinfo',
  aliases: ['ci'],
  description: 'Get information about a channel',
  usage: 'channelinfo [#channel]',
  category: 'moderation',
  cooldown: 5,
  async execute(client, message, args) {
    const ch = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]) || message.channel;
    const typeNames = { 0: 'Text', 2: 'Voice', 4: 'Category', 5: 'Announcement', 13: 'Stage', 15: 'Forum' };
    message.reply({ embeds: [Embed.custom({
      title: `Channel Info — #${ch.name}`,
      fields: [
        { name: 'ID', value: ch.id, inline: true },
        { name: 'Type', value: typeNames[ch.type] || ch.type.toString(), inline: true },
        { name: 'Category', value: ch.parent?.name || 'None', inline: true },
        { name: 'Topic', value: ch.topic || 'None', inline: false },
        { name: 'NSFW', value: ch.nsfw ? 'Yes' : 'No', inline: true },
        { name: 'Slowmode', value: ch.rateLimitPerUser ? `${ch.rateLimitPerUser}s` : 'Off', inline: true },
        { name: 'Position', value: `${ch.position}`, inline: true },
        { name: 'Created', value: `<t:${Math.floor(ch.createdTimestamp / 1000)}:R>`, inline: true },
      ]
    })] });
  }
};
