const Embed = require('../../utils/Embed');

module.exports = {
  name: 'checkperms',
  description: 'Check permissions for a member in a channel',
  usage: 'checkperms [user] [#channel]',
  category: 'moderation',
  cooldown: 5,
  async execute(client, message, args) {
    const member = message.mentions.members.first() || message.member;
    const channel = message.mentions.channels.first() || message.channel;
    const perms = channel.permissionsFor(member);
    if (!perms) return message.reply({ embeds: [Embed.error('Error', 'Could not retrieve permissions.')] });
    const all = perms.toArray();
    const denied = Object.keys(require('discord.js').PermissionsBitField.Flags).filter(p => !perms.has(p));
    message.reply({ embeds: [Embed.custom({
      title: `Permissions — ${member.user.tag}`,
      description: `In ${channel}\n\n**Granted (${all.length}):**\n${all.slice(0, 15).map(p => `✅ \`${p}\``).join('\n') || 'None'}\n\n**Denied (${denied.length}):**\n${denied.slice(0, 10).map(p => `❌ \`${p}\``).join('\n') || 'None'}`
    })] });
  }
};
