const Embed = require('../../utils/Embed');

module.exports = {
  name: 'checkrole',
  description: 'Check all members who have a specific role',
  usage: 'checkrole <role>',
  category: 'moderation',
  userPermissions: ['ModerateMembers'],
  cooldown: 10,
  async execute(client, message, args) {
    const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]) || message.guild.roles.cache.find(r => r.name.toLowerCase() === args.join(' ').toLowerCase());
    if (!role) return message.reply({ embeds: [Embed.error('Invalid Role', 'Please mention a valid role.')] });
    const members = role.members.map(m => m.user.tag);
    const desc = members.length ? members.slice(0, 30).join('\n') + (members.length > 30 ? `\n...and ${members.length - 30} more` : '') : 'No members have this role.';
    message.reply({ embeds: [Embed.custom({ title: `Members with ${role.name}`, description: `**Count: ${members.length}**\n\n${desc}` })] });
  }
};
