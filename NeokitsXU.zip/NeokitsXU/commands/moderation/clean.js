const Embed = require('../../utils/Embed');

module.exports = {
  name: 'clean',
  description: 'Delete all bot messages from the channel',
  usage: 'clean [amount]',
  category: 'moderation',
  userPermissions: ['ManageMessages'],
  botPermissions: ['ManageMessages'],
  cooldown: 5,
  async execute(client, message, args) {
    const amount = Math.min(parseInt(args[0]) || 50, 100);
    const messages = await message.channel.messages.fetch({ limit: 100 });
    const botMessages = messages.filter(m => m.author.bot).first(amount);
    if (!botMessages.length) return message.reply({ embeds: [Embed.info('Nothing to Clean', 'No bot messages found.')] });
    await message.channel.bulkDelete(botMessages, true).catch(() => {});
    const r = await message.channel.send({ embeds: [Embed.success('Cleaned', `Deleted **${botMessages.length}** bot message(s).`)] });
    setTimeout(() => r.delete().catch(() => {}), 5000);
  }
};
