const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'closecase',
  description: 'Close an open report case',
  usage: 'closecase <caseID> [reason]',
  category: 'moderation',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const caseId = args[0]?.toUpperCase();
    if (!caseId) return message.reply({ embeds: [Embed.error('Missing ID', 'Provide a case ID.')] });
    const reports = DataManager.get('reports', message.guild.id, []);
    const idx = reports.findIndex(r => r.id === caseId);
    if (idx === -1) return message.reply({ embeds: [Embed.error('Not Found', `Case \`${caseId}\` not found.`)] });
    if (reports[idx].status === 'closed') return message.reply({ embeds: [Embed.warn('Already Closed', `Case \`${caseId}\` is already closed.`)] });
    reports[idx].status = 'closed';
    reports[idx].closedBy = message.author.id;
    reports[idx].closedReason = args.slice(1).join(' ') || 'No reason provided';
    reports[idx].closedAt = Date.now();
    DataManager.set('reports', message.guild.id, reports);
    message.reply({ embeds: [Embed.success('Case Closed', `Case \`${caseId}\` has been closed.`)] });
  }
};
