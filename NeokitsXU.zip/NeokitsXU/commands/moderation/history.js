const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'history',
  description: 'View full moderation history for a user',
  usage: 'history <user>',
  category: 'moderation',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.users.first() || client.users.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a user.')] });
    const key = `${message.guild.id}-${target.id}`;
    const warns = DataManager.get('warnings', key, []);
    const logs = DataManager.get('modlogs', key, []);
    const combined = [...warns.map(w => ({ ...w, type: 'warn' })), ...logs].sort((a, b) => b.time - a.time);
    if (!combined.length) return message.reply({ embeds: [Embed.info('Clean Record', `**${target.tag}** has no moderation history.`)] });
    const fields = combined.slice(0, 10).map(e => ({
      name: `${e.type.toUpperCase()} — <t:${Math.floor(e.time/1000)}:R>`,
      value: `Reason: ${e.reason}\nMod: <@${e.mod}>`,
      inline: false
    }));
    message.reply({ embeds: [Embed.custom({ title: `History — ${target.tag}`, description: `Total entries: **${combined.length}**`, fields })] });
  }
};
