const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'infractions',
  aliases: ['inf'],
  description: 'View all infractions for a user',
  usage: 'infractions <user>',
  category: 'moderation',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    const key = `${message.guild.id}-${target.id}`;
    const warns = DataManager.get('warnings', key, []);
    const logs = DataManager.get('modlogs', key, []);
    const fields = [
      { name: 'Warnings', value: `${warns.length}`, inline: true },
      { name: 'Mod Actions', value: `${logs.length}`, inline: true },
      { name: 'Recent Actions', value: logs.slice(-5).map(l => `• ${l.type.toUpperCase()} — <t:${Math.floor(l.time/1000)}:R>`).join('\n') || 'None' }
    ];
    message.reply({ embeds: [Embed.custom({ title: `Infractions — ${target.user.tag}`, fields })] });
  }
};
