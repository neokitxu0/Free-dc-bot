const Embed = require('../../utils/Embed');

module.exports = {
  name: 'lockdown',
  description: 'Lockdown the server (all text channels)',
  usage: 'lockdown [reason]',
  category: 'moderation',
  userPermissions: ['Administrator'],
  botPermissions: ['ManageChannels'],
  cooldown: 30,
  async execute(client, message, args) {
    const reason = args.join(' ') || 'Emergency lockdown';
    const channels = message.guild.channels.cache.filter(c => c.type === 0);
    let count = 0;
    for (const [, ch] of channels) {
      try {
        await ch.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: false });
        count++;
      } catch {}
    }
    message.reply({ embeds: [Embed.warn('🔒 Lockdown Active', `**${count}** channels locked.\nReason: ${reason}\n\nUse \`unlockdown\` to restore.`)] });
  }
};
