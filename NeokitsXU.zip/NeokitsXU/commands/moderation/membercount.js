const Embed = require('../../utils/Embed');

module.exports = {
  name: 'membercount',
  aliases: ['mc', 'members'],
  description: 'Show the server member count',
  usage: 'membercount',
  category: 'moderation',
  cooldown: 5,
  async execute(client, message) {
    const g = message.guild;
    const humans = g.members.cache.filter(m => !m.user.bot).size;
    const bots = g.members.cache.filter(m => m.user.bot).size;
    const online = g.members.cache.filter(m => m.presence?.status && m.presence.status !== 'offline').size;
    message.reply({ embeds: [Embed.custom({
      title: `Member Count — ${g.name}`,
      thumbnail: g.iconURL({ dynamic: true }),
      fields: [
        { name: 'Total', value: `${g.memberCount}`, inline: true },
        { name: 'Humans', value: `${humans}`, inline: true },
        { name: 'Bots', value: `${bots}`, inline: true },
        { name: 'Online', value: `${online || 'N/A'}`, inline: true },
      ]
    })] });
  }
};
