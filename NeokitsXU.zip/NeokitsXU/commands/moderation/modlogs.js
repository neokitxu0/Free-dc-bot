const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'modlogs',
  aliases: ['mlog'],
  description: 'View mod action logs for a user',
  usage: 'modlogs <user>',
  category: 'moderation',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.users.first() || client.users.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a user.')] });
    const key = `${message.guild.id}-${target.id}`;
    const logs = DataManager.get('modlogs', key, []);
    if (!logs.length) return message.reply({ embeds: [Embed.info('No Logs', `No mod logs found for **${target.tag}**.`)] });
    const fields = logs.slice(-10).reverse().map(l => ({
      name: `${l.type.toUpperCase()} — <t:${Math.floor(l.time / 1000)}:R>`,
      value: `Mod: <@${l.mod}>\nReason: ${l.reason}${l.duration ? `\nDuration: ${l.duration}` : ''}`,
      inline: false
    }));
    message.reply({ embeds: [Embed.custom({ title: `Mod Logs — ${target.tag}`, description: `Total: **${logs.length}** action(s)`, fields })] });
  }
};
