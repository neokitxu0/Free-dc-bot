const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'notes',
  description: 'Add or view moderator notes on a user',
  usage: 'notes <user> [add <note>|clear]',
  category: 'moderation',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid member.')] });
    const key = `${message.guild.id}-${target.id}`;
    const action = args[1]?.toLowerCase();
    if (action === 'add') {
      const note = args.slice(2).join(' ');
      if (!note) return message.reply({ embeds: [Embed.error('Missing Note', 'Provide a note to add.')] });
      const notes = DataManager.ensure('notes', key, []);
      notes.push({ note, mod: message.author.id, time: Date.now() });
      DataManager.set('notes', key, notes);
      return message.reply({ embeds: [Embed.success('Note Added', `Note added for **${target.user.tag}**.`)] });
    }
    if (action === 'clear') {
      DataManager.set('notes', key, []);
      return message.reply({ embeds: [Embed.success('Notes Cleared', `All notes cleared for **${target.user.tag}**.`)] });
    }
    const notes = DataManager.get('notes', key, []);
    if (!notes.length) return message.reply({ embeds: [Embed.info('No Notes', `No notes for **${target.user.tag}**.`)] });
    const fields = notes.slice(-10).map((n, i) => ({ name: `Note #${i+1} — <t:${Math.floor(n.time/1000)}:R>`, value: `${n.note}\nBy: <@${n.mod}>`, inline: false }));
    message.reply({ embeds: [Embed.custom({ title: `Notes — ${target.user.tag}`, fields })] });
  }
};
