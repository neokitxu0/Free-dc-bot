const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');
const { v4: uuidv4 } = require('uuid');

module.exports = {
  name: 'report',
  description: 'Report a member to moderators',
  usage: 'report <user> <reason>',
  category: 'moderation',
  cooldown: 30,
  async execute(client, message, args) {
    const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) return message.reply({ embeds: [Embed.error('Invalid User', 'Please mention a valid member.')] });
    if (target.id === message.author.id) return message.reply({ embeds: [Embed.error('Error', 'You cannot report yourself.')] });
    const reason = args.slice(1).join(' ');
    if (!reason) return message.reply({ embeds: [Embed.error('Missing Reason', 'Please provide a reason for the report.')] });
    const id = uuidv4().slice(0, 8).toUpperCase();
    const reports = DataManager.ensure('reports', message.guild.id, []);
    reports.push({ id, reporter: message.author.id, target: target.id, reason, time: Date.now(), status: 'open' });
    DataManager.set('reports', message.guild.id, reports);
    await message.delete().catch(() => {});
    const reply = await message.channel.send({ embeds: [Embed.success('Report Submitted', `Your report has been submitted.\nCase ID: \`${id}\`\nReason: ${reason}`)] });
    setTimeout(() => reply.delete().catch(() => {}), 10000);
    if (client.config.logChannelId) {
      const logCh = message.guild.channels.cache.get(client.config.logChannelId);
      if (logCh) logCh.send({ embeds: [Embed.warn(`New Report — ${id}`, `Reporter: ${message.author}\nTarget: ${target.user.tag}\nReason: ${reason}`)] }).catch(() => {});
    }
  }
};
