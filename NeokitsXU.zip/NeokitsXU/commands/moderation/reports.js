const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'reports',
  description: 'View all open reports in the server',
  usage: 'reports [page]',
  category: 'moderation',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const all = DataManager.get('reports', message.guild.id, []);
    const open = all.filter(r => r.status === 'open');
    if (!open.length) return message.reply({ embeds: [Embed.info('No Reports', 'There are no open reports.')] });
    const page = Math.max(1, parseInt(args[0]) || 1);
    const perPage = 5;
    const pages = Math.ceil(open.length / perPage);
    const slice = open.slice((page - 1) * perPage, page * perPage);
    const fields = slice.map(r => ({
      name: `Case ${r.id}`,
      value: `Reporter: <@${r.reporter}>\nTarget: <@${r.target}>\nReason: ${r.reason}\nTime: <t:${Math.floor(r.time / 1000)}:R>`,
      inline: false
    }));
    message.reply({ embeds: [Embed.custom({ title: `Open Reports — ${message.guild.name}`, description: `Total: **${open.length}** | Page ${page}/${pages}`, fields })] });
  }
};
