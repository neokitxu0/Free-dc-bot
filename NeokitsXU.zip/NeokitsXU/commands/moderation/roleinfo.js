const Embed = require('../../utils/Embed');

module.exports = {
  name: 'roleinfo',
  aliases: ['ri'],
  description: 'Get information about a role',
  usage: 'roleinfo <role>',
  category: 'moderation',
  cooldown: 5,
  async execute(client, message, args) {
    const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]) || message.guild.roles.cache.find(r => r.name.toLowerCase() === args.join(' ').toLowerCase());
    if (!role) return message.reply({ embeds: [Embed.error('Invalid Role', 'Please mention a valid role.')] });
    const perms = role.permissions.toArray().slice(0, 10).map(p => `\`${p}\``).join(', ') || 'None';
    message.reply({ embeds: [Embed.custom({
      title: `Role Info — ${role.name}`,
      color: role.hexColor,
      fields: [
        { name: 'ID', value: role.id, inline: true },
        { name: 'Color', value: role.hexColor, inline: true },
        { name: 'Position', value: `${role.position}`, inline: true },
        { name: 'Hoisted', value: role.hoist ? 'Yes' : 'No', inline: true },
        { name: 'Mentionable', value: role.mentionable ? 'Yes' : 'No', inline: true },
        { name: 'Managed', value: role.managed ? 'Yes' : 'No', inline: true },
        { name: 'Members', value: `${role.members.size}`, inline: true },
        { name: 'Created', value: `<t:${Math.floor(role.createdTimestamp / 1000)}:R>`, inline: true },
        { name: 'Key Permissions', value: perms, inline: false },
      ]
    })] });
  }
};
