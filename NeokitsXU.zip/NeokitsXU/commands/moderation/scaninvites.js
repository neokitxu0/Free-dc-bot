const Embed = require('../../utils/Embed');

module.exports = {
  name: 'scaninvites',
  description: 'Scan recent messages for Discord invites',
  usage: 'scaninvites [amount]',
  category: 'moderation',
  userPermissions: ['ModerateMembers'],
  cooldown: 10,
  async execute(client, message, args) {
    const amount = Math.min(parseInt(args[0]) || 50, 100);
    const msgs = await message.channel.messages.fetch({ limit: amount });
    const invRegex = /(discord\.gg|discord\.com\/invite)\/\w+/gi;
    const found = [];
    for (const [, m] of msgs) {
      const invs = m.content.match(invRegex);
      if (invs) found.push({ user: m.author.tag, invites: invs, time: m.createdTimestamp });
    }
    if (!found.length) return message.reply({ embeds: [Embed.info('None Found', `No Discord invites found in the last **${amount}** messages.`)] });
    const desc = found.map(f => `**${f.user}**: ${f.invites.join(', ')}`).slice(0, 10).join('\n');
    message.reply({ embeds: [Embed.warn(`Invite Scan — ${found.length} found`, desc)] });
  }
};
