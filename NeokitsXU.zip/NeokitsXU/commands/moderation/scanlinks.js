const Embed = require('../../utils/Embed');

module.exports = {
  name: 'scanlinks',
  description: 'Scan recent messages for links',
  usage: 'scanlinks [amount]',
  category: 'moderation',
  userPermissions: ['ModerateMembers'],
  cooldown: 10,
  async execute(client, message, args) {
    const amount = Math.min(parseInt(args[0]) || 50, 100);
    const msgs = await message.channel.messages.fetch({ limit: amount });
    const linkRegex = /https?:\/\/\S+/gi;
    const found = [];
    for (const [, m] of msgs) {
      const links = m.content.match(linkRegex);
      if (links) found.push({ user: m.author.tag, links, time: m.createdTimestamp });
    }
    if (!found.length) return message.reply({ embeds: [Embed.info('No Links', `No links found in the last **${amount}** messages.`)] });
    const desc = found.slice(0, 10).map(f => `**${f.user}**: ${f.links.slice(0, 3).join(', ')}`).join('\n');
    message.reply({ embeds: [Embed.custom({ title: `Link Scan — ${found.length} found`, description: desc })] });
  }
};
