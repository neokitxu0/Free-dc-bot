const Embed = require('../../utils/Embed');

module.exports = {
  name: 'scanmentions',
  description: 'Scan recent messages for mass mentions',
  usage: 'scanmentions [amount] [threshold]',
  category: 'moderation',
  userPermissions: ['ModerateMembers'],
  cooldown: 10,
  async execute(client, message, args) {
    const amount = Math.min(parseInt(args[0]) || 50, 100);
    const threshold = parseInt(args[1]) || 5;
    const msgs = await message.channel.messages.fetch({ limit: amount });
    const found = msgs.filter(m => m.mentions.users.size >= threshold || m.mentions.roles.size >= threshold);
    if (!found.size) return message.reply({ embeds: [Embed.info('None Found', `No mass mentions (≥${threshold}) found in the last **${amount}** messages.`)] });
    const desc = [...found.values()].slice(0, 10).map(m => `**${m.author.tag}**: ${m.mentions.users.size} users, ${m.mentions.roles.size} roles`).join('\n');
    message.reply({ embeds: [Embed.warn(`Mass Mentions — ${found.size} found`, desc)] });
  }
};
