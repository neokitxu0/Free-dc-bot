const Embed = require('../../utils/Embed');

module.exports = {
  name: 'serverinfo',
  aliases: ['si', 'guildinfo'],
  description: 'Get information about the server',
  usage: 'serverinfo',
  category: 'moderation',
  cooldown: 5,
  async execute(client, message) {
    const g = message.guild;
    const owner = await g.fetchOwner().catch(() => null);
    const textChannels = g.channels.cache.filter(c => c.type === 0).size;
    const voiceChannels = g.channels.cache.filter(c => c.type === 2).size;
    const categories = g.channels.cache.filter(c => c.type === 4).size;
    message.reply({ embeds: [Embed.custom({
      title: g.name,
      thumbnail: g.iconURL({ dynamic: true }),
      image: g.bannerURL({ size: 1024 }) || null,
      fields: [
        { name: 'ID', value: g.id, inline: true },
        { name: 'Owner', value: owner ? `${owner.user.tag}` : `<@${g.ownerId}>`, inline: true },
        { name: 'Region', value: g.preferredLocale, inline: true },
        { name: 'Created', value: `<t:${Math.floor(g.createdTimestamp / 1000)}:R>`, inline: true },
        { name: 'Members', value: `${g.memberCount}`, inline: true },
        { name: 'Boost Level', value: `Tier ${g.premiumTier} (${g.premiumSubscriptionCount} boosts)`, inline: true },
        { name: 'Channels', value: `Text: ${textChannels} | Voice: ${voiceChannels} | Categories: ${categories}`, inline: false },
        { name: 'Roles', value: `${g.roles.cache.size}`, inline: true },
        { name: 'Emojis', value: `${g.emojis.cache.size}`, inline: true },
        { name: 'Stickers', value: `${g.stickers.cache.size}`, inline: true },
        { name: 'Verification Level', value: g.verificationLevel.toString(), inline: true },
        { name: 'NSFW Level', value: g.nsfwLevel.toString(), inline: true },
      ]
    })] });
  }
};
