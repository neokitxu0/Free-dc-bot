const Embed = require('../../utils/Embed');

module.exports = {
  name: 'unlockdown',
  description: 'Lift the server lockdown',
  usage: 'unlockdown [reason]',
  category: 'moderation',
  userPermissions: ['Administrator'],
  botPermissions: ['ManageChannels'],
  cooldown: 30,
  async execute(client, message, args) {
    const reason = args.join(' ') || 'Lockdown lifted';
    const channels = message.guild.channels.cache.filter(c => c.type === 0);
    let count = 0;
    for (const [, ch] of channels) {
      try {
        await ch.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: null });
        count++;
      } catch {}
    }
    message.reply({ embeds: [Embed.success('🔓 Lockdown Lifted', `**${count}** channels unlocked.\nReason: ${reason}`)] });
  }
};
