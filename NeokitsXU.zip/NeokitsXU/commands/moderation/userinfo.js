const Embed = require('../../utils/Embed');

module.exports = {
  name: 'userinfo',
  aliases: ['ui', 'whois'],
  description: 'Get detailed information about a user',
  usage: 'userinfo [user]',
  category: 'moderation',
  cooldown: 5,
  async execute(client, message, args) {
    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    const user = member.user;
    const roles = member.roles.cache.filter(r => r.id !== message.guild.id).sort((a, b) => b.position - a.position).map(r => r.toString()).slice(0, 10);
    const e = Embed.custom({
      title: `${user.tag}`,
      thumbnail: user.displayAvatarURL({ dynamic: true, size: 256 }),
      fields: [
        { name: 'ID', value: user.id, inline: true },
        { name: 'Nickname', value: member.nickname || 'None', inline: true },
        { name: 'Bot', value: user.bot ? 'Yes' : 'No', inline: true },
        { name: 'Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F> (<t:${Math.floor(user.createdTimestamp / 1000)}:R>)`, inline: false },
        { name: 'Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:F> (<t:${Math.floor(member.joinedTimestamp / 1000)}:R>)`, inline: false },
        { name: `Roles [${member.roles.cache.size - 1}]`, value: roles.length ? roles.join(', ') : 'None', inline: false },
        { name: 'Highest Role', value: member.roles.highest.toString(), inline: true },
        { name: 'Boosting Since', value: member.premiumSince ? `<t:${Math.floor(member.premiumSinceTimestamp / 1000)}:R>` : 'Not boosting', inline: true },
      ]
    });
    message.reply({ embeds: [e] });
  }
};
