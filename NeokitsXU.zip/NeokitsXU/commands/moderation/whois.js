const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'whois',
  description: 'Full information about a user including mod history',
  usage: 'whois [user]',
  category: 'moderation',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    const user = member.user;
    const key = `${message.guild.id}-${user.id}`;
    const warns = DataManager.get('warnings', key, []);
    const logs = DataManager.get('modlogs', key, []);
    const roles = member.roles.cache.filter(r => r.id !== message.guild.id).sort((a, b) => b.position - a.position).map(r => r.toString()).slice(0, 5);
    message.reply({ embeds: [Embed.custom({
      title: `Who is ${user.tag}`,
      thumbnail: user.displayAvatarURL({ dynamic: true, size: 256 }),
      fields: [
        { name: 'ID', value: user.id, inline: true },
        { name: 'Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
        { name: 'Joined', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: 'Warnings', value: `${warns.length}`, inline: true },
        { name: 'Mod Actions', value: `${logs.length}`, inline: true },
        { name: 'Roles', value: roles.length ? roles.join(', ') : 'None', inline: false },
      ]
    })] });
  }
};
