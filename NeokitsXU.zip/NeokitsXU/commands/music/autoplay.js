const Embed = require('../../utils/Embed');

module.exports = {
  name: 'autoplay',
  aliases: ['ap'],
  description: 'Toggle autoplay mode (auto-queue related songs)',
  usage: 'autoplay <on|off>',
  category: 'music',
  cooldown: 5,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    if (!queue) return message.reply({ embeds: [Embed.error('Not Playing', 'No music is playing.')] });
    const toggle = args[0]?.toLowerCase();
    if (!['on', 'off'].includes(toggle)) return message.reply({ embeds: [Embed.error('Usage', 'autoplay <on|off>')] });
    queue.autoplay = toggle === 'on';
    message.reply({ embeds: [Embed.success('🔁 Autoplay', `Autoplay is now **${toggle}**.`)] });
  }
};
