const Embed = require('../../utils/Embed');

module.exports = {
  name: 'bassboost',
  aliases: ['bb'],
  description: 'Toggle bass boost filter',
  usage: 'bassboost <on|off|low|medium|high>',
  category: 'music',
  cooldown: 5,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || !queue.playing) return message.reply({ embeds: [Embed.error('Not Playing', 'No music is playing.')] });
    const level = args[0]?.toLowerCase() || 'medium';
    const levels = { off: 0, low: 20, medium: 50, high: 100, on: 50 };
    if (!(level in levels)) return message.reply({ embeds: [Embed.error('Invalid Level', 'Use: off, low, medium, high.')] });
    queue.bassboost = level;
    const emoji = level === 'off' ? '🔇' : '🔊';
    message.reply({ embeds: [Embed.success(`${emoji} Bass Boost`, `Bass boost set to **${level}**.`)] });
  }
};
