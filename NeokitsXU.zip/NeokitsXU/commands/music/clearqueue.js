const Embed = require('../../utils/Embed');

module.exports = {
  name: 'clearqueue',
  aliases: ['cq'],
  description: 'Clear all songs from the queue (keeps current song)',
  usage: 'clearqueue',
  category: 'music',
  cooldown: 5,
  async execute(client, message) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || queue.songs.length <= 1) return message.reply({ embeds: [Embed.error('Empty Queue', 'No songs to clear.')] });
    const current = queue.songs[0];
    queue.songs = [current];
    message.reply({ embeds: [Embed.success('🗑️ Queue Cleared', 'Queue cleared. Current song will finish playing.')] });
  }
};
