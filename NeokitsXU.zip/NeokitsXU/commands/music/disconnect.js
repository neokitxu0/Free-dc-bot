const Embed = require('../../utils/Embed');
const { getVoiceConnection } = require('@discordjs/voice');

module.exports = {
  name: 'disconnect',
  aliases: ['dc', 'leave'],
  description: 'Disconnect the bot from voice channel',
  usage: 'disconnect',
  category: 'music',
  cooldown: 3,
  async execute(client, message) {
    const connection = getVoiceConnection(message.guild.id);
    if (!connection) return message.reply({ embeds: [Embed.error('Not Connected', 'Bot is not in a voice channel.')] });
    connection.destroy();
    client.queue.delete(message.guild.id);
    message.reply({ embeds: [Embed.success('👋 Disconnected', 'Left the voice channel and cleared the queue.')] });
  }
};
