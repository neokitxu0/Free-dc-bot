const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'favorites',
  aliases: ['fav', 'favs'],
  description: 'Manage your favorite songs',
  usage: 'favorites <add|remove|list|play>',
  category: 'music',
  cooldown: 5,
  async execute(client, message, args) {
    const action = args[0]?.toLowerCase();
    const favs = DataManager.ensure('musicfavorites', message.author.id, []);
    if (!action || action === 'list') {
      if (!favs.length) return message.reply({ embeds: [Embed.info('No Favorites', 'No favorites saved. Use `favorites add` while a song is playing.')] });
      const desc = favs.slice(0, 10).map((s, i) => `**${i+1}.** [${s.title}](${s.url})`).join('\n');
      return message.reply({ embeds: [Embed.custom({ title: '⭐ Your Favorites', description: desc })] });
    }
    if (action === 'add') {
      const queue = client.queue.get(message.guild.id);
      if (!queue || !queue.songs.length) return message.reply({ embeds: [Embed.error('Not Playing', 'No song is currently playing.')] });
      const song = queue.songs[0];
      if (favs.some(f => f.url === song.url)) return message.reply({ embeds: [Embed.warn('Already Saved', 'This song is already in your favorites.')] });
      favs.push({ title: song.title, url: song.url, duration: song.duration });
      DataManager.set('musicfavorites', message.author.id, favs);
      return message.reply({ embeds: [Embed.success('Added', `**${song.title}** added to favorites!`)] });
    }
    if (action === 'remove') {
      const idx = parseInt(args[1]) - 1;
      if (isNaN(idx) || idx < 0 || idx >= favs.length) return message.reply({ embeds: [Embed.error('Invalid', 'Provide a valid number from your favorites list.')] });
      const removed = favs.splice(idx, 1)[0];
      DataManager.set('musicfavorites', message.author.id, favs);
      return message.reply({ embeds: [Embed.success('Removed', `Removed **${removed.title}** from favorites.`)] });
    }
    if (action === 'play') {
      if (!favs.length) return message.reply({ embeds: [Embed.info('No Favorites', 'No favorites to play.')] });
      const play = client.commands.get('play');
      for (const s of favs.slice(0, 10)) await play?.execute(client, message, [s.url]).catch(() => {});
      return message.reply({ embeds: [Embed.success('Playing', `Added **${favs.length}** favorites to the queue!`)] });
    }
    message.reply({ embeds: [Embed.error('Unknown Action', 'Actions: `list`, `add`, `remove`, `play`.')] });
  }
};
