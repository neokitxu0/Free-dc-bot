const Embed = require('../../utils/Embed');

const filters = {
  'bassboost': 'Bass Boost',
  'nightcore': 'Nightcore',
  'vaporwave': 'Vaporwave',
  'karaoke': 'Karaoke',
  'equalizer': 'Equalizer',
  'echo': 'Echo',
  'flanger': 'Flanger',
  'pulsator': 'Pulsator',
  '3d': '3D Audio',
  'none': 'No Filter',
};

module.exports = {
  name: 'filter',
  description: 'Apply audio filters',
  usage: 'filter <filter name|list>',
  category: 'music',
  cooldown: 5,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    if (!args.length || args[0]?.toLowerCase() === 'list') {
      const filterList = Object.entries(filters).map(([k, v]) => `\`${k}\` — ${v}`).join('\n');
      return message.reply({ embeds: [Embed.info('🎛️ Available Filters', filterList)] });
    }
    if (!queue || !queue.playing) return message.reply({ embeds: [Embed.error('Not Playing', 'No music is playing.')] });
    const filter = args[0]?.toLowerCase();
    if (!filters[filter]) return message.reply({ embeds: [Embed.error('Unknown Filter', `Unknown filter. Use \`filter list\` to see available filters.`)] });
    queue.filter = filter === 'none' ? null : filter;
    message.reply({ embeds: [Embed.success('🎛️ Filter', `Filter set to **${filters[filter]}**.`)] });
  }
};
