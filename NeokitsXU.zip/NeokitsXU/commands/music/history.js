const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'musichistory',
  aliases: ['mhistory'],
  description: 'View recently played songs',
  usage: 'musichistory',
  category: 'music',
  cooldown: 5,
  async execute(client, message) {
    const hist = DataManager.get('musichistory', message.guild.id, []);
    if (!hist.length) return message.reply({ embeds: [Embed.info('No History', 'No songs have been played yet.')] });
    const desc = hist.slice(-10).reverse().map((s, i) => `**${i+1}.** [${s.title}](${s.url}) — <t:${Math.floor(s.playedAt / 1000)}:R>`).join('\n');
    message.reply({ embeds: [Embed.custom({ title: '🎵 Music History', description: desc })] });
  }
};
