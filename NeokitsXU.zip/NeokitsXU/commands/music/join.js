const Embed = require('../../utils/Embed');
const { joinVoiceChannel } = require('@discordjs/voice');

module.exports = {
  name: 'join',
  description: 'Join your voice channel',
  usage: 'join',
  category: 'music',
  cooldown: 5,
  async execute(client, message) {
    const voiceChannel = message.member.voice.channel;
    if (!voiceChannel) return message.reply({ embeds: [Embed.error('Not in Voice', 'You must be in a voice channel!')] });
    const perms = voiceChannel.permissionsFor(message.guild.members.me);
    if (!perms.has('Connect') || !perms.has('Speak')) return message.reply({ embeds: [Embed.error('Missing Permissions', 'I need Connect and Speak permissions!')] });
    joinVoiceChannel({ channelId: voiceChannel.id, guildId: message.guild.id, adapterCreator: message.guild.voiceAdapterCreator });
    message.reply({ embeds: [Embed.success('🎵 Joined', `Connected to **${voiceChannel.name}**!`)] });
  }
};
