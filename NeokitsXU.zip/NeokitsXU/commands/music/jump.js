const Embed = require('../../utils/Embed');

module.exports = {
  name: 'jump',
  description: 'Jump to a specific position in the queue',
  usage: 'jump <position>',
  category: 'music',
  cooldown: 3,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || !queue.songs.length) return message.reply({ embeds: [Embed.error('Empty Queue', 'The queue is empty.')] });
    const pos = parseInt(args[0]);
    if (!pos || pos < 1 || pos >= queue.songs.length) return message.reply({ embeds: [Embed.error('Invalid Position', `Provide a valid position (1–${queue.songs.length - 1}).`)] });
    queue.songs.splice(1, pos - 1);
    queue.player.stop();
    message.reply({ embeds: [Embed.success('⏭️ Jumped', `Jumped to position **${pos}**: **${queue.songs[0]?.title}**`)] });
  }
};
