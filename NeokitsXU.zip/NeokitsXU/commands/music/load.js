const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'load',
  description: 'Load and play a personal playlist',
  usage: 'load <playlist name>',
  category: 'music',
  cooldown: 10,
  async execute(client, message, args) {
    const name = args.join(' ');
    if (!name) return message.reply({ embeds: [Embed.error('Missing Name', 'Provide a playlist name to load.')] });
    const playlists = DataManager.get('playlists', message.author.id, {});
    const songs = playlists[name];
    if (!songs || !songs.length) return message.reply({ embeds: [Embed.error('Empty', `Playlist **${name}** is empty or doesn't exist.`)] });
    if (!message.member.voice.channel) return message.reply({ embeds: [Embed.error('Not in Voice', 'You must be in a voice channel!')] });
    let added = 0;
    const play = client.commands.get('play');
    for (const song of songs.slice(0, 25)) {
      await play?.execute(client, message, [song.url]).catch(() => {});
      added++;
    }
    message.reply({ embeds: [Embed.success('Playlist Loaded', `Loaded **${added}** songs from playlist **${name}** into the queue.`)] });
  }
};
