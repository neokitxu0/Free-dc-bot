const Embed = require('../../utils/Embed');

module.exports = {
  name: 'loop',
  description: 'Toggle loop mode',
  usage: 'loop <off|song|queue>',
  category: 'music',
  cooldown: 3,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    if (!queue) return message.reply({ embeds: [Embed.error('Not Playing', 'No music is playing.')] });
    const mode = args[0]?.toLowerCase() || 'song';
    if (!['off', 'song', 'queue'].includes(mode)) return message.reply({ embeds: [Embed.error('Invalid Mode', 'Use: `off`, `song`, or `queue`.')] });
    queue.loop = mode;
    const emoji = { off: '➡️', song: '🔂', queue: '🔁' };
    message.reply({ embeds: [Embed.success(`${emoji[mode]} Loop`, `Loop mode set to **${mode}**.`)] });
  }
};
