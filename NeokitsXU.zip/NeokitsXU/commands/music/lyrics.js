const Embed = require('../../utils/Embed');

module.exports = {
  name: 'lyrics',
  description: 'Search for song lyrics',
  usage: 'lyrics [song name]',
  category: 'music',
  cooldown: 10,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    const songName = args.join(' ') || queue?.songs[0]?.title;
    if (!songName) return message.reply({ embeds: [Embed.error('No Song', 'Provide a song name or play something.')] });
    message.reply({ embeds: [Embed.info('🎤 Lyrics', `Searching lyrics for: **${songName}**\n\nLyrics integration requires a lyrics API (genius.com). Configure your Genius API key to enable this feature.\n\nVisit: https://genius.com/api-clients`)] });
  }
};
