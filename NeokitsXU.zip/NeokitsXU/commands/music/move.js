const Embed = require('../../utils/Embed');

module.exports = {
  name: 'move',
  description: 'Move a song to a different position in the queue',
  usage: 'move <from> <to>',
  category: 'music',
  cooldown: 3,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || queue.songs.length < 2) return message.reply({ embeds: [Embed.error('Empty Queue', 'Not enough songs to move.')] });
    const from = parseInt(args[0]);
    const to = parseInt(args[1]);
    if (!from || !to || from < 1 || to < 1 || from >= queue.songs.length || to >= queue.songs.length) return message.reply({ embeds: [Embed.error('Invalid Positions', 'Provide valid positions.')] });
    const song = queue.songs.splice(from, 1)[0];
    queue.songs.splice(to, 0, song);
    message.reply({ embeds: [Embed.success('Moved', `Moved **${song.title}** from position ${from} to ${to}.`)] });
  }
};
