const Embed = require('../../utils/Embed');

module.exports = {
  name: 'nightcore',
  description: 'Toggle nightcore filter (speed up + pitch up)',
  usage: 'nightcore <on|off>',
  category: 'music',
  cooldown: 5,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || !queue.playing) return message.reply({ embeds: [Embed.error('Not Playing', 'No music is playing.')] });
    const toggle = args[0]?.toLowerCase() || 'on';
    if (!['on', 'off'].includes(toggle)) return message.reply({ embeds: [Embed.error('Usage', 'nightcore <on|off>')] });
    queue.nightcore = toggle === 'on';
    message.reply({ embeds: [Embed.success('🌙 Nightcore', `Nightcore filter is now **${toggle}**.\n\n*Restarts current song with filter.*`)] });
  }
};
