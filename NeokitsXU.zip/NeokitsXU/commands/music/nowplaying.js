const Embed = require('../../utils/Embed');

module.exports = {
  name: 'nowplaying',
  aliases: ['np', 'current'],
  description: 'Show the currently playing song',
  usage: 'nowplaying',
  category: 'music',
  cooldown: 5,
  async execute(client, message) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || !queue.songs.length) return message.reply({ embeds: [Embed.error('Not Playing', 'No music is playing.')] });
    const song = queue.songs[0];
    const elapsed = queue.startTime ? Math.floor((Date.now() - queue.startTime) / 1000) : 0;
    const total = song.durationSec || 0;
    const barLen = 20;
    const filled = total > 0 ? Math.floor((elapsed / total) * barLen) : 0;
    const bar = '▬'.repeat(filled) + '🔘' + '▬'.repeat(Math.max(0, barLen - filled - 1));
    const fmtTime = s => `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;
    message.reply({ embeds: [Embed.custom({
      title: '🎵 Now Playing',
      description: `**[${song.title}](${song.url})**\n\n\`${fmtTime(elapsed)} [${bar}] ${song.duration}\``,
      thumbnail: song.thumbnail,
      fields: [
        { name: 'Requested by', value: `<@${song.requestedBy}>`, inline: true },
        { name: 'Volume', value: `${queue.volume || 100}%`, inline: true },
        { name: 'Loop', value: queue.loop || 'off', inline: true },
      ]
    })] });
  }
};
