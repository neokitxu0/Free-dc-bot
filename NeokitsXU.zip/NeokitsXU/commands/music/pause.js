const Embed = require('../../utils/Embed');

module.exports = {
  name: 'pause',
  description: 'Pause the current song',
  usage: 'pause',
  category: 'music',
  cooldown: 3,
  async execute(client, message) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || !queue.playing) return message.reply({ embeds: [Embed.error('Not Playing', 'No music is playing.')] });
    if (queue.paused) return message.reply({ embeds: [Embed.warn('Already Paused', 'Music is already paused. Use `resume` to continue.')] });
    queue.player.pause();
    queue.paused = true;
    message.reply({ embeds: [Embed.success('⏸️ Paused', 'Music has been paused.')] });
  }
};
