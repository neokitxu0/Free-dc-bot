const Embed = require('../../utils/Embed');
const MusicManager = require('../../utils/MusicManager');

module.exports = {
  name: 'play',
  aliases: ['p'],
  description: 'Play a song from YouTube or search query',
  usage: 'play <song name or URL>',
  category: 'music',
  cooldown: 3,
  async execute(client, message, args) {
    const query = args.join(' ');
    if (!query) return message.reply({ embeds: [Embed.error('Missing Query', 'Provide a song name or URL.')] });
    const voiceChannel = message.member.voice.channel;
    if (!voiceChannel) return message.reply({ embeds: [Embed.error('Not in Voice', 'You must be in a voice channel!')] });
    const perms = voiceChannel.permissionsFor(message.guild.members.me);
    if (!perms.has('Connect') || !perms.has('Speak')) return message.reply({ embeds: [Embed.error('Missing Permissions', 'I need Connect and Speak permissions!')] });
    const loading = await message.reply({ embeds: [Embed.info('🔍 Searching...', `Searching for: **${query}**`)] });
    try {
      const result = await MusicManager.play(client, message, query);
      loading.edit({ embeds: [Embed.custom({
        title: result.queued ? '➕ Added to Queue' : '🎵 Now Playing',
        description: `**[${result.title}](${result.url})**\nDuration: \`${result.duration}\`\nPosition: ${result.queued ? `#${result.position}` : 'Now'}`,
        thumbnail: result.thumbnail
      })] });
    } catch (e) {
      loading.edit({ embeds: [Embed.error('Error', e.message || 'Could not play that track.')] });
    }
  }
};
