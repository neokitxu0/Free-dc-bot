const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'playlist',
  description: 'Manage personal playlists',
  usage: 'playlist <list|create|delete|show> [name]',
  category: 'music',
  cooldown: 5,
  async execute(client, message, args) {
    const action = args[0]?.toLowerCase();
    const name = args.slice(1).join(' ');
    const playlists = DataManager.ensure('playlists', message.author.id, {});
    if (!action || action === 'list') {
      const list = Object.keys(playlists);
      if (!list.length) return message.reply({ embeds: [Embed.info('No Playlists', 'You have no playlists. Create one with `playlist create <name>`.')] });
      return message.reply({ embeds: [Embed.custom({ title: '🎵 Your Playlists', description: list.map(n => `• **${n}** (${playlists[n].length} songs)`).join('\n') })] });
    }
    if (action === 'create') {
      if (!name) return message.reply({ embeds: [Embed.error('Missing Name', 'Provide a playlist name.')] });
      if (playlists[name]) return message.reply({ embeds: [Embed.warn('Exists', `Playlist **${name}** already exists.`)] });
      playlists[name] = [];
      DataManager.set('playlists', message.author.id, playlists);
      return message.reply({ embeds: [Embed.success('Created', `Playlist **${name}** created!`)] });
    }
    if (action === 'delete') {
      if (!name || !playlists[name]) return message.reply({ embeds: [Embed.error('Not Found', `Playlist **${name}** not found.`)] });
      delete playlists[name];
      DataManager.set('playlists', message.author.id, playlists);
      return message.reply({ embeds: [Embed.success('Deleted', `Playlist **${name}** deleted.`)] });
    }
    if (action === 'show') {
      if (!name || !playlists[name]) return message.reply({ embeds: [Embed.error('Not Found', `Playlist **${name}** not found.`)] });
      const songs = playlists[name];
      const desc = songs.length ? songs.slice(0, 15).map((s, i) => `**${i+1}.** ${s.title} \`${s.duration}\``).join('\n') : 'No songs yet.';
      return message.reply({ embeds: [Embed.custom({ title: `🎵 Playlist — ${name}`, description: desc })] });
    }
    message.reply({ embeds: [Embed.error('Unknown Action', 'Actions: `list`, `create`, `delete`, `show`.')] });
  }
};
