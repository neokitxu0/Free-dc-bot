const Embed = require('../../utils/Embed');

module.exports = {
  name: 'queue',
  aliases: ['q'],
  description: 'View the music queue',
  usage: 'queue [page]',
  category: 'music',
  cooldown: 5,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || !queue.songs.length) return message.reply({ embeds: [Embed.info('Empty Queue', 'No songs in the queue.')] });
    const page = Math.max(1, parseInt(args[0]) || 1);
    const perPage = 10;
    const pages = Math.ceil(queue.songs.length / perPage);
    const slice = queue.songs.slice((page - 1) * perPage, page * perPage);
    const desc = slice.map((s, i) => {
      const num = (page - 1) * perPage + i;
      return `${num === 0 ? '▶️' : `**${num}.**`} [${s.title}](${s.url}) \`${s.duration}\``;
    }).join('\n');
    message.reply({ embeds: [Embed.custom({
      title: `🎵 Queue — ${message.guild.name}`,
      description: desc,
      footer: { text: `Page ${page}/${pages} | ${queue.songs.length} songs | Loop: ${queue.loop || 'off'}` }
    })] });
  }
};
