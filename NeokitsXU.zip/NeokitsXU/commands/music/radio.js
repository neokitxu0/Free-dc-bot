const Embed = require('../../utils/Embed');

const stations = {
  'lofi': { name: 'Lo-Fi Hip Hop', url: 'https://www.youtube.com/watch?v=jfKfPfyJRdk' },
  'jazz': { name: 'Jazz Radio', url: 'https://www.youtube.com/watch?v=Dx5qFachd3A' },
  'chillpop': { name: 'Chill Pop', url: 'https://www.youtube.com/watch?v=H_OTYIPxJFA' },
  'classical': { name: 'Classical Music', url: 'https://www.youtube.com/watch?v=tvVs5bszmXg' },
};

module.exports = {
  name: 'radio',
  description: 'Play a 24/7 radio station',
  usage: 'radio <station|list>',
  category: 'music',
  cooldown: 5,
  async execute(client, message, args) {
    if (!args[0] || args[0]?.toLowerCase() === 'list') {
      const list = Object.entries(stations).map(([k, v]) => `\`${k}\` — ${v.name}`).join('\n');
      return message.reply({ embeds: [Embed.info('📻 Radio Stations', list)] });
    }
    const station = stations[args[0].toLowerCase()];
    if (!station) return message.reply({ embeds: [Embed.error('Unknown Station', 'Use `radio list` to see available stations.')] });
    const fakeArgs = [station.url];
    const play = client.commands.get('play');
    if (play) await play.execute(client, message, fakeArgs);
  }
};
