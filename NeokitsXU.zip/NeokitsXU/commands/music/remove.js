const Embed = require('../../utils/Embed');

module.exports = {
  name: 'remove',
  description: 'Remove a song from the queue',
  usage: 'remove <position>',
  category: 'music',
  cooldown: 3,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || !queue.songs.length) return message.reply({ embeds: [Embed.error('Empty Queue', 'The queue is empty.')] });
    const pos = parseInt(args[0]);
    if (!pos || pos < 1 || pos >= queue.songs.length) return message.reply({ embeds: [Embed.error('Invalid Position', `Provide a position between 1 and ${queue.songs.length - 1}.`)] });
    const removed = queue.songs.splice(pos, 1)[0];
    message.reply({ embeds: [Embed.success('Removed', `Removed **${removed.title}** from position ${pos}.`)] });
  }
};
