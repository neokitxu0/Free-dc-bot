const Embed = require('../../utils/Embed');

module.exports = {
  name: 'resume',
  description: 'Resume the paused song',
  usage: 'resume',
  category: 'music',
  cooldown: 3,
  async execute(client, message) {
    const queue = client.queue.get(message.guild.id);
    if (!queue) return message.reply({ embeds: [Embed.error('Not Playing', 'No music is playing.')] });
    if (!queue.paused) return message.reply({ embeds: [Embed.warn('Not Paused', 'Music is not paused.')] });
    queue.player.unpause();
    queue.paused = false;
    message.reply({ embeds: [Embed.success('▶️ Resumed', 'Music has been resumed.')] });
  }
};
