const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'save',
  description: 'Save the current song to a playlist',
  usage: 'save <playlist name>',
  category: 'music',
  cooldown: 5,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || !queue.songs.length) return message.reply({ embeds: [Embed.error('Not Playing', 'No song is currently playing.')] });
    const name = args.join(' ');
    if (!name) return message.reply({ embeds: [Embed.error('Missing Name', 'Provide a playlist name to save to.')] });
    const playlists = DataManager.ensure('playlists', message.author.id, {});
    if (!playlists[name]) return message.reply({ embeds: [Embed.error('Not Found', `Playlist **${name}** not found. Create it with \`playlist create ${name}\`.`)] });
    const song = queue.songs[0];
    playlists[name].push({ title: song.title, url: song.url, duration: song.duration, thumbnail: song.thumbnail });
    DataManager.set('playlists', message.author.id, playlists);
    message.reply({ embeds: [Embed.success('Saved', `Saved **${song.title}** to playlist **${name}**.`)] });
  }
};
