const Embed = require('../../utils/Embed');

module.exports = {
  name: 'seek',
  description: 'Seek to a position in the current song',
  usage: 'seek <time> (e.g. 1:30)',
  category: 'music',
  cooldown: 5,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || !queue.playing) return message.reply({ embeds: [Embed.error('Not Playing', 'No music is currently playing.')] });
    const timeStr = args[0];
    if (!timeStr) return message.reply({ embeds: [Embed.error('Missing Time', 'Provide a time (e.g. `1:30` or `90`).')] });
    let seconds;
    if (timeStr.includes(':')) {
      const parts = timeStr.split(':');
      seconds = parseInt(parts[0]) * 60 + parseInt(parts[1]);
    } else {
      seconds = parseInt(timeStr);
    }
    if (isNaN(seconds) || seconds < 0) return message.reply({ embeds: [Embed.error('Invalid Time', 'Provide a valid time.')] });
    const fmtTime = s => `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;
    message.reply({ embeds: [Embed.info('⏩ Seeking', `Seeking to **${fmtTime(seconds)}**...\n\n*Note: Seek is dependent on play-dl support for the current stream.*`)] });
  }
};
