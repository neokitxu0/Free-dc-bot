const Embed = require('../../utils/Embed');

module.exports = {
  name: 'shuffle',
  description: 'Shuffle the music queue',
  usage: 'shuffle',
  category: 'music',
  cooldown: 5,
  async execute(client, message) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || queue.songs.length < 2) return message.reply({ embeds: [Embed.error('Not Enough Songs', 'Need at least 2 songs to shuffle.')] });
    const current = queue.songs.shift();
    for (let i = queue.songs.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [queue.songs[i], queue.songs[j]] = [queue.songs[j], queue.songs[i]];
    }
    queue.songs.unshift(current);
    message.reply({ embeds: [Embed.success('🔀 Shuffled', `Queue shuffled! **${queue.songs.length}** songs.`)] });
  }
};
