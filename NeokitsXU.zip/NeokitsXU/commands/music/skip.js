const Embed = require('../../utils/Embed');

module.exports = {
  name: 'skip',
  aliases: ['s', 'next'],
  description: 'Skip the current song',
  usage: 'skip',
  category: 'music',
  cooldown: 3,
  async execute(client, message) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || !queue.playing) return message.reply({ embeds: [Embed.error('Not Playing', 'No music is playing.')] });
    if (!message.member.voice.channel) return message.reply({ embeds: [Embed.error('Not in Voice', 'You must be in a voice channel!')] });
    queue.player.stop();
    message.reply({ embeds: [Embed.success('⏭️ Skipped', `Skipped **${queue.songs[0]?.title || 'current song'}**.`)] });
  }
};
