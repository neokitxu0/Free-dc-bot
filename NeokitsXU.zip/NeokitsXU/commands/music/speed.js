const Embed = require('../../utils/Embed');

module.exports = {
  name: 'speed',
  description: 'Set playback speed',
  usage: 'speed <0.5-2.0>',
  category: 'music',
  cooldown: 5,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || !queue.playing) return message.reply({ embeds: [Embed.error('Not Playing', 'No music is playing.')] });
    const speed = parseFloat(args[0]);
    if (isNaN(speed) || speed < 0.5 || speed > 2.0) return message.reply({ embeds: [Embed.error('Invalid Speed', 'Speed must be between 0.5 and 2.0.')] });
    queue.speed = speed;
    message.reply({ embeds: [Embed.success('⚡ Speed', `Playback speed set to **${speed}x**.`)] });
  }
};
