const Embed = require('../../utils/Embed');

module.exports = {
  name: 'stop',
  description: 'Stop music and clear the queue',
  usage: 'stop',
  category: 'music',
  cooldown: 3,
  async execute(client, message) {
    const queue = client.queue.get(message.guild.id);
    if (!queue) return message.reply({ embeds: [Embed.error('Not Playing', 'No music is playing.')] });
    if (!message.member.voice.channel) return message.reply({ embeds: [Embed.error('Not in Voice', 'You must be in a voice channel!')] });
    queue.songs = [];
    queue.player.stop();
    client.queue.delete(message.guild.id);
    message.reply({ embeds: [Embed.success('⏹️ Stopped', 'Music stopped and queue cleared.')] });
  }
};
