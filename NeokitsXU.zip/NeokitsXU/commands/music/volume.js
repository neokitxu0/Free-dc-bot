const Embed = require('../../utils/Embed');

module.exports = {
  name: 'volume',
  aliases: ['vol', 'v'],
  description: 'Set the playback volume',
  usage: 'volume <1-200>',
  category: 'music',
  cooldown: 3,
  async execute(client, message, args) {
    const queue = client.queue.get(message.guild.id);
    if (!queue || !queue.playing) return message.reply({ embeds: [Embed.error('Not Playing', 'No music is playing.')] });
    if (!args[0]) return message.reply({ embeds: [Embed.info('Volume', `Current volume: **${queue.volume || 100}%**`)] });
    const vol = parseInt(args[0]);
    if (isNaN(vol) || vol < 1 || vol > 200) return message.reply({ embeds: [Embed.error('Invalid', 'Volume must be between 1 and 200.')] });
    queue.volume = vol;
    if (queue.resource) queue.resource.volume?.setVolumeLogarithmic(vol / 100);
    message.reply({ embeds: [Embed.success('🔊 Volume', `Volume set to **${vol}%**`)] });
  }
};
