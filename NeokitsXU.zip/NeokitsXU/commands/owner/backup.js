const Embed = require('../../utils/Embed');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'backup',
  description: 'Create a backup of all data files',
  usage: 'backup',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message) {
    const dataDir = path.join(__dirname, '../../data');
    const backupDir = path.join(__dirname, '../../data/backups');
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
    const ts = new Date().toISOString().replace(/[:.]/g, '-');
    const files = fs.readdirSync(dataDir).filter(f => f.endsWith('.json'));
    let count = 0;
    for (const file of files) {
      const src = path.join(dataDir, file);
      const dst = path.join(backupDir, `${ts}-${file}`);
      fs.copyFileSync(src, dst);
      count++;
    }
    message.reply({ embeds: [Embed.success('💾 Backup Created', `Backed up **${count}** data file(s).\nTimestamp: \`${ts}\``)] });
  }
};
