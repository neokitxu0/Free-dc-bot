const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'blacklist',
  description: 'Blacklist a user from using the bot',
  usage: 'blacklist <@user|userID>',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const userId = message.mentions.users.first()?.id || args[0];
    if (!userId) return message.reply({ embeds: [Embed.error('Usage', 'blacklist <@user|userID>')] });
    const bl = DataManager.ensure('blacklist', 'global', []);
    if (bl.includes(userId)) return message.reply({ embeds: [Embed.warn('Already Blacklisted', `User \`${userId}\` is already blacklisted.`)] });
    bl.push(userId);
    DataManager.set('blacklist', 'global', bl);
    client.blacklist = new Set(bl);
    message.reply({ embeds: [Embed.success('Blacklisted', `User \`${userId}\` has been blacklisted from using the bot.`)] });
  }
};
