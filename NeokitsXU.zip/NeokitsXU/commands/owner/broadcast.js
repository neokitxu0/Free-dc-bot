const Embed = require('../../utils/Embed');

module.exports = {
  name: 'broadcast',
  description: 'Send a message to all server owners',
  usage: 'broadcast <message>',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const text = args.join(' ');
    if (!text) return message.reply({ embeds: [Embed.error('Missing Message', 'Provide a message to broadcast.')] });
    let sent = 0, failed = 0;
    for (const [, guild] of client.guilds.cache) {
      try {
        const owner = await guild.fetchOwner();
        await owner.send({ embeds: [Embed.custom({ title: `📢 Bot Announcement`, description: text, footer: { text: `From ${client.user.username} owner` } })] });
        sent++;
      } catch { failed++; }
    }
    message.reply({ embeds: [Embed.success('Broadcast Sent', `Sent to **${sent}** owners. **${failed}** failed.`)] });
  }
};
