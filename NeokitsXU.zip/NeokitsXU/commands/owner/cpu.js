const Embed = require('../../utils/Embed');
const os = require('os');

module.exports = {
  name: 'cpu',
  description: 'View CPU usage and information',
  usage: 'cpu',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message) {
    const cpus = os.cpus();
    const cpu = cpus[0];
    const usage = process.cpuUsage();
    message.reply({ embeds: [Embed.custom({
      title: '⚙️ CPU Information',
      fields: [
        { name: 'Model', value: cpu.model, inline: false },
        { name: 'Cores', value: `${cpus.length}`, inline: true },
        { name: 'Speed', value: `${cpu.speed} MHz`, inline: true },
        { name: 'Platform', value: `${os.platform()} ${os.arch()}`, inline: true },
        { name: 'User CPU', value: `${(usage.user / 1000).toFixed(2)} ms`, inline: true },
        { name: 'System CPU', value: `${(usage.system / 1000).toFixed(2)} ms`, inline: true },
        { name: 'Load Average', value: os.loadavg().map(l => l.toFixed(2)).join(', '), inline: false },
      ]
    })] });
  }
};
