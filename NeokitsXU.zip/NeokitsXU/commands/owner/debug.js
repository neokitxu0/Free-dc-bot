const Embed = require('../../utils/Embed');

module.exports = {
  name: 'debug',
  description: 'Run diagnostic checks',
  usage: 'debug',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message) {
    const issues = [];
    if (!client.config.prefix) issues.push('❌ No prefix configured');
    if (!client.config.ownerId) issues.push('❌ No owner ID configured');
    if (!client.commands.size) issues.push('❌ No commands loaded');
    if (!client.queue) issues.push('⚠️ Music queue not initialized');
    const mem = process.memoryUsage();
    const memUsed = (mem.heapUsed / 1024 / 1024).toFixed(2);
    if (parseFloat(memUsed) > 400) issues.push(`⚠️ High memory usage: ${memUsed} MB`);
    if (!issues.length) issues.push('✅ All systems operational');
    message.reply({ embeds: [Embed.custom({
      title: '🔍 Diagnostic Report',
      description: issues.join('\n'),
      fields: [
        { name: 'Commands Loaded', value: `${client.commands.size}`, inline: true },
        { name: 'Guilds', value: `${client.guilds.cache.size}`, inline: true },
        { name: 'Heap', value: `${memUsed} MB`, inline: true },
        { name: 'WS Status', value: `${client.ws.status}`, inline: true },
        { name: 'Ping', value: `${client.ws.ping}ms`, inline: true },
        { name: 'Config OK', value: `${!!client.config}`, inline: true },
      ]
    })] });
  }
};
