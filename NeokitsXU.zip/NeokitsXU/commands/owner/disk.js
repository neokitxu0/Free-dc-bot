const Embed = require('../../utils/Embed');
const { execSync } = require('child_process');

module.exports = {
  name: 'disk',
  description: 'View disk usage',
  usage: 'disk',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message) {
    let diskInfo = 'Not available on this platform.';
    try {
      diskInfo = execSync('df -h .').toString();
    } catch {}
    message.reply({ embeds: [Embed.custom({ title: '💿 Disk Usage', description: `\`\`\`\n${diskInfo.slice(0, 1800)}\n\`\`\`` })] });
  }
};
