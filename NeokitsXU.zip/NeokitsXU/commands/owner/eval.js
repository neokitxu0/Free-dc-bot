const Embed = require('../../utils/Embed');

module.exports = {
  name: 'eval',
  description: 'Execute JavaScript code',
  usage: 'eval <code>',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const code = args.join(' ');
    if (!code) return message.reply({ embeds: [Embed.error('Missing Code', 'Provide code to evaluate.')] });
    try {
      let result = eval(code);
      if (result instanceof Promise) result = await result;
      if (typeof result !== 'string') result = require('util').inspect(result, { depth: 1 });
      if (result.length > 1900) result = result.slice(0, 1900) + '...';
      result = result.replace(client.token, '[REDACTED]');
      message.reply({ embeds: [Embed.custom({ title: '✅ Eval', description: `\`\`\`js\n${result}\n\`\`\`` })] });
    } catch (e) {
      message.reply({ embeds: [Embed.error('Error', `\`\`\`js\n${e.message}\n\`\`\``)] });
    }
  }
};
