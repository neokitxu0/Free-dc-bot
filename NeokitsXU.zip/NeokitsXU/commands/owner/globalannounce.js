const Embed = require('../../utils/Embed');

module.exports = {
  name: 'globalannounce',
  aliases: ['gannounce'],
  description: 'Send an announcement to the first channel of all servers',
  usage: 'globalannounce <message>',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const text = args.join(' ');
    if (!text) return message.reply({ embeds: [Embed.error('Missing Message', 'Provide an announcement message.')] });
    let sent = 0, failed = 0;
    for (const [, guild] of client.guilds.cache) {
      const ch = guild.channels.cache.filter(c => c.type === 0 && c.permissionsFor(guild.members.me)?.has('SendMessages')).first();
      if (!ch) { failed++; continue; }
      await ch.send({ embeds: [Embed.custom({ title: `📢 Global Announcement`, description: text, footer: { text: `Official announcement from ${client.user.username}` } })] }).then(() => sent++).catch(() => failed++);
    }
    message.reply({ embeds: [Embed.success('Announced', `Sent to **${sent}** servers. **${failed}** failed.`)] });
  }
};
