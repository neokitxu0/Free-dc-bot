const Embed = require('../../utils/Embed');

module.exports = {
  name: 'guilds',
  aliases: ['servers'],
  description: 'List all guilds the bot is in',
  usage: 'guilds [page]',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const page = Math.max(1, parseInt(args[0]) || 1);
    const perPage = 10;
    const all = [...client.guilds.cache.values()];
    const pages = Math.ceil(all.length / perPage);
    const slice = all.slice((page - 1) * perPage, page * perPage);
    const desc = slice.map(g => `**${g.name}** (${g.memberCount} members) — \`${g.id}\``).join('\n');
    message.reply({ embeds: [Embed.custom({ title: `🌍 Guilds (${all.length} total)`, description: desc, footer: { text: `Page ${page}/${pages}` } })] });
  }
};
