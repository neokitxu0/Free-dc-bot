const Embed = require('../../utils/Embed');

module.exports = {
  name: 'latency',
  description: 'View detailed latency information',
  usage: 'latency',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message) {
    const start = Date.now();
    const sent = await message.reply({ embeds: [Embed.info('Testing...', 'Calculating latencies...')] });
    const msgLatency = sent.createdTimestamp - message.createdTimestamp;
    const apiLatency = Math.round(client.ws.ping);
    const roundtrip = Date.now() - start;
    sent.edit({ embeds: [Embed.custom({
      title: '📡 Latency Report',
      fields: [
        { name: 'Bot Latency', value: `${msgLatency}ms`, inline: true },
        { name: 'API Latency', value: `${apiLatency}ms`, inline: true },
        { name: 'Round Trip', value: `${roundtrip}ms`, inline: true },
      ]
    })] });
  }
};
