const Embed = require('../../utils/Embed');

module.exports = {
  name: 'leaveserver',
  description: 'Force the bot to leave a server',
  usage: 'leaveserver <guildID>',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const guildId = args[0];
    if (!guildId) return message.reply({ embeds: [Embed.error('Missing ID', 'Provide a guild ID.')] });
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return message.reply({ embeds: [Embed.error('Not Found', `Guild \`${guildId}\` not found.`)] });
    const name = guild.name;
    await guild.leave().catch(() => {});
    message.reply({ embeds: [Embed.success('Left Server', `Left **${name}** (\`${guildId}\`).`)] });
  }
};
