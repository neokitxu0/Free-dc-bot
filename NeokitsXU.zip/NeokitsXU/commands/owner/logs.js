const Embed = require('../../utils/Embed');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'logs',
  description: 'View the latest bot log',
  usage: 'logs [lines]',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const lines = Math.min(parseInt(args[0]) || 20, 50);
    const logDir = path.join(__dirname, '../../logs');
    if (!fs.existsSync(logDir)) return message.reply({ embeds: [Embed.info('No Logs', 'No log directory found.')] });
    const files = fs.readdirSync(logDir).filter(f => f.endsWith('.log')).sort((a, b) => {
      return fs.statSync(path.join(logDir, b)).mtime - fs.statSync(path.join(logDir, a)).mtime;
    });
    if (!files.length) return message.reply({ embeds: [Embed.info('No Logs', 'No log files found.')] });
    const content = fs.readFileSync(path.join(logDir, files[0]), 'utf8').split('\n').slice(-lines).join('\n');
    const display = content.slice(-1800) || 'Empty log file.';
    message.reply({ embeds: [Embed.custom({ title: `📋 Log — ${files[0]}`, description: `\`\`\`\n${display}\n\`\`\`` })] });
  }
};
