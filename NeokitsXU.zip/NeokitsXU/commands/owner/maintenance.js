const Embed = require('../../utils/Embed');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'maintenance',
  description: 'Toggle maintenance mode (only owner can use commands)',
  usage: 'maintenance <on|off>',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const toggle = args[0]?.toLowerCase();
    if (!['on', 'off'].includes(toggle)) return message.reply({ embeds: [Embed.error('Usage', 'maintenance <on|off>')] });
    client.config.maintenance = toggle === 'on';
    const cfgPath = path.join(__dirname, '../../config/config.json');
    fs.writeFileSync(cfgPath, JSON.stringify(client.config, null, 2));
    message.reply({ embeds: [Embed.custom({
      title: toggle === 'on' ? '🔧 Maintenance Mode ON' : '✅ Maintenance Mode OFF',
      description: toggle === 'on' ? 'Bot is now in maintenance mode. Only the owner can use commands.' : 'Bot is back online for all users.',
      color: toggle === 'on' ? '#FEE75C' : '#57F287'
    })] });
  }
};
