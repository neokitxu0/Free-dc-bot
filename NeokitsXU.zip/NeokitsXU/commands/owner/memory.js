const Embed = require('../../utils/Embed');
const os = require('os');

module.exports = {
  name: 'memory',
  aliases: ['mem', 'ram'],
  description: 'View memory usage',
  usage: 'memory',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message) {
    const m = process.memoryUsage();
    const total = os.totalmem() / 1024 / 1024;
    const free = os.freemem() / 1024 / 1024;
    const used = total - free;
    message.reply({ embeds: [Embed.custom({
      title: '💾 Memory Usage',
      fields: [
        { name: 'Heap Used', value: `${(m.heapUsed / 1024 / 1024).toFixed(2)} MB`, inline: true },
        { name: 'Heap Total', value: `${(m.heapTotal / 1024 / 1024).toFixed(2)} MB`, inline: true },
        { name: 'RSS', value: `${(m.rss / 1024 / 1024).toFixed(2)} MB`, inline: true },
        { name: 'External', value: `${(m.external / 1024 / 1024).toFixed(2)} MB`, inline: true },
        { name: 'System Used', value: `${used.toFixed(0)} MB / ${total.toFixed(0)} MB`, inline: true },
        { name: 'System Free', value: `${free.toFixed(0)} MB`, inline: true },
      ]
    })] });
  }
};
