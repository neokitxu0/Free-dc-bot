const Embed = require('../../utils/Embed');
const os = require('os');

module.exports = {
  name: 'network',
  aliases: ['net'],
  description: 'View network interfaces',
  usage: 'network',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message) {
    const ifaces = os.networkInterfaces();
    const fields = Object.entries(ifaces).slice(0, 5).map(([name, addrs]) => ({
      name,
      value: addrs.filter(a => !a.internal).map(a => `${a.family}: ${a.address}`).join('\n') || 'Internal only',
      inline: true
    }));
    if (!fields.length) return message.reply({ embeds: [Embed.info('Network', 'No external network interfaces found.')] });
    message.reply({ embeds: [Embed.custom({ title: '🌐 Network Interfaces', fields })] });
  }
};
