const Embed = require('../../utils/Embed');
const os = require('os');

module.exports = {
  name: 'ownerinfo',
  description: 'View detailed owner/bot information',
  usage: 'ownerinfo',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message) {
    const uptime = Date.now() - client.startTime;
    const d = Math.floor(uptime / 86400000), h = Math.floor((uptime % 86400000) / 3600000);
    const mem = process.memoryUsage();
    message.reply({ embeds: [Embed.custom({
      title: `🤖 Owner Info — ${client.user.username}`,
      thumbnail: client.user.displayAvatarURL({ dynamic: true }),
      fields: [
        { name: 'Owner', value: `<@${client.config.ownerId}>`, inline: true },
        { name: 'Uptime', value: `${d}d ${h}h`, inline: true },
        { name: 'Guilds', value: `${client.guilds.cache.size}`, inline: true },
        { name: 'Users', value: `${client.users.cache.size}`, inline: true },
        { name: 'Heap', value: `${(mem.heapUsed / 1024 / 1024).toFixed(2)} MB`, inline: true },
        { name: 'RSS', value: `${(mem.rss / 1024 / 1024).toFixed(2)} MB`, inline: true },
        { name: 'Node.js', value: process.version, inline: true },
        { name: 'OS', value: `${os.type()} ${os.arch()}`, inline: true },
        { name: 'Commands', value: `${client.commands.size}`, inline: true },
      ]
    })] });
  }
};
