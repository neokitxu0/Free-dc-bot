const Embed = require('../../utils/Embed');
const path = require('path');
const fs = require('fs');

module.exports = {
  name: 'reload',
  description: 'Reload a specific command',
  usage: 'reload <command>',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const cmdName = args[0]?.toLowerCase();
    if (!cmdName) return message.reply({ embeds: [Embed.error('Missing Command', 'Provide a command name to reload.')] });
    const cmd = client.commands.get(cmdName) || client.commands.get(client.aliases.get(cmdName));
    if (!cmd) return message.reply({ embeds: [Embed.error('Not Found', `Command \`${cmdName}\` not found.`)] });
    const cats = fs.readdirSync(path.join(__dirname, '..'));
    let filePath;
    for (const cat of cats) {
      const p = path.join(__dirname, '..', cat, `${cmd.name}.js`);
      if (fs.existsSync(p)) { filePath = p; break; }
    }
    if (!filePath) return message.reply({ embeds: [Embed.error('Not Found', `File for \`${cmd.name}\` not found.`)] });
    delete require.cache[require.resolve(filePath)];
    const newCmd = require(filePath);
    client.commands.set(newCmd.name, newCmd);
    if (newCmd.aliases) newCmd.aliases.forEach(a => client.aliases.set(a, newCmd.name));
    message.reply({ embeds: [Embed.success('Reloaded', `Command \`${newCmd.name}\` has been reloaded.`)] });
  }
};
