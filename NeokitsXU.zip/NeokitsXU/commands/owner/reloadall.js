const Embed = require('../../utils/Embed');
const path = require('path');
const fs = require('fs');

module.exports = {
  name: 'reloadall',
  description: 'Reload all commands',
  usage: 'reloadall',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message) {
    client.commands.clear();
    client.aliases.clear();
    const cats = fs.readdirSync(path.join(__dirname, '..'));
    let loaded = 0;
    for (const cat of cats) {
      const files = fs.readdirSync(path.join(__dirname, '..', cat)).filter(f => f.endsWith('.js'));
      for (const file of files) {
        const fp = path.join(__dirname, '..', cat, file);
        delete require.cache[require.resolve(fp)];
        try {
          const cmd = require(fp);
          client.commands.set(cmd.name, cmd);
          if (cmd.aliases) cmd.aliases.forEach(a => client.aliases.set(a, cmd.name));
          loaded++;
        } catch {}
      }
    }
    message.reply({ embeds: [Embed.success('Reloaded All', `Reloaded **${loaded}** commands.`)] });
  }
};
