const Embed = require('../../utils/Embed');
const { exec } = require('child_process');

module.exports = {
  name: 'restart',
  description: 'Restart the bot',
  usage: 'restart',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message) {
    await message.reply({ embeds: [Embed.warn('🔄 Restarting', 'Bot is restarting...')] });
    exec('node .', { detached: true, stdio: 'ignore' }).unref();
    client.destroy();
    process.exit(0);
  }
};
