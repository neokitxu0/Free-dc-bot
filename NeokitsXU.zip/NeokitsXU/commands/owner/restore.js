const Embed = require('../../utils/Embed');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'restore',
  description: 'List available backups',
  usage: 'restore',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message) {
    const backupDir = path.join(__dirname, '../../data/backups');
    if (!fs.existsSync(backupDir)) return message.reply({ embeds: [Embed.info('No Backups', 'No backups exist yet. Use `backup` to create one.')] });
    const files = fs.readdirSync(backupDir).filter(f => f.endsWith('.json')).slice(-20);
    if (!files.length) return message.reply({ embeds: [Embed.info('No Backups', 'No backup files found.')] });
    const groupedByTs = {};
    for (const f of files) {
      const ts = f.split('-').slice(0, 3).join('-');
      if (!groupedByTs[ts]) groupedByTs[ts] = 0;
      groupedByTs[ts]++;
    }
    const desc = Object.entries(groupedByTs).map(([ts, count]) => `\`${ts}\` — ${count} files`).join('\n');
    message.reply({ embeds: [Embed.custom({ title: '💾 Available Backups', description: desc })] });
  }
};
