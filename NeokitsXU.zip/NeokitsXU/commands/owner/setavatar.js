const Embed = require('../../utils/Embed');

module.exports = {
  name: 'setavatar',
  description: 'Change the bot\'s avatar',
  usage: 'setavatar <image URL>',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const url = args[0] || message.attachments.first()?.url;
    if (!url) return message.reply({ embeds: [Embed.error('Missing URL', 'Provide an image URL or attach an image.')] });
    await client.user.setAvatar(url).catch(() => null);
    message.reply({ embeds: [Embed.success('Avatar Updated', 'Bot avatar has been updated!'), { image: { url: client.user.displayAvatarURL({ size: 256 }) } }] });
  }
};
