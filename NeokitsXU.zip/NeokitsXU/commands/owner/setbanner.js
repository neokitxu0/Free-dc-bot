const Embed = require('../../utils/Embed');

module.exports = {
  name: 'setbanner',
  description: 'Change the bot\'s banner',
  usage: 'setbanner <image URL>',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const url = args[0] || message.attachments.first()?.url;
    if (!url) return message.reply({ embeds: [Embed.error('Missing URL', 'Provide an image URL or attach an image.')] });
    await client.user.setBanner(url).catch(() => null);
    message.reply({ embeds: [Embed.success('Banner Updated', 'Bot banner has been updated! (Requires Discord Nitro for the bot application.)')] });
  }
};
