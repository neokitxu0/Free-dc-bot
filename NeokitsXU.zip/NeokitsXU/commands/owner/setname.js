const Embed = require('../../utils/Embed');

module.exports = {
  name: 'setname',
  description: 'Change the bot\'s username',
  usage: 'setname <name>',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const name = args.join(' ');
    if (!name || name.length < 2 || name.length > 32) return message.reply({ embeds: [Embed.error('Invalid Name', 'Name must be 2-32 characters.')] });
    const oldName = client.user.username;
    await client.user.setUsername(name).catch(() => null);
    message.reply({ embeds: [Embed.success('Username Updated', `**${oldName}** → **${name}**`)] });
  }
};
