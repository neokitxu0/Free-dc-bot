const Embed = require('../../utils/Embed');

module.exports = {
  name: 'setstatus',
  description: 'Set the bot\'s status and activity',
  usage: 'setstatus <online|idle|dnd|invisible> [playing|watching|listening|competing] [text]',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const status = args[0]?.toLowerCase();
    const type = args[1]?.toLowerCase();
    const text = args.slice(2).join(' ');
    const validStatuses = ['online', 'idle', 'dnd', 'invisible'];
    const activityTypes = { playing: 0, streaming: 1, listening: 2, watching: 3, competing: 5 };
    if (!status || !validStatuses.includes(status)) return message.reply({ embeds: [Embed.error('Usage', 'setstatus <online|idle|dnd|invisible> [type] [text]')] });
    const presenceData = { status };
    if (type && text && activityTypes[type] !== undefined) {
      presenceData.activities = [{ name: text, type: activityTypes[type] }];
    }
    client.user.setPresence(presenceData);
    message.reply({ embeds: [Embed.success('Status Set', `Status: **${status}**${type && text ? ` | ${type}: **${text}**` : ''}`)] });
  }
};
