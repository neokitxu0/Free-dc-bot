const Embed = require('../../utils/Embed');
const { exec } = require('child_process');

module.exports = {
  name: 'shell',
  aliases: ['sh', 'exec'],
  description: 'Execute a shell command',
  usage: 'shell <command>',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const cmd = args.join(' ');
    if (!cmd) return message.reply({ embeds: [Embed.error('Missing Command', 'Provide a shell command.')] });
    const loading = await message.reply({ embeds: [Embed.info('⚙️ Executing...', `\`${cmd}\``)] });
    exec(cmd, { timeout: 15000 }, (err, stdout, stderr) => {
      const out = (stdout || stderr || 'No output').slice(0, 1900);
      loading.edit({ embeds: [Embed.custom({ title: err ? '❌ Shell Error' : '✅ Shell Output', description: `\`\`\`\n${out}\n\`\`\`` })] });
    });
  }
};
