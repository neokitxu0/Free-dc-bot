const Embed = require('../../utils/Embed');

module.exports = {
  name: 'shutdown',
  aliases: ['die', 'poweroff'],
  description: 'Shut down the bot',
  usage: 'shutdown',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message) {
    await message.reply({ embeds: [Embed.warn('👋 Shutting Down', 'Bot is shutting down...')] });
    client.destroy();
    process.exit(0);
  }
};
