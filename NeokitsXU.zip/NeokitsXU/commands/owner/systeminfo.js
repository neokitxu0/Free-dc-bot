const Embed = require('../../utils/Embed');
const os = require('os');

module.exports = {
  name: 'systeminfo',
  aliases: ['sysinfo', 'system'],
  description: 'Comprehensive system information',
  usage: 'systeminfo',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message) {
    const uptime = os.uptime();
    const d = Math.floor(uptime / 86400), h = Math.floor((uptime % 86400) / 3600), m = Math.floor((uptime % 3600) / 60);
    const mem = process.memoryUsage();
    const totalMem = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
    const freeMem = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);
    message.reply({ embeds: [Embed.custom({
      title: '🖥️ System Information',
      fields: [
        { name: 'OS', value: `${os.type()} ${os.release()} (${os.arch()})`, inline: false },
        { name: 'CPU', value: os.cpus()[0]?.model || 'Unknown', inline: false },
        { name: 'CPU Cores', value: `${os.cpus().length}`, inline: true },
        { name: 'CPU Speed', value: `${os.cpus()[0]?.speed || 0} MHz`, inline: true },
        { name: 'Total RAM', value: `${totalMem} GB`, inline: true },
        { name: 'Free RAM', value: `${freeMem} GB`, inline: true },
        { name: 'System Uptime', value: `${d}d ${h}h ${m}m`, inline: true },
        { name: 'Bot Heap', value: `${(mem.heapUsed / 1024 / 1024).toFixed(1)} MB`, inline: true },
        { name: 'Node.js', value: process.version, inline: true },
        { name: 'Hostname', value: os.hostname(), inline: true },
        { name: 'Load Avg', value: os.loadavg().map(l => l.toFixed(2)).join(' | '), inline: false },
      ]
    })] });
  }
};
