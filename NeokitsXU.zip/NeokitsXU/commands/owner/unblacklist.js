const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'unblacklist',
  description: 'Remove a user from the bot blacklist',
  usage: 'unblacklist <@user|userID>',
  category: 'owner',
  ownerOnly: true,
  async execute(client, message, args) {
    const userId = message.mentions.users.first()?.id || args[0];
    if (!userId) return message.reply({ embeds: [Embed.error('Usage', 'unblacklist <@user|userID>')] });
    const bl = DataManager.ensure('blacklist', 'global', []);
    const idx = bl.indexOf(userId);
    if (idx === -1) return message.reply({ embeds: [Embed.warn('Not Blacklisted', `User \`${userId}\` is not blacklisted.`)] });
    bl.splice(idx, 1);
    DataManager.set('blacklist', 'global', bl);
    client.blacklist = new Set(bl);
    message.reply({ embeds: [Embed.success('Unblacklisted', `User \`${userId}\` has been removed from the blacklist.`)] });
  }
};
