const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');
const { PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'adduser',
  description: 'Add a user to the current ticket',
  usage: 'adduser <@user>',
  category: 'ticket',
  cooldown: 5,
  async execute(client, message, args) {
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const ticket = tickets.find(t => t.channelId === message.channel.id && t.status === 'open');
    if (!ticket) return message.reply({ embeds: [Embed.error('Not a Ticket', 'Use this in a ticket channel.')] });
    const member = message.mentions.members.first();
    if (!member) return message.reply({ embeds: [Embed.error('Invalid', 'Mention a member to add.')] });
    await message.channel.permissionOverwrites.edit(member, {
      ViewChannel: true, SendMessages: true, ReadMessageHistory: true
    }).catch(() => {});
    message.reply({ embeds: [Embed.success('User Added', `${member} has been added to this ticket.`)] });
  }
};
