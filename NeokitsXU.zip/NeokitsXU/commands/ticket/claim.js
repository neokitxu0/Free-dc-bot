const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'claim',
  description: 'Claim the current ticket',
  usage: 'claim',
  category: 'ticket',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message) {
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const idx = tickets.findIndex(t => t.channelId === message.channel.id && t.status === 'open');
    if (idx === -1) return message.reply({ embeds: [Embed.error('Not a Ticket', 'Use this in a ticket channel.')] });
    if (tickets[idx].claimedBy) return message.reply({ embeds: [Embed.warn('Already Claimed', `This ticket is claimed by <@${tickets[idx].claimedBy}>.`)] });
    tickets[idx].claimedBy = message.author.id;
    DataManager.set('tickets', message.guild.id, tickets);
    message.reply({ embeds: [Embed.success('Claimed', `${message.author} has claimed this ticket.`)] });
  }
};
