const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'closeticket',
  aliases: ['close', 'tc'],
  description: 'Close the current ticket',
  usage: 'closeticket [reason]',
  category: 'ticket',
  cooldown: 5,
  async execute(client, message, args) {
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const ticket = tickets.find(t => t.channelId === message.channel.id && t.status === 'open');
    if (!ticket) return message.reply({ embeds: [Embed.error('Not a Ticket', 'This command can only be used in a ticket channel.')] });
    const reason = args.join(' ') || 'No reason provided';
    ticket.status = 'closed';
    ticket.closedBy = message.author.id;
    ticket.closedAt = Date.now();
    ticket.closeReason = reason;
    DataManager.set('tickets', message.guild.id, tickets);
    await message.channel.send({ embeds: [Embed.warn('Ticket Closing', `Closed by ${message.author}.\nReason: ${reason}\n\nThis channel will be deleted in 5 seconds.`)] });
    setTimeout(() => message.channel.delete().catch(() => {}), 5000);
  }
};
