const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'removeuser',
  description: 'Remove a user from the current ticket',
  usage: 'removeuser <@user>',
  category: 'ticket',
  cooldown: 5,
  async execute(client, message, args) {
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const ticket = tickets.find(t => t.channelId === message.channel.id && t.status === 'open');
    if (!ticket) return message.reply({ embeds: [Embed.error('Not a Ticket', 'Use this in a ticket channel.')] });
    const member = message.mentions.members.first();
    if (!member) return message.reply({ embeds: [Embed.error('Invalid', 'Mention a member to remove.')] });
    await message.channel.permissionOverwrites.edit(member, { ViewChannel: false }).catch(() => {});
    message.reply({ embeds: [Embed.success('User Removed', `${member} has been removed from this ticket.`)] });
  }
};
