const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'rename',
  description: 'Rename the current ticket channel',
  usage: 'rename <name>',
  category: 'ticket',
  userPermissions: ['ModerateMembers'],
  cooldown: 10,
  async execute(client, message, args) {
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const ticket = tickets.find(t => t.channelId === message.channel.id && t.status === 'open');
    if (!ticket) return message.reply({ embeds: [Embed.error('Not a Ticket', 'Use this in an open ticket channel.')] });
    const name = args.join('-').toLowerCase().replace(/[^a-z0-9-]/g, '');
    if (!name) return message.reply({ embeds: [Embed.error('Invalid Name', 'Provide a valid channel name.')] });
    await message.channel.setName(name).catch(() => {});
    message.reply({ embeds: [Embed.success('Renamed', `Ticket channel renamed to **${name}**.`)] });
  }
};
