const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');
const { PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'ticket',
  aliases: ['newticket', 'openticket'],
  description: 'Open a support ticket',
  usage: 'ticket [reason]',
  category: 'ticket',
  cooldown: 60,
  async execute(client, message, args) {
    const config = DataManager.get('ticketconfig', message.guild.id, {});
    const category = config.categoryId ? message.guild.channels.cache.get(config.categoryId) : null;
    const tickets = DataManager.ensure('tickets', message.guild.id, []);
    const existing = tickets.find(t => t.userId === message.author.id && t.status === 'open');
    if (existing) {
      const ch = message.guild.channels.cache.get(existing.channelId);
      if (ch) return message.reply({ embeds: [Embed.warn('Already Open', `You already have an open ticket: ${ch}`)] });
    }
    const ticketNum = (tickets.length + 1).toString().padStart(4, '0');
    const reason = args.join(' ') || 'No reason provided';
    let channel;
    try {
      channel = await message.guild.channels.create({
        name: `ticket-${ticketNum}`,
        type: 0,
        parent: category?.id || null,
        permissionOverwrites: [
          { id: message.guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
          { id: message.author.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] },
          { id: client.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] },
        ]
      });
    } catch (e) {
      return message.reply({ embeds: [Embed.error('Failed', 'Could not create ticket channel.')] });
    }
    const ticket = { id: ticketNum, userId: message.author.id, channelId: channel.id, reason, status: 'open', createdAt: Date.now(), claimedBy: null };
    tickets.push(ticket);
    DataManager.set('tickets', message.guild.id, tickets);
    const supportRole = config.supportRoleId ? `<@&${config.supportRoleId}>` : '';
    await channel.send({
      content: `${message.author} ${supportRole}`,
      embeds: [Embed.custom({
        title: `🎫 Ticket #${ticketNum}`,
        description: `Welcome ${message.author}!\n\nReason: **${reason}**\n\nA staff member will assist you shortly. Use \`${client.config.prefix}closeticket\` to close.`,
        footer: { text: `Ticket ID: ${ticketNum}` }
      })]
    });
    message.reply({ embeds: [Embed.success('Ticket Created', `Your ticket has been opened in ${channel}!`)] });
  }
};
