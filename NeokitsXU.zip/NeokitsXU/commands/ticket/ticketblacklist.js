const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'ticketblacklist',
  description: 'Blacklist a user from creating tickets',
  usage: 'ticketblacklist <@user>',
  category: 'ticket',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first();
    if (!target) return message.reply({ embeds: [Embed.error('Invalid', 'Mention a user to blacklist.')] });
    const bl = DataManager.ensure('ticketblacklist', message.guild.id, []);
    if (bl.includes(target.id)) {
      bl.splice(bl.indexOf(target.id), 1);
      DataManager.set('ticketblacklist', message.guild.id, bl);
      return message.reply({ embeds: [Embed.success('Removed from Blacklist', `**${target.user.tag}** can now create tickets again.`)] });
    }
    bl.push(target.id);
    DataManager.set('ticketblacklist', message.guild.id, bl);
    message.reply({ embeds: [Embed.success('Blacklisted', `**${target.user.tag}** has been blacklisted from creating tickets.`)] });
  }
};
