const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'ticketcategory',
  description: 'Set the category for new tickets',
  usage: 'ticketcategory <categoryID>',
  category: 'ticket',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const cat = message.guild.channels.cache.get(args[0]);
    if (!cat || cat.type !== 4) return message.reply({ embeds: [Embed.error('Invalid', 'Provide a valid category ID.')] });
    const cfg = DataManager.ensure('ticketconfig', message.guild.id, {});
    cfg.categoryId = cat.id;
    DataManager.set('ticketconfig', message.guild.id, cfg);
    message.reply({ embeds: [Embed.success('Category Set', `New tickets will be created under **${cat.name}**.`)] });
  }
};
