const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'ticketcloseall',
  description: 'Close all open tickets in the server',
  usage: 'ticketcloseall',
  category: 'ticket',
  userPermissions: ['Administrator'],
  cooldown: 30,
  async execute(client, message) {
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const open = tickets.filter(t => t.status === 'open');
    if (!open.length) return message.reply({ embeds: [Embed.info('None Open', 'There are no open tickets.')] });
    let closed = 0;
    for (const ticket of open) {
      ticket.status = 'closed';
      ticket.closedBy = client.user.id;
      ticket.closedAt = Date.now();
      const ch = message.guild.channels.cache.get(ticket.channelId);
      if (ch) await ch.delete('Mass ticket close').then(() => closed++).catch(() => {});
    }
    DataManager.set('tickets', message.guild.id, tickets);
    message.reply({ embeds: [Embed.success('All Closed', `Closed **${closed}** ticket(s).`)] });
  }
};
