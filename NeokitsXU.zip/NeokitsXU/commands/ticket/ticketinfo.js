const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'ticketinfo',
  description: 'View info about the current ticket',
  usage: 'ticketinfo',
  category: 'ticket',
  cooldown: 5,
  async execute(client, message) {
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const ticket = tickets.find(t => t.channelId === message.channel.id);
    if (!ticket) return message.reply({ embeds: [Embed.error('Not a Ticket', 'This command must be used in a ticket channel.')] });
    message.reply({ embeds: [Embed.custom({
      title: `🎫 Ticket Info #${ticket.id}`,
      fields: [
        { name: 'Status', value: ticket.status.toUpperCase(), inline: true },
        { name: 'Opened by', value: `<@${ticket.userId}>`, inline: true },
        { name: 'Claimed by', value: ticket.claimedBy ? `<@${ticket.claimedBy}>` : 'Unclaimed', inline: true },
        { name: 'Reason', value: ticket.reason, inline: false },
        { name: 'Priority', value: ticket.priority || 'Not set', inline: true },
        { name: 'Created', value: `<t:${Math.floor(ticket.createdAt / 1000)}:R>`, inline: true },
      ]
    })] });
  }
};
