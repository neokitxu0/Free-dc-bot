const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'ticketlogs',
  description: 'View recent ticket activity logs',
  usage: 'ticketlogs [page]',
  category: 'ticket',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const closed = tickets.filter(t => t.status === 'closed').reverse().slice(0, 10);
    if (!closed.length) return message.reply({ embeds: [Embed.info('No Logs', 'No closed tickets yet.')] });
    const fields = closed.map(t => ({
      name: `Ticket #${t.id}`,
      value: `User: <@${t.userId}>\nClosed by: <@${t.closedBy || 'Unknown'}>\nReason: ${t.closeReason || 'None'}\nTime: <t:${Math.floor((t.closedAt || t.createdAt) / 1000)}:R>`,
      inline: false
    }));
    message.reply({ embeds: [Embed.custom({ title: `🎫 Ticket Logs — ${message.guild.name}`, fields })] });
  }
};
