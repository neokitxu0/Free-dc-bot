const Embed = require('../../utils/Embed');
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  name: 'ticketpanel',
  description: 'Send the ticket panel to a channel',
  usage: 'ticketpanel [#channel]',
  category: 'ticket',
  userPermissions: ['Administrator'],
  cooldown: 10,
  async execute(client, message, args) {
    const channel = message.mentions.channels.first() || message.channel;
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('create_ticket').setLabel('🎫 Create Ticket').setStyle(ButtonStyle.Primary),
    );
    await channel.send({
      embeds: [Embed.custom({
        title: '🎫 Support Tickets',
        description: 'Click the button below to open a support ticket.\n\nOur staff team will assist you shortly.',
        color: '#5865F2',
        footer: { text: message.guild.name }
      })],
      components: [row]
    });
    message.reply({ embeds: [Embed.success('Panel Sent', `Ticket panel sent to ${channel}.`)] });
  }
};
