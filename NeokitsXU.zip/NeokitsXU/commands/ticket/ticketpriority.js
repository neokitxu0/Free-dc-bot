const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'ticketpriority',
  description: 'Set the priority of the current ticket',
  usage: 'ticketpriority <low|medium|high|critical>',
  category: 'ticket',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const priorities = { low: '🟢', medium: '🟡', high: '🟠', critical: '🔴' };
    const priority = args[0]?.toLowerCase();
    if (!priorities[priority]) return message.reply({ embeds: [Embed.error('Invalid', 'Priority must be: low, medium, high, or critical.')] });
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const idx = tickets.findIndex(t => t.channelId === message.channel.id && t.status === 'open');
    if (idx === -1) return message.reply({ embeds: [Embed.error('Not a Ticket', 'Use this in an open ticket channel.')] });
    tickets[idx].priority = priority;
    DataManager.set('tickets', message.guild.id, tickets);
    await message.channel.setName(`${priorities[priority]}-${message.channel.name.replace(/^[🟢🟡🟠🔴]-?/, '')}`).catch(() => {});
    message.reply({ embeds: [Embed.success('Priority Set', `Ticket priority set to **${priority}** ${priorities[priority]}.`)] });
  }
};
