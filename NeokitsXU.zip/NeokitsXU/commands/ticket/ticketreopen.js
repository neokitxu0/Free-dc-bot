const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'ticketreopen',
  description: 'Reopen a closed ticket by ID',
  usage: 'ticketreopen <ticketID>',
  category: 'ticket',
  userPermissions: ['ModerateMembers'],
  cooldown: 10,
  async execute(client, message, args) {
    const id = args[0]?.padStart(4, '0');
    if (!id) return message.reply({ embeds: [Embed.error('Usage', 'ticketreopen <ticketID>')] });
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const idx = tickets.findIndex(t => t.id === id);
    if (idx === -1) return message.reply({ embeds: [Embed.error('Not Found', `Ticket \`${id}\` not found.`)] });
    if (tickets[idx].status === 'open') return message.reply({ embeds: [Embed.warn('Already Open', 'That ticket is already open.')] });
    message.reply({ embeds: [Embed.info('Note', 'This ticket\'s channel was deleted. A new one cannot be automatically created. Please use the ticket command to create a new one.')] });
  }
};
