const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'ticketsetup',
  description: 'Setup the ticket system',
  usage: 'ticketsetup <category|logchannel|supportrole> <value>',
  category: 'ticket',
  userPermissions: ['Administrator'],
  cooldown: 5,
  async execute(client, message, args) {
    const option = args[0]?.toLowerCase();
    if (!option) return message.reply({ embeds: [Embed.error('Usage', 'ticketsetup <category|logchannel|supportrole> <value>')] });
    const cfg = DataManager.ensure('ticketconfig', message.guild.id, {});
    if (option === 'category') {
      const cat = message.guild.channels.cache.get(args[1]) || message.guild.channels.cache.find(c => c.name.toLowerCase() === args.slice(1).join(' ').toLowerCase() && c.type === 4);
      if (!cat) return message.reply({ embeds: [Embed.error('Invalid', 'Provide a valid category ID or name.')] });
      cfg.categoryId = cat.id;
    } else if (option === 'logchannel') {
      const ch = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
      if (!ch) return message.reply({ embeds: [Embed.error('Invalid', 'Mention a valid channel.')] });
      cfg.logChannelId = ch.id;
    } else if (option === 'supportrole') {
      const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);
      if (!role) return message.reply({ embeds: [Embed.error('Invalid', 'Mention a valid role.')] });
      cfg.supportRoleId = role.id;
    } else {
      return message.reply({ embeds: [Embed.error('Unknown Option', 'Valid: `category`, `logchannel`, `supportrole`.')] });
    }
    DataManager.set('ticketconfig', message.guild.id, cfg);
    message.reply({ embeds: [Embed.success('Config Updated', `Ticket **${option}** updated successfully.`)] });
  }
};
