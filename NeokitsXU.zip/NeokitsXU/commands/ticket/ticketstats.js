const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'ticketstats',
  description: 'View ticket statistics for this server',
  usage: 'ticketstats',
  category: 'ticket',
  userPermissions: ['ModerateMembers'],
  cooldown: 10,
  async execute(client, message) {
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const open = tickets.filter(t => t.status === 'open').length;
    const closed = tickets.filter(t => t.status === 'closed').length;
    const claimed = tickets.filter(t => t.claimedBy).length;
    message.reply({ embeds: [Embed.custom({
      title: `🎫 Ticket Stats — ${message.guild.name}`,
      fields: [
        { name: 'Total Tickets', value: `${tickets.length}`, inline: true },
        { name: 'Open', value: `${open}`, inline: true },
        { name: 'Closed', value: `${closed}`, inline: true },
        { name: 'Currently Claimed', value: `${claimed}`, inline: true },
      ]
    })] });
  }
};
