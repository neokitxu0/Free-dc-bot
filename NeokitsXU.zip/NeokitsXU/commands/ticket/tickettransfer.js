const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'tickettransfer',
  description: 'Transfer ticket ownership to another user',
  usage: 'tickettransfer <@user>',
  category: 'ticket',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const newOwner = message.mentions.members.first();
    if (!newOwner) return message.reply({ embeds: [Embed.error('Invalid', 'Mention a user to transfer the ticket to.')] });
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const idx = tickets.findIndex(t => t.channelId === message.channel.id && t.status === 'open');
    if (idx === -1) return message.reply({ embeds: [Embed.error('Not a Ticket', 'Use this in an open ticket channel.')] });
    const oldOwner = tickets[idx].userId;
    tickets[idx].userId = newOwner.id;
    DataManager.set('tickets', message.guild.id, tickets);
    await message.channel.permissionOverwrites.edit(newOwner, { ViewChannel: true, SendMessages: true }).catch(() => {});
    message.reply({ embeds: [Embed.success('Transferred', `Ticket transferred from <@${oldOwner}> to ${newOwner}.`)] });
  }
};
