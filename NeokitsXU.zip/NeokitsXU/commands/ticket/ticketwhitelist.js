const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'ticketwhitelist',
  description: 'Remove a user from ticket blacklist',
  usage: 'ticketwhitelist <@user>',
  category: 'ticket',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.members.first();
    if (!target) return message.reply({ embeds: [Embed.error('Invalid', 'Mention a user to whitelist.')] });
    const bl = DataManager.ensure('ticketblacklist', message.guild.id, []);
    const idx = bl.indexOf(target.id);
    if (idx === -1) return message.reply({ embeds: [Embed.warn('Not Blacklisted', `**${target.user.tag}** is not blacklisted from tickets.`)] });
    bl.splice(idx, 1);
    DataManager.set('ticketblacklist', message.guild.id, bl);
    message.reply({ embeds: [Embed.success('Whitelisted', `**${target.user.tag}** can now create tickets again.`)] });
  }
};
