const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'transcript',
  description: 'Save a transcript of the current ticket',
  usage: 'transcript',
  category: 'ticket',
  userPermissions: ['ModerateMembers'],
  cooldown: 10,
  async execute(client, message) {
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const ticket = tickets.find(t => t.channelId === message.channel.id);
    if (!ticket) return message.reply({ embeds: [Embed.error('Not a Ticket', 'Use this in a ticket channel.')] });
    const messages = await message.channel.messages.fetch({ limit: 100 });
    const lines = [...messages.values()].reverse().map(m => `[${new Date(m.createdTimestamp).toISOString()}] ${m.author.tag}: ${m.content || '[embed/attachment]'}`);
    const filename = `transcript-${ticket.id}-${Date.now()}.txt`;
    const filepath = path.join(__dirname, '../../logs', filename);
    fs.writeFileSync(filepath, lines.join('\n'));
    try {
      const user = await client.users.fetch(ticket.userId);
      await user.send({ content: `Transcript for Ticket #${ticket.id}`, files: [filepath] });
    } catch {}
    message.reply({ embeds: [Embed.success('Transcript Saved', `Transcript for ticket #${ticket.id} has been saved and sent to the ticket creator.`)] });
  }
};
