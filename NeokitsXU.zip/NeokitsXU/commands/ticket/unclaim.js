const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'unclaim',
  description: 'Unclaim the current ticket',
  usage: 'unclaim',
  category: 'ticket',
  userPermissions: ['ModerateMembers'],
  cooldown: 5,
  async execute(client, message) {
    const tickets = DataManager.get('tickets', message.guild.id, []);
    const idx = tickets.findIndex(t => t.channelId === message.channel.id && t.status === 'open');
    if (idx === -1) return message.reply({ embeds: [Embed.error('Not a Ticket', 'Use this in a ticket channel.')] });
    if (!tickets[idx].claimedBy) return message.reply({ embeds: [Embed.warn('Not Claimed', 'This ticket is not currently claimed.')] });
    tickets[idx].claimedBy = null;
    DataManager.set('tickets', message.guild.id, tickets);
    message.reply({ embeds: [Embed.success('Unclaimed', 'Ticket is now unclaimed.')] });
  }
};
