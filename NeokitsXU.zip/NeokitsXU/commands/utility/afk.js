const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'afk',
  description: 'Set your AFK status',
  usage: 'afk [reason]',
  category: 'utility',
  cooldown: 10,
  async execute(client, message, args) {
    const reason = args.join(' ') || 'AFK';
    const afkData = { reason, time: Date.now() };
    client.afk.set(message.author.id, afkData);
    DataManager.set('afk', message.author.id, afkData);
    message.reply({ embeds: [Embed.success('AFK Set', `You are now AFK: **${reason}**`)] });
  }
};
