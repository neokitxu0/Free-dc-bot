const Embed = require('../../utils/Embed');

module.exports = {
  name: 'base64',
  description: 'Encode text to Base64',
  usage: 'base64 <text>',
  category: 'utility',
  cooldown: 3,
  async execute(client, message, args) {
    const text = args.join(' ');
    if (!text) return message.reply({ embeds: [Embed.error('Missing Text', 'Provide text to encode.')] });
    const encoded = Buffer.from(text).toString('base64');
    message.reply({ embeds: [Embed.custom({ title: '🔐 Base64 Encoded', description: `**Input:** \`${text.slice(0, 200)}\`\n**Output:** \`\`\`${encoded.slice(0, 500)}\`\`\`` })] });
  }
};
