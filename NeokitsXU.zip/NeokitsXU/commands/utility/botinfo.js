const Embed = require('../../utils/Embed');
const os = require('os');

module.exports = {
  name: 'botinfo',
  aliases: ['about', 'bi'],
  description: 'Detailed information about the bot',
  usage: 'botinfo',
  category: 'utility',
  cooldown: 10,
  async execute(client, message) {
    const ms = Date.now() - client.startTime;
    const d = Math.floor(ms / 86400000), h = Math.floor((ms % 86400000) / 3600000), m = Math.floor((ms % 3600000) / 60000);
    const memUsed = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
    message.reply({ embeds: [Embed.custom({
      title: `${client.user.username}`,
      thumbnail: client.user.displayAvatarURL({ dynamic: true }),
      fields: [
        { name: 'Developer', value: `<@${client.config.ownerId}>`, inline: true },
        { name: 'Version', value: '1.0.0', inline: true },
        { name: 'Library', value: 'Discord.js v14', inline: true },
        { name: 'Node.js', value: process.version, inline: true },
        { name: 'Uptime', value: `${d}d ${h}h ${m}m`, inline: true },
        { name: 'Memory', value: `${memUsed} MB`, inline: true },
        { name: 'Servers', value: `${client.guilds.cache.size}`, inline: true },
        { name: 'Users', value: `${client.users.cache.size}`, inline: true },
        { name: 'Commands', value: `${client.commands.size}`, inline: true },
        { name: 'Platform', value: `${os.type()} ${os.arch()}`, inline: true },
      ]
    })] });
  }
};
