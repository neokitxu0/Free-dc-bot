const Embed = require('../../utils/Embed');

module.exports = {
  name: 'calculator',
  aliases: ['calc', 'math'],
  description: 'Evaluate a math expression',
  usage: 'calculator <expression>',
  category: 'utility',
  cooldown: 3,
  async execute(client, message, args) {
    const expr = args.join(' ');
    if (!expr) return message.reply({ embeds: [Embed.error('Missing Expression', 'Provide a math expression.')] });
    const sanitized = expr.replace(/[^0-9+\-*/.() %^]/g, '');
    if (!sanitized) return message.reply({ embeds: [Embed.error('Invalid', 'Expression contains invalid characters.')] });
    try {
      const result = Function(`"use strict"; return (${sanitized.replace(/\^/g, '**')})`)();
      if (typeof result !== 'number' || !isFinite(result)) throw new Error('Invalid result');
      message.reply({ embeds: [Embed.custom({ title: '🧮 Calculator', description: `**Expression:** \`${expr}\`\n**Result:** \`${result}\`` })] });
    } catch {
      message.reply({ embeds: [Embed.error('Error', 'Could not evaluate the expression.')] });
    }
  }
};
