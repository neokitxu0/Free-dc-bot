const Embed = require('../../utils/Embed');

module.exports = {
  name: 'choose',
  aliases: ['pick', 'random'],
  description: 'Choose randomly between options',
  usage: 'choose <option1> | <option2> | ...',
  category: 'utility',
  cooldown: 3,
  async execute(client, message, args) {
    const options = args.join(' ').split('|').map(o => o.trim()).filter(Boolean);
    if (options.length < 2) return message.reply({ embeds: [Embed.error('Not Enough Options', 'Provide at least 2 options separated by `|`.')] });
    const choice = options[Math.floor(Math.random() * options.length)];
    message.reply({ embeds: [Embed.custom({ title: '🎯 I Choose...', description: `**${choice}**\n\nOptions: ${options.map(o => `\`${o}\``).join(', ')}` })] });
  }
};
