const Embed = require('../../utils/Embed');

module.exports = {
  name: 'coinflip',
  aliases: ['cf', 'flip'],
  description: 'Flip a coin',
  usage: 'coinflip [heads|tails]',
  category: 'utility',
  cooldown: 3,
  async execute(client, message, args) {
    const result = Math.random() < 0.5 ? 'Heads' : 'Tails';
    const emoji = result === 'Heads' ? '🪙' : '🪙';
    const guess = args[0]?.toLowerCase();
    let extra = '';
    if (guess === 'heads' || guess === 'tails') {
      const guessWord = guess.charAt(0).toUpperCase() + guess.slice(1);
      extra = guessWord === result ? '\n\n✅ **You guessed correctly!**' : '\n\n❌ **You guessed wrong!**';
    }
    message.reply({ embeds: [Embed.custom({ title: `${emoji} Coin Flip`, description: `Result: **${result}**${extra}` })] });
  }
};
