const Embed = require('../../utils/Embed');

module.exports = {
  name: 'color',
  aliases: ['colour'],
  description: 'Get information about a color',
  usage: 'color <hex|rgb>',
  category: 'utility',
  cooldown: 5,
  async execute(client, message, args) {
    let hex;
    const input = args.join(' ').trim();
    if (/^#?[0-9A-F]{6}$/i.test(input)) {
      hex = input.startsWith('#') ? input : `#${input}`;
    } else if (/^\d{1,3},\s*\d{1,3},\s*\d{1,3}$/.test(input)) {
      const [r, g, b] = input.split(',').map(n => parseInt(n.trim()));
      hex = `#${r.toString(16).padStart(2,'0')}${g.toString(16).padStart(2,'0')}${b.toString(16).padStart(2,'0')}`;
    } else {
      return message.reply({ embeds: [Embed.error('Invalid Color', 'Provide a hex (#FF5733) or RGB (255,87,51).')] });
    }
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    message.reply({ embeds: [Embed.custom({
      title: `Color: ${hex.toUpperCase()}`,
      description: `**HEX:** \`${hex.toUpperCase()}\`\n**RGB:** \`rgb(${r}, ${g}, ${b})\``,
      color: hex,
      thumbnail: `https://singlecolorimage.com/get/${hex.slice(1)}/128x128`
    })] });
  }
};
