const Embed = require('../../utils/Embed');

module.exports = {
  name: 'countdown',
  description: 'Show a countdown to a specific date',
  usage: 'countdown <date>',
  category: 'utility',
  cooldown: 5,
  async execute(client, message, args) {
    const dateStr = args.join(' ');
    if (!dateStr) return message.reply({ embeds: [Embed.error('Missing Date', 'Provide a future date. Example: `countdown 2025-12-25`')] });
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return message.reply({ embeds: [Embed.error('Invalid Date', 'Could not parse that date.')] });
    if (date <= Date.now()) return message.reply({ embeds: [Embed.error('Past Date', 'That date is in the past!')] });
    const diff = date - Date.now();
    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    message.reply({ embeds: [Embed.custom({
      title: `⏳ Countdown to ${date.toDateString()}`,
      description: `**${d}** days, **${h}** hours, **${m}** minutes, **${s}** seconds\n\nTimestamp: <t:${Math.floor(date.getTime() / 1000)}:R>`
    })] });
  }
};
