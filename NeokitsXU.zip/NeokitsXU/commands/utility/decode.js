const Embed = require('../../utils/Embed');

module.exports = {
  name: 'decode',
  description: 'Decode Base64 text',
  usage: 'decode <base64>',
  category: 'utility',
  cooldown: 3,
  async execute(client, message, args) {
    const text = args.join(' ');
    if (!text) return message.reply({ embeds: [Embed.error('Missing Text', 'Provide Base64 text to decode.')] });
    try {
      const decoded = Buffer.from(text, 'base64').toString('utf8');
      message.reply({ embeds: [Embed.custom({ title: '🔓 Base64 Decoded', description: `**Input:** \`${text.slice(0, 200)}\`\n**Output:** \`\`\`${decoded.slice(0, 500)}\`\`\`` })] });
    } catch {
      message.reply({ embeds: [Embed.error('Invalid', 'Could not decode the provided text.')] });
    }
  }
};
