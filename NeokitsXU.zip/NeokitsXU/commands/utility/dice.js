const Embed = require('../../utils/Embed');

module.exports = {
  name: 'dice',
  aliases: ['roll'],
  description: 'Roll dice',
  usage: 'dice [NdN] (e.g. 2d6, d20)',
  category: 'utility',
  cooldown: 3,
  async execute(client, message, args) {
    const input = args[0] || '1d6';
    const match = input.match(/^(\d+)?d(\d+)$/i);
    if (!match) return message.reply({ embeds: [Embed.error('Invalid Format', 'Use format like `d6`, `2d20`, `3d10`.')] });
    const count = Math.min(parseInt(match[1]) || 1, 10);
    const sides = Math.min(parseInt(match[2]) || 6, 1000);
    if (sides < 2) return message.reply({ embeds: [Embed.error('Invalid Die', 'Die must have at least 2 sides.')] });
    const rolls = Array.from({ length: count }, () => Math.floor(Math.random() * sides) + 1);
    const total = rolls.reduce((a, b) => a + b, 0);
    message.reply({ embeds: [Embed.custom({
      title: `🎲 Dice Roll — ${input}`,
      description: `Rolls: **${rolls.join(', ')}**\n\nTotal: **${total}**`
    })] });
  }
};
