const Embed = require('../../utils/Embed');

module.exports = {
  name: 'encode',
  description: 'URL-encode text',
  usage: 'encode <text>',
  category: 'utility',
  cooldown: 3,
  async execute(client, message, args) {
    const text = args.join(' ');
    if (!text) return message.reply({ embeds: [Embed.error('Missing Text', 'Provide text to URL-encode.')] });
    const encoded = encodeURIComponent(text);
    message.reply({ embeds: [Embed.custom({ title: '🔗 URL Encoded', description: `**Input:** \`${text.slice(0, 200)}\`\n**Output:** \`\`\`${encoded.slice(0, 500)}\`\`\`` })] });
  }
};
