const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'feedback',
  description: 'Submit feedback about the bot',
  usage: 'feedback <message>',
  category: 'utility',
  cooldown: 60,
  async execute(client, message, args) {
    const text = args.join(' ');
    if (!text || text.length < 5) return message.reply({ embeds: [Embed.error('Too Short', 'Feedback must be at least 5 characters.')] });
    const feedbacks = DataManager.ensure('feedback', 'global', []);
    feedbacks.push({ author: message.author.id, guild: message.guild.id, text, time: Date.now() });
    DataManager.set('feedback', 'global', feedbacks);
    const owner = await client.users.fetch(client.config.ownerId).catch(() => null);
    if (owner) owner.send({ embeds: [Embed.custom({ title: '📝 New Feedback', description: text, footer: { text: `From ${message.author.tag} in ${message.guild.name}` } })] }).catch(() => {});
    message.reply({ embeds: [Embed.success('Feedback Sent', 'Thank you for your feedback!')] });
  }
};
