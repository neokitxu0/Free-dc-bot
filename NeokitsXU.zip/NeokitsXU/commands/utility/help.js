const Embed = require('../../utils/Embed');

module.exports = {
  name: 'help',
  aliases: ['h', 'commands'],
  description: 'Show all commands or get help on a specific command',
  usage: 'help [command|category]',
  category: 'utility',
  cooldown: 5,
  async execute(client, message, args) {
    const prefix = client.config.prefix;
    if (!args[0]) {
      const categories = [...new Set(client.commands.map(c => c.category))].filter(Boolean);
      const fields = categories.map(cat => {
        const cmds = client.commands.filter(c => c.category === cat);
        return { name: `${cat.charAt(0).toUpperCase() + cat.slice(1)} [${cmds.size}]`, value: cmds.map(c => `\`${c.name}\``).join(', '), inline: false };
      });
      return message.reply({ embeds: [Embed.custom({
        title: `${client.user.username} — Help`,
        description: `Prefix: \`${prefix}\`\nTotal commands: **${client.commands.size}**\n\nUse \`${prefix}help <command>\` for details.`,
        fields,
        thumbnail: client.user.displayAvatarURL({ dynamic: true })
      })] });
    }
    const cmd = client.commands.get(args[0].toLowerCase()) || client.commands.get(client.aliases.get(args[0].toLowerCase()));
    if (!cmd) return message.reply({ embeds: [Embed.error('Not Found', `Command \`${args[0]}\` not found.`)] });
    message.reply({ embeds: [Embed.custom({
      title: `${prefix}${cmd.name}`,
      fields: [
        { name: 'Description', value: cmd.description || 'None', inline: false },
        { name: 'Usage', value: `\`${prefix}${cmd.usage || cmd.name}\``, inline: true },
        { name: 'Category', value: cmd.category || 'None', inline: true },
        { name: 'Cooldown', value: `${cmd.cooldown || 3}s`, inline: true },
        { name: 'Aliases', value: cmd.aliases?.map(a => `\`${a}\``).join(', ') || 'None', inline: true },
        { name: 'Permissions', value: cmd.userPermissions?.join(', ') || 'None', inline: false },
      ]
    })] });
  }
};
