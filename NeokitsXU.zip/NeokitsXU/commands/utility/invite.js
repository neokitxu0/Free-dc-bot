const Embed = require('../../utils/Embed');

module.exports = {
  name: 'invite',
  description: 'Get the bot invite link',
  usage: 'invite',
  category: 'utility',
  cooldown: 5,
  async execute(client, message) {
    const inviteLink = `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`;
    message.reply({ embeds: [Embed.custom({
      title: `Invite ${client.user.username}`,
      description: `[Click here to invite the bot](${inviteLink})\n\nUse \`${client.config.prefix}support\` for the support server.`,
      thumbnail: client.user.displayAvatarURL({ dynamic: true })
    })] });
  }
};
