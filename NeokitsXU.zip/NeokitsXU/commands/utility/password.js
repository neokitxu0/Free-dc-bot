const Embed = require('../../utils/Embed');

module.exports = {
  name: 'password',
  aliases: ['genpass', 'pwgen'],
  description: 'Generate a secure random password',
  usage: 'password [length]',
  category: 'utility',
  cooldown: 5,
  async execute(client, message, args) {
    const len = Math.min(Math.max(parseInt(args[0]) || 16, 8), 64);
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;:,.<>?';
    let pw = '';
    for (let i = 0; i < len; i++) pw += chars[Math.floor(Math.random() * chars.length)];
    try {
      await message.author.send({ embeds: [Embed.success('Password Generated', `\`\`\`${pw}\`\`\`\nLength: **${len}** — Keep this safe!`)] });
      message.reply({ embeds: [Embed.success('Sent!', 'Your password has been sent via DM.')] });
    } catch {
      message.reply({ embeds: [Embed.warn('DM Failed', `Here is your password (delete this message!):\n\`\`\`${pw}\`\`\``)] });
    }
  }
};
