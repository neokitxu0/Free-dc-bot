const Embed = require('../../utils/Embed');

module.exports = {
  name: 'ping',
  description: 'Check bot latency and API ping',
  usage: 'ping',
  category: 'utility',
  cooldown: 5,
  async execute(client, message) {
    const sent = await message.reply({ embeds: [Embed.info('🏓 Pinging...', 'Calculating latency...')] });
    const latency = sent.createdTimestamp - message.createdTimestamp;
    const apiLatency = Math.round(client.ws.ping);
    sent.edit({ embeds: [Embed.custom({
      title: '🏓 Pong!',
      fields: [
        { name: 'Bot Latency', value: `\`${latency}ms\``, inline: true },
        { name: 'API Latency', value: `\`${apiLatency}ms\``, inline: true },
        { name: 'Status', value: apiLatency < 100 ? '🟢 Excellent' : apiLatency < 200 ? '🟡 Good' : '🔴 Poor', inline: true }
      ]
    })] });
  }
};
