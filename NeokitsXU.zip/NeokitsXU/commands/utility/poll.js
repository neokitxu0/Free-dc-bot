const Embed = require('../../utils/Embed');

module.exports = {
  name: 'poll',
  description: 'Create a poll with up to 10 options',
  usage: 'poll <question> | <option1> | <option2> ...',
  category: 'utility',
  cooldown: 10,
  async execute(client, message, args) {
    const input = args.join(' ').split('|').map(s => s.trim());
    const question = input[0];
    const options = input.slice(1);
    if (!question) return message.reply({ embeds: [Embed.error('Usage', 'poll <question> | <opt1> | <opt2> ...')] });
    const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
    if (!options.length) {
      const m = await message.channel.send({ embeds: [Embed.custom({ title: '📊 Poll', description: `**${question}**` })] });
      await m.react('👍');
      await m.react('👎');
      return message.delete().catch(() => {});
    }
    if (options.length < 2 || options.length > 10) return message.reply({ embeds: [Embed.error('Invalid Options', 'Provide between 2 and 10 options.')] });
    const desc = options.map((o, i) => `${emojis[i]} ${o}`).join('\n');
    const m = await message.channel.send({ embeds: [Embed.custom({ title: `📊 ${question}`, description: desc, footer: { text: `Poll by ${message.author.tag}` } })] });
    for (let i = 0; i < options.length; i++) await m.react(emojis[i]);
    message.delete().catch(() => {});
  }
};
