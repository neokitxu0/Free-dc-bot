const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');
const ms = require('ms');
const { v4: uuidv4 } = require('uuid');

module.exports = {
  name: 'remind',
  aliases: ['reminder', 'remindme'],
  description: 'Set a reminder',
  usage: 'remind <time> <message>',
  category: 'utility',
  cooldown: 5,
  async execute(client, message, args) {
    const timeArg = args[0];
    if (!timeArg) return message.reply({ embeds: [Embed.error('Usage', 'remind <time> <message>\nExample: remind 10m Do homework')] });
    const duration = ms(timeArg);
    if (!duration || duration > 2592000000) return message.reply({ embeds: [Embed.error('Invalid Time', 'Use valid time like `10m`, `1h`, `2d`. Max 30 days.')] });
    const reminderText = args.slice(1).join(' ') || 'No message';
    const id = uuidv4().slice(0, 8);
    const remindAt = Date.now() + duration;
    DataManager.set('reminders', id, {
      userId: message.author.id,
      channelId: message.channel.id,
      message: reminderText,
      time: remindAt
    });
    message.reply({ embeds: [Embed.success('Reminder Set', `I'll remind you in **${timeArg}**.\n\nMessage: ${reminderText}\nID: \`${id}\``)] });
  }
};
