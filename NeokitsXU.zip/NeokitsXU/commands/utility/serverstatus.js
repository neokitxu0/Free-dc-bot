const Embed = require('../../utils/Embed');

module.exports = {
  name: 'serverstatus',
  aliases: ['discordstatus'],
  description: 'Check Discord API status',
  usage: 'serverstatus',
  category: 'utility',
  cooldown: 30,
  async execute(client, message) {
    const fields = [
      { name: 'Bot Latency', value: `${client.ws.ping}ms`, inline: true },
      { name: 'Shard', value: `${(message.guild.shardId || 0) + 1}/${client.shard?.count || 1}`, inline: true },
      { name: 'Cache', value: `${client.guilds.cache.size} guilds | ${client.users.cache.size} users | ${client.channels.cache.size} channels`, inline: false },
      { name: 'Status Page', value: '[status.discordapp.com](https://status.discordapp.com)', inline: false }
    ];
    message.reply({ embeds: [Embed.custom({ title: '🌐 Discord Status', fields })] });
  }
};
