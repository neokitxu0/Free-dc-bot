const Embed = require('../../utils/Embed');
const os = require('os');

module.exports = {
  name: 'stats',
  description: 'Show detailed bot statistics',
  usage: 'stats',
  category: 'utility',
  cooldown: 10,
  async execute(client, message) {
    const mem = process.memoryUsage();
    const totalUsers = client.guilds.cache.reduce((a, g) => a + g.memberCount, 0);
    const topCmds = [...client.commandStats.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
    message.reply({ embeds: [Embed.custom({
      title: '📊 Bot Statistics',
      fields: [
        { name: 'Servers', value: `${client.guilds.cache.size}`, inline: true },
        { name: 'Total Users', value: `${totalUsers}`, inline: true },
        { name: 'Channels', value: `${client.channels.cache.size}`, inline: true },
        { name: 'Commands', value: `${client.commands.size}`, inline: true },
        { name: 'Heap Used', value: `${(mem.heapUsed / 1024 / 1024).toFixed(2)} MB`, inline: true },
        { name: 'RSS', value: `${(mem.rss / 1024 / 1024).toFixed(2)} MB`, inline: true },
        { name: 'CPU Model', value: os.cpus()[0]?.model || 'Unknown', inline: false },
        { name: 'OS', value: `${os.type()} ${os.release()}`, inline: true },
        { name: 'Top Commands', value: topCmds.length ? topCmds.map(([n, c]) => `\`${n}\`: ${c}`).join('\n') : 'No data', inline: false }
      ]
    })] });
  }
};
