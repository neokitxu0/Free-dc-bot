const Embed = require('../../utils/Embed');

module.exports = {
  name: 'stopwatch',
  aliases: ['sw'],
  description: 'Stopwatch — start and stop to get elapsed time',
  usage: 'stopwatch <start|stop>',
  category: 'utility',
  cooldown: 3,
  async execute(client, message, args) {
    const action = args[0]?.toLowerCase();
    if (!client.stopwatches) client.stopwatches = new Map();
    if (action === 'start') {
      client.stopwatches.set(message.author.id, Date.now());
      return message.reply({ embeds: [Embed.success('⏱️ Started', 'Stopwatch started! Use `stopwatch stop` to stop it.')] });
    }
    if (action === 'stop') {
      const start = client.stopwatches.get(message.author.id);
      if (!start) return message.reply({ embeds: [Embed.error('Not Running', 'Start a stopwatch first with `stopwatch start`.')] });
      const elapsed = Date.now() - start;
      client.stopwatches.delete(message.author.id);
      const s = (elapsed / 1000).toFixed(3);
      return message.reply({ embeds: [Embed.success('⏱️ Stopped', `Elapsed: **${s}s** (${elapsed}ms)`)] });
    }
    message.reply({ embeds: [Embed.error('Usage', 'stopwatch <start|stop>')] });
  }
};
