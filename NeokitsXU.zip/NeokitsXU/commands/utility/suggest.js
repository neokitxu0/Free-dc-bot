const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'suggest',
  description: 'Submit a suggestion',
  usage: 'suggest <suggestion>',
  category: 'utility',
  cooldown: 30,
  async execute(client, message, args) {
    const text = args.join(' ');
    if (!text || text.length < 10) return message.reply({ embeds: [Embed.error('Too Short', 'Please provide a more detailed suggestion (min 10 chars).')] });
    const suggestions = DataManager.ensure('suggestions', message.guild.id, []);
    const id = suggestions.length + 1;
    const embed = Embed.custom({
      title: `Suggestion #${id}`,
      description: text,
      author: { name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true }) },
      footer: { text: `ID: ${id} | Author: ${message.author.id}` },
      color: '#FEE75C'
    });
    suggestions.push({ id, text, author: message.author.id, time: Date.now(), status: 'pending' });
    DataManager.set('suggestions', message.guild.id, suggestions);
    await message.delete().catch(() => {});
    const m = await message.channel.send({ embeds: [embed] });
    await m.react('👍');
    await m.react('👎');
    message.channel.send({ embeds: [Embed.success('Submitted', `Your suggestion #${id} has been submitted!`)] }).then(r => setTimeout(() => r.delete().catch(() => {}), 5000));
  }
};
