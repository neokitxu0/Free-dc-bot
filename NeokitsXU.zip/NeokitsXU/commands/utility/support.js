const Embed = require('../../utils/Embed');

module.exports = {
  name: 'support',
  description: 'Get the support server link',
  usage: 'support',
  category: 'utility',
  cooldown: 5,
  async execute(client, message) {
    message.reply({ embeds: [Embed.custom({
      title: 'Support Server',
      description: `[Join our support server](${client.config.supportServer || 'https://discord.gg/neokitsxu'})\n\nNeed help? Join the server and open a ticket!`,
      thumbnail: client.user.displayAvatarURL({ dynamic: true })
    })] });
  }
};
