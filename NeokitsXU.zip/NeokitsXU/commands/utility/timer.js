const Embed = require('../../utils/Embed');
const ms = require('ms');

module.exports = {
  name: 'timer',
  description: 'Start a countdown timer',
  usage: 'timer <time>',
  category: 'utility',
  cooldown: 10,
  async execute(client, message, args) {
    const duration = ms(args[0]);
    if (!duration || duration > 3600000) return message.reply({ embeds: [Embed.error('Invalid Time', 'Use valid time up to 1 hour (e.g. `5m`, `30s`).')] });
    const endsAt = Date.now() + duration;
    const m = await message.reply({ embeds: [Embed.info(`⏲️ Timer Started`, `Ends <t:${Math.floor(endsAt / 1000)}:R>`)] });
    setTimeout(async () => {
      m.edit({ embeds: [Embed.success('⏲️ Timer Done!', `Your ${args[0]} timer has ended, ${message.author}!`)] });
    }, duration);
  }
};
