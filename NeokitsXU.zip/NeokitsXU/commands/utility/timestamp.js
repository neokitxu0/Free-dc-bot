const Embed = require('../../utils/Embed');

module.exports = {
  name: 'timestamp',
  aliases: ['ts', 'time'],
  description: 'Generate Discord timestamps',
  usage: 'timestamp [date/time string]',
  category: 'utility',
  cooldown: 3,
  async execute(client, message, args) {
    let date;
    if (args.length) {
      date = new Date(args.join(' '));
      if (isNaN(date.getTime())) return message.reply({ embeds: [Embed.error('Invalid Date', 'Provide a valid date string.')] });
    } else {
      date = new Date();
    }
    const unix = Math.floor(date.getTime() / 1000);
    const formats = [
      { name: 'Short Date', format: `\`<t:${unix}:d>\``, value: `<t:${unix}:d>` },
      { name: 'Long Date', format: `\`<t:${unix}:D>\``, value: `<t:${unix}:D>` },
      { name: 'Short Time', format: `\`<t:${unix}:t>\``, value: `<t:${unix}:t>` },
      { name: 'Long Time', format: `\`<t:${unix}:T>\``, value: `<t:${unix}:T>` },
      { name: 'Short Date/Time', format: `\`<t:${unix}:f>\``, value: `<t:${unix}:f>` },
      { name: 'Long Date/Time', format: `\`<t:${unix}:F>\``, value: `<t:${unix}:F>` },
      { name: 'Relative', format: `\`<t:${unix}:R>\``, value: `<t:${unix}:R>` },
    ];
    const fields = formats.map(f => ({ name: f.name, value: `${f.format} → ${f.value}`, inline: false }));
    message.reply({ embeds: [Embed.custom({ title: `🕐 Timestamps for ${date.toISOString()}`, description: `**Unix:** \`${unix}\``, fields })] });
  }
};
