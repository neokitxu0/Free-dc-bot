const Embed = require('../../utils/Embed');

module.exports = {
  name: 'timezone',
  aliases: ['tz'],
  description: 'Show current time in a timezone',
  usage: 'timezone <zone> (e.g. America/New_York)',
  category: 'utility',
  cooldown: 5,
  async execute(client, message, args) {
    const zone = args.join(' ') || 'UTC';
    try {
      const time = new Date().toLocaleString('en-US', { timeZone: zone, timeStyle: 'long', dateStyle: 'full' });
      message.reply({ embeds: [Embed.info(`🕐 ${zone}`, time)] });
    } catch {
      message.reply({ embeds: [Embed.error('Invalid Timezone', 'Use a valid IANA timezone like `America/New_York`, `Europe/London`, `Asia/Tokyo`.')] });
    }
  }
};
