const Embed = require('../../utils/Embed');
const DataManager = require('../../utils/DataManager');

module.exports = {
  name: 'todo',
  description: 'Manage your personal to-do list',
  usage: 'todo <add|remove|list|clear> [item]',
  category: 'utility',
  cooldown: 5,
  async execute(client, message, args) {
    const action = args[0]?.toLowerCase();
    const todos = DataManager.ensure('todo', message.author.id, []);
    if (action === 'add') {
      const item = args.slice(1).join(' ');
      if (!item) return message.reply({ embeds: [Embed.error('Missing Item', 'Provide an item to add.')] });
      todos.push({ item, done: false, time: Date.now() });
      DataManager.set('todo', message.author.id, todos);
      return message.reply({ embeds: [Embed.success('Added', `Added: **${item}**`)] });
    }
    if (action === 'remove') {
      const idx = parseInt(args[1]) - 1;
      if (isNaN(idx) || idx < 0 || idx >= todos.length) return message.reply({ embeds: [Embed.error('Invalid', 'Provide a valid task number.')] });
      const removed = todos.splice(idx, 1)[0];
      DataManager.set('todo', message.author.id, todos);
      return message.reply({ embeds: [Embed.success('Removed', `Removed: **${removed.item}**`)] });
    }
    if (action === 'clear') {
      DataManager.set('todo', message.author.id, []);
      return message.reply({ embeds: [Embed.success('Cleared', 'Your to-do list has been cleared.')] });
    }
    if (!todos.length) return message.reply({ embeds: [Embed.info('Empty', 'Your to-do list is empty. Add items with `todo add <item>`.')] });
    const desc = todos.map((t, i) => `${i + 1}. ${t.done ? '~~' : ''}${t.item}${t.done ? '~~' : ''}`).join('\n');
    message.reply({ embeds: [Embed.custom({ title: `📝 Your To-Do List (${todos.length})`, description: desc })] });
  }
};
