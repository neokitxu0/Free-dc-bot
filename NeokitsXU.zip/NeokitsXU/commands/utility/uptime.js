const Embed = require('../../utils/Embed');

module.exports = {
  name: 'uptime',
  description: 'Show how long the bot has been running',
  usage: 'uptime',
  category: 'utility',
  cooldown: 5,
  async execute(client, message) {
    const ms = Date.now() - client.startTime;
    const d = Math.floor(ms / 86400000);
    const h = Math.floor((ms % 86400000) / 3600000);
    const m = Math.floor((ms % 3600000) / 60000);
    const s = Math.floor((ms % 60000) / 1000);
    message.reply({ embeds: [Embed.info('⏱️ Uptime', `**${d}d ${h}h ${m}m ${s}s**\nOnline since: <t:${Math.floor(client.startTime / 1000)}:R>`)] });
  }
};
