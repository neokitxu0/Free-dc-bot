const Embed = require('../../utils/Embed');

module.exports = {
  name: 'vote',
  description: 'Create a quick yes/no vote',
  usage: 'vote <question>',
  category: 'utility',
  cooldown: 10,
  async execute(client, message, args) {
    const question = args.join(' ');
    if (!question) return message.reply({ embeds: [Embed.error('Missing Question', 'Provide a question for the vote.')] });
    await message.delete().catch(() => {});
    const m = await message.channel.send({ embeds: [Embed.custom({
      title: '🗳️ Vote',
      description: `**${question}**`,
      footer: { text: `Started by ${message.author.tag}` }
    })] });
    await m.react('✅');
    await m.react('❌');
  }
};
