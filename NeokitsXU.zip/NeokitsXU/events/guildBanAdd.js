const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'guildBanAdd',
  async execute(client, ban) {
    const cfg = client.config;
    if (!cfg.logChannelId) return;
    const logChannel = ban.guild.channels.cache.get(cfg.logChannelId);
    if (!logChannel) return;
    const embed = new EmbedBuilder()
      .setColor('#ED4245')
      .setTitle('Member Banned')
      .addFields(
        { name: 'User', value: `${ban.user.tag} (${ban.user.id})`, inline: true },
        { name: 'Reason', value: ban.reason || 'No reason provided' }
      )
      .setThumbnail(ban.user.displayAvatarURL({ dynamic: true }))
      .setTimestamp();
    logChannel.send({ embeds: [embed] }).catch(() => {});
  }
};
