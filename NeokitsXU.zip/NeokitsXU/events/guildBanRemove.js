const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'guildBanRemove',
  async execute(client, ban) {
    const cfg = client.config;
    if (!cfg.logChannelId) return;
    const logChannel = ban.guild.channels.cache.get(cfg.logChannelId);
    if (!logChannel) return;
    const embed = new EmbedBuilder()
      .setColor('#57F287')
      .setTitle('Member Unbanned')
      .addFields({ name: 'User', value: `${ban.user.tag} (${ban.user.id})`, inline: true })
      .setThumbnail(ban.user.displayAvatarURL({ dynamic: true }))
      .setTimestamp();
    logChannel.send({ embeds: [embed] }).catch(() => {});
  }
};
