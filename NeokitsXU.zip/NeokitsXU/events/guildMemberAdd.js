const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'guildMemberAdd',
  async execute(client, member) {
    const cfg = client.config;

    // Auto roles
    if (cfg.autoRoles && cfg.autoRoles.length > 0) {
      for (const roleId of cfg.autoRoles) {
        const role = member.guild.roles.cache.get(roleId);
        if (role) member.roles.add(role).catch(() => {});
      }
    }

    // Welcome message
    if (cfg.welcomeChannel) {
      const channel = member.guild.channels.cache.get(cfg.welcomeChannel);
      if (channel) {
        const msg = (cfg.welcomeMessage || 'Welcome {user} to {server}!')
          .replace('{user}', member.toString())
          .replace('{server}', member.guild.name)
          .replace('{username}', member.user.username)
          .replace('{membercount}', member.guild.memberCount);
        const embed = new EmbedBuilder()
          .setColor(cfg.embedColor || '#5865F2')
          .setTitle('Welcome!')
          .setDescription(msg)
          .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
          .setFooter({ text: `Member #${member.guild.memberCount}` })
          .setTimestamp();
        channel.send({ embeds: [embed] }).catch(() => {});
      }
    }

    // Anti-raid check
    if (cfg.antiRaid?.enabled) {
      const key = `raid-${member.guild.id}`;
      const now = Date.now();
      const joins = client.cooldowns.get(key) || [];
      joins.push(now);
      const recent = joins.filter(t => now - t < (cfg.antiRaid.joinInterval || 10000));
      client.cooldowns.set(key, recent);
      if (recent.length >= (cfg.antiRaid.joinThreshold || 10)) {
        member.kick('Anti-Raid: Too many joins').catch(() => {});
        client.logger.warn(`Anti-Raid triggered in ${member.guild.name}`);
      }
    }
  }
};
