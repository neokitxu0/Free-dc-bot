const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'guildMemberRemove',
  async execute(client, member) {
    const cfg = client.config;
    if (cfg.goodbyeChannel) {
      const channel = member.guild.channels.cache.get(cfg.goodbyeChannel);
      if (channel) {
        const msg = (cfg.goodbyeMessage || '{user} has left {server}.')
          .replace('{user}', member.user.username)
          .replace('{server}', member.guild.name)
          .replace('{membercount}', member.guild.memberCount);
        const embed = new EmbedBuilder()
          .setColor('#ED4245')
          .setTitle('Member Left')
          .setDescription(msg)
          .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
          .setFooter({ text: `Members: ${member.guild.memberCount}` })
          .setTimestamp();
        channel.send({ embeds: [embed] }).catch(() => {});
      }
    }
  }
};
