const { Collection } = require('discord.js');
const Embed = require('../utils/Embed');
const { isOwner, isBlacklisted } = require('../utils/Permissions');
const LevelManager = require('../utils/LevelManager');

const xpCooldowns = new Collection();

module.exports = {
  name: 'messageCreate',
  async execute(client, message) {
    if (message.author.bot || !message.guild) return;

    const cfg = client.config;

    if (isBlacklisted(client, message.author.id)) return;

    if (cfg.maintenance && !isOwner(client, message.author.id)) return;

    // Anti-spam check
    if (cfg.antiSpam?.enabled) {
      const key = `${message.guild.id}-${message.author.id}`;
      const now = Date.now();
      const timestamps = client.cooldowns.get(`spam-${key}`) || new Collection();
      const interval = cfg.antiSpam.interval || 5000;
      const max = cfg.antiSpam.maxMessages || 5;
      timestamps.sweep(t => now - t > interval);
      if (timestamps.size >= max) {
        message.delete().catch(() => {});
        const m = await message.channel.send({ embeds: [Embed.warn('Anti-Spam', `${message.author}, you are sending messages too fast!`)] });
        setTimeout(() => m.delete().catch(() => {}), 5000);
        return;
      }
      timestamps.set(message.id, now);
      client.cooldowns.set(`spam-${key}`, timestamps);
    }

    // Anti-invite check
    if (cfg.antiInvite?.enabled && !message.member?.permissions.has(8n)) {
      const inviteRegex = /(discord\.gg|discord\.com\/invite)\/\w+/i;
      if (inviteRegex.test(message.content)) {
        const whitelist = cfg.antiInvite?.whitelist || [];
        if (!whitelist.includes(message.author.id) && !whitelist.includes(message.guild.id)) {
          message.delete().catch(() => {});
          const m = await message.channel.send({ embeds: [Embed.warn('Anti-Invite', `${message.author}, Discord invites are not allowed here!`)] });
          setTimeout(() => m.delete().catch(() => {}), 5000);
          return;
        }
      }
    }

    // Anti-link check
    if (cfg.antiLink?.enabled && !message.member?.permissions.has(8n)) {
      const linkRegex = /https?:\/\/\S+/i;
      if (linkRegex.test(message.content)) {
        const whitelist = cfg.antiLink?.whitelist || [];
        if (!whitelist.includes(message.author.id) && !whitelist.includes(message.guild.id)) {
          message.delete().catch(() => {});
          const m = await message.channel.send({ embeds: [Embed.warn('Anti-Link', `${message.author}, links are not allowed here!`)] });
          setTimeout(() => m.delete().catch(() => {}), 5000);
          return;
        }
      }
    }

    // XP system
    const xpKey = `${message.guild.id}-${message.author.id}`;
    const xpNow = Date.now();
    const lastXp = xpCooldowns.get(xpKey) || 0;
    const xpCooldown = (cfg.leveling?.xpCooldown || 60) * 1000;
    if (xpNow - lastXp >= xpCooldown) {
      xpCooldowns.set(xpKey, xpNow);
      const [min, max] = cfg.leveling?.xpPerMessage || [15, 25];
      const xpGain = Math.floor(Math.random() * (max - min + 1)) + min;
      const multiplier = cfg.leveling?.multiplier || 1.0;
      const result = LevelManager.addXp(message.guild.id, message.author.id, Math.floor(xpGain * multiplier));
      if (result.leveledUp) {
        const levelMsg = (cfg.leveling?.levelUpMessage || 'Congratulations {user}, you reached level {level}!')
          .replace('{user}', message.author.toString())
          .replace('{level}', result.newLevel);
        message.channel.send({ embeds: [Embed.success('Level Up!', levelMsg)] }).catch(() => {});
      }
    }

    // AFK check
    if (client.afk && client.afk.has(message.author.id)) {
      client.afk.delete(message.author.id);
      const DataManager = require('../utils/DataManager');
      DataManager.del('afk', message.author.id);
      message.reply({ embeds: [Embed.info('AFK Removed', 'Welcome back! Your AFK status has been removed.')] }).catch(() => {});
    }

    if (message.mentions.users.size > 0) {
      for (const [uid, user] of message.mentions.users) {
        if (client.afk && client.afk.has(uid)) {
          const afkData = client.afk.get(uid);
          message.channel.send({ embeds: [Embed.info('User AFK', `**${user.username}** is AFK: ${afkData.reason}`)] }).catch(() => {});
        }
      }
    }

    // Auto-responses
    const autoResponses = cfg.autoResponses || {};
    for (const [trigger, response] of Object.entries(autoResponses)) {
      if (message.content.toLowerCase().includes(trigger.toLowerCase())) {
        message.channel.send(response).catch(() => {});
        break;
      }
    }

    // Command processing
    const prefix = cfg.prefix || '!';
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/\s+/);
    const commandName = args.shift().toLowerCase();

    const command = client.commands.get(commandName) || client.commands.get(client.aliases.get(commandName));
    if (!command) return;

    // Owner-only check
    if (command.ownerOnly && !isOwner(client, message.author.id)) {
      return message.reply({ embeds: [Embed.error('Access Denied', 'This command is only for the bot owner.')] });
    }

    // Permission check
    if (command.userPermissions && command.userPermissions.length > 0) {
      const missing = command.userPermissions.filter(p => !message.member.permissions.has(p));
      if (missing.length > 0) {
        return message.reply({ embeds: [Embed.error('Missing Permissions', `You need: ${missing.map(p => `\`${p}\``).join(', ')}`)] });
      }
    }

    if (command.botPermissions && command.botPermissions.length > 0) {
      const missing = command.botPermissions.filter(p => !message.guild.members.me.permissions.has(p));
      if (missing.length > 0) {
        return message.reply({ embeds: [Embed.error('Bot Missing Permissions', `I need: ${missing.map(p => `\`${p}\``).join(', ')}`)] });
      }
    }

    // Cooldown check
    const cooldownKey = `${command.name}-${message.author.id}`;
    const now2 = Date.now();
    const cdAmount = (command.cooldown || 3) * 1000;
    const cdTimestamps = client.cooldowns.get(cooldownKey) || 0;
    if (now2 < cdTimestamps) {
      const remaining = ((cdTimestamps - now2) / 1000).toFixed(1);
      return message.reply({ embeds: [Embed.warn('Cooldown', `Please wait **${remaining}s** before using \`${command.name}\` again.`)] });
    }
    client.cooldowns.set(cooldownKey, now2 + cdAmount);

    // Track command usage
    client.commandStats.set(command.name, (client.commandStats.get(command.name) || 0) + 1);

    // Execute
    try {
      client.logger.command(`${message.author.tag} used ${command.name} in ${message.guild.name}`);
      await command.execute(client, message, args);
    } catch (err) {
      client.logger.error(`Command ${command.name} error: ${err.message}\n${err.stack}`);
      message.reply({ embeds: [Embed.error('Command Error', `An error occurred: ${err.message.slice(0, 200)}`)] }).catch(() => {});
    }
  }
};
