const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'messageDelete',
  async execute(client, message) {
    if (!message.guild || message.author?.bot) return;
    const cfg = client.config;
    if (!cfg.logChannelId) return;
    const logChannel = message.guild.channels.cache.get(cfg.logChannelId);
    if (!logChannel) return;
    const embed = new EmbedBuilder()
      .setColor('#ED4245')
      .setTitle('Message Deleted')
      .addFields(
        { name: 'Author', value: message.author?.tag || 'Unknown', inline: true },
        { name: 'Channel', value: message.channel?.toString() || 'Unknown', inline: true },
        { name: 'Content', value: message.content?.slice(0, 1024) || 'No content / embed' }
      )
      .setTimestamp();
    logChannel.send({ embeds: [embed] }).catch(() => {});
  }
};
