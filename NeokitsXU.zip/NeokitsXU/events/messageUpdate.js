const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'messageUpdate',
  async execute(client, oldMessage, newMessage) {
    if (!newMessage.guild || newMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return;
    const cfg = client.config;
    if (!cfg.logChannelId) return;
    const logChannel = newMessage.guild.channels.cache.get(cfg.logChannelId);
    if (!logChannel) return;
    const embed = new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle('Message Edited')
      .setURL(newMessage.url)
      .addFields(
        { name: 'Author', value: newMessage.author?.tag || 'Unknown', inline: true },
        { name: 'Channel', value: newMessage.channel?.toString() || 'Unknown', inline: true },
        { name: 'Before', value: (oldMessage.content || 'No content').slice(0, 1024) },
        { name: 'After', value: (newMessage.content || 'No content').slice(0, 1024) }
      )
      .setTimestamp();
    logChannel.send({ embeds: [embed] }).catch(() => {});
  }
};
