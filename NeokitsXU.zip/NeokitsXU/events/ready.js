const { ActivityType } = require('discord.js');

const typeMap = {
  playing: ActivityType.Playing,
  watching: ActivityType.Watching,
  listening: ActivityType.Listening,
  competing: ActivityType.Competing
};

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    const cfg = client.config;
    const actType = typeMap[cfg.status?.type?.toLowerCase()] ?? ActivityType.Playing;
    client.user.setPresence({
      activities: [{ name: cfg.status?.text || 'NeokitsXU', type: actType }],
      status: 'online'
    });

    client.logger.success(`Logged in as ${client.user.tag}`);
    client.logger.info(`Serving ${client.guilds.cache.size} guilds | ${client.users.cache.size} users`);
    client.logger.info(`Commands: ${client.commands.size} loaded`);
    client.logger.info(`Prefix: ${cfg.prefix}`);
    client.logger.info(`Owner: ${cfg.ownerId}`);
  }
};
