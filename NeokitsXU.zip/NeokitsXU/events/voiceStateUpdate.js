const { getVoiceConnection } = require('@discordjs/voice');

module.exports = {
  name: 'voiceStateUpdate',
  async execute(client, oldState, newState) {
    // Auto-leave if bot is alone
    const cfg = client.config;
    if (!cfg.music?.leaveOnEmpty) return;
    const guild = oldState.guild;
    const queue = client.queue.get(guild.id);
    if (!queue) return;
    const botChannel = guild.members.me.voice.channel;
    if (!botChannel) return;
    const members = botChannel.members.filter(m => !m.user.bot);
    if (members.size === 0) {
      setTimeout(() => {
        const q = client.queue.get(guild.id);
        if (!q) return;
        const bc = guild.members.me.voice.channel;
        if (!bc) return;
        const m = bc.members.filter(m => !m.user.bot);
        if (m.size === 0) {
          const conn = getVoiceConnection(guild.id);
          if (conn) conn.destroy();
          client.queue.delete(guild.id);
          if (q.textChannel) q.textChannel.send('👋 Left the voice channel due to inactivity.').catch(() => {});
        }
      }, cfg.music.leaveOnEmptyCooldown || 30000);
    }
  }
};
