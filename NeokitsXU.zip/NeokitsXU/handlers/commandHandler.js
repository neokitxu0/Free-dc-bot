const fs = require('fs');
const path = require('path');

module.exports = (client) => {
  const commandsPath = path.join(__dirname, '..', 'commands');
  const categories = fs.readdirSync(commandsPath).filter(f => fs.statSync(path.join(commandsPath, f)).isDirectory());

  let loaded = 0;
  for (const category of categories) {
    const files = fs.readdirSync(path.join(commandsPath, category)).filter(f => f.endsWith('.js'));
    for (const file of files) {
      try {
        const cmd = require(path.join(commandsPath, category, file));
        if (!cmd.name) continue;
        client.commands.set(cmd.name, cmd);
        if (cmd.aliases && Array.isArray(cmd.aliases)) {
          for (const alias of cmd.aliases) client.aliases.set(alias, cmd.name);
        }
        loaded++;
      } catch (err) {
        client.logger.error(`Failed to load command ${file}: ${err.message}`);
      }
    }
  }
  client.logger.success(`Loaded ${loaded} commands across ${categories.length} categories`);
};
