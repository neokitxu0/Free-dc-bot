const fs = require('fs');
const path = require('path');

module.exports = (client) => {
  const eventsPath = path.join(__dirname, '..', 'events');
  const files = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'));

  let loaded = 0;
  for (const file of files) {
    try {
      const event = require(path.join(eventsPath, file));
      if (!event.name) continue;
      if (event.once) client.once(event.name, (...args) => event.execute(client, ...args));
      else client.on(event.name, (...args) => event.execute(client, ...args));
      loaded++;
    } catch (err) {
      client.logger.error(`Failed to load event ${file}: ${err.message}`);
    }
  }
  client.logger.success(`Loaded ${loaded} events`);
};
