const DataManager = require('../utils/DataManager');

module.exports = (client) => {
  setInterval(() => {
    const reminders = DataManager.all('reminders');
    const now = Date.now();
    for (const [id, reminder] of Object.entries(reminders)) {
      if (now >= reminder.time) {
        const channel = client.channels.cache.get(reminder.channelId);
        if (channel) {
          channel.send(`<@${reminder.userId}> ⏰ Reminder: **${reminder.message}**`).catch(() => {});
        } else {
          client.users.fetch(reminder.userId).then(user => {
            user.send(`⏰ Reminder: **${reminder.message}**`).catch(() => {});
          }).catch(() => {});
        }
        DataManager.del('reminders', id);
      }
    }
  }, 10000);
};
