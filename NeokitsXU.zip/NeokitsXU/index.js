const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const fs = require('fs');
const path = require('path');

if (!fs.existsSync(path.join(__dirname, 'config', 'config.json'))) {
  console.error('\x1b[31m[ERROR]\x1b[0m config/config.json not found. Run \x1b[36mnpm run setup\x1b[0m first.');
  process.exit(1);
}

const config = require('./config/config.json');
const Logger = require('./utils/Logger');
const DataManager = require('./utils/DataManager');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildEmojisAndStickers,
    GatewayIntentBits.GuildIntegrations,
    GatewayIntentBits.GuildScheduledEvents,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.User, Partials.GuildMember],
});

client.commands = new Collection();
client.aliases = new Collection();
client.cooldowns = new Collection();
client.config = config;
client.logger = Logger;
client.data = DataManager;
client.queue = new Map();
client.giveaways = new Map();
client.tickets = new Map();
client.afk = new Map();
client.reminders = new Map();
client.commandStats = new Map();
client.startTime = Date.now();

require('./handlers/commandHandler')(client);
require('./handlers/eventHandler')(client);
require('./handlers/reminderHandler')(client);

process.on('unhandledRejection', (reason, promise) => {
  Logger.error(`Unhandled Rejection at: ${promise}\nReason: ${reason}`);
});

process.on('uncaughtException', err => {
  Logger.error(`Uncaught Exception: ${err.message}\n${err.stack}`);
});

process.on('SIGINT', () => {
  Logger.warn('Received SIGINT. Shutting down gracefully...');
  client.destroy();
  process.exit(0);
});

client.login(config.token).catch(err => {
  Logger.error(`Failed to login: ${err.message}`);
  process.exit(1);
});
