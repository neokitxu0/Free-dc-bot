const readline = require('readline');
const fs = require('fs');
const path = require('path');

const chalk = (() => {
  try { return require('chalk'); } catch { return { green: s => s, cyan: s => s, yellow: s => s, red: s => s, bold: { green: s => s, cyan: s => s } }; }
})();

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

function ask(question) {
  return new Promise(resolve => rl.question(question, resolve));
}

async function main() {
  console.clear();
  console.log(chalk.cyan('╔════════════════════════════════════════════╗'));
  console.log(chalk.cyan('║      NeokitsXU Bot — Setup Wizard          ║'));
  console.log(chalk.cyan('╚════════════════════════════════════════════╝\n'));

  const token = await ask(chalk.yellow('Enter Bot Token: '));
  const ownerId = await ask(chalk.yellow('Enter Owner ID: '));
  const prefix = (await ask(chalk.yellow('Enter Prefix [default: !]: '))) || '!';
  let statusType = (await ask(chalk.yellow('Enter Status Type (playing/watching/listening/competing) [default: playing]: '))).toLowerCase() || 'playing';
  if (!['playing','watching','listening','competing'].includes(statusType)) statusType = 'playing';
  const statusText = (await ask(chalk.yellow('Enter Status Text [default: NeokitsXU Bot]: '))) || 'NeokitsXU Bot';

  rl.close();

  const configDir = path.join(__dirname, 'config');
  if (!fs.existsSync(configDir)) fs.mkdirSync(configDir, { recursive: true });

  const config = {
    token,
    ownerId,
    prefix,
    status: { type: statusType, text: statusText },
    embedColor: '#5865F2',
    errorColor: '#ED4245',
    successColor: '#57F287',
    warningColor: '#FEE75C',
    supportServer: 'https://discord.gg/neokitsxu',
    botInvite: '',
    maintenance: false,
    maintenanceMessage: 'Bot is currently under maintenance.',
    logChannelId: '',
    economy: { currencyName: 'Coins', currencySymbol: '🪙', dailyAmount: 200, weeklyAmount: 1000, monthlyAmount: 5000, workMin: 50, workMax: 300 },
    leveling: { xpPerMessage: [15, 25], xpCooldown: 60, multiplier: 1.0, levelUpMessage: 'Congratulations {user}, you reached level {level}!' },
    music: { maxQueueSize: 200, defaultVolume: 80, leaveOnEmpty: true, leaveOnEmptyCooldown: 30000 },
    ticket: { categoryId: '', logChannelId: '', transcriptChannelId: '', maxTicketsPerUser: 1 },
    giveaway: { defaultColor: '#FF6B6B', defaultEmoji: '🎉' },
    antiSpam: { enabled: false, maxMessages: 5, interval: 5000 },
    antiLink: { enabled: false, whitelist: [] },
    antiInvite: { enabled: false, whitelist: [] },
    antiRaid: { enabled: false, joinThreshold: 10, joinInterval: 10000 },
    welcomeChannel: '',
    welcomeMessage: 'Welcome {user} to {server}!',
    goodbyeChannel: '',
    goodbyeMessage: '{user} has left {server}.',
    autoRoles: [],
    reactionRoles: {},
    autoResponses: {},
    blacklistedUsers: [],
    blacklistedGuilds: []
  };

  fs.writeFileSync(path.join(configDir, 'config.json'), JSON.stringify(config, null, 2));

  const dataDir = path.join(__dirname, 'data');
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

  const dataFiles = {
    'economy.json': {},
    'levels.json': {},
    'warnings.json': {},
    'tickets.json': {},
    'giveaways.json': {},
    'polls.json': {},
    'afk.json': {},
    'todos.json': {},
    'playlists.json': {},
    'notes.json': {},
    'reports.json': {},
    'suggestions.json': {},
    'modlogs.json': {},
    'reminders.json': {},
    'cooldowns.json': {}
  };

  for (const [file, def] of Object.entries(dataFiles)) {
    const fp = path.join(dataDir, file);
    if (!fs.existsSync(fp)) fs.writeFileSync(fp, JSON.stringify(def, null, 2));
  }

  console.log('\n' + chalk.bold.green('✅ Configuration saved to config/config.json'));
  console.log(chalk.bold.green('✅ Data files initialized in data/'));
  console.log('\n' + chalk.cyan('Run ' + chalk.bold.cyan('npm start') + ' to launch NeokitsXU!\n'));
}

main().catch(err => { console.error('Setup error:', err); process.exit(1); });
