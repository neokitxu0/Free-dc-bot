const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const cache = {};

function getPath(file) {
  return path.join(dataDir, `${file}.json`);
}

function load(file) {
  if (cache[file]) return cache[file];
  const fp = getPath(file);
  if (!fs.existsSync(fp)) {
    fs.writeFileSync(fp, '{}');
    cache[file] = {};
    return {};
  }
  try {
    cache[file] = JSON.parse(fs.readFileSync(fp, 'utf8'));
    return cache[file];
  } catch {
    cache[file] = {};
    return {};
  }
}

function save(file, data) {
  cache[file] = data;
  fs.writeFileSync(getPath(file), JSON.stringify(data, null, 2));
}

function get(file, key, def = null) {
  const data = load(file);
  return key in data ? data[key] : def;
}

function set(file, key, value) {
  const data = load(file);
  data[key] = value;
  save(file, data);
  return value;
}

function del(file, key) {
  const data = load(file);
  delete data[key];
  save(file, data);
}

function all(file) {
  return load(file);
}

function ensure(file, key, def) {
  const data = load(file);
  if (!(key in data)) {
    data[key] = typeof def === 'object' && def !== null ? JSON.parse(JSON.stringify(def)) : def;
    save(file, data);
  }
  return data[key];
}

function push(file, key, value) {
  const data = load(file);
  if (!Array.isArray(data[key])) data[key] = [];
  data[key].push(value);
  save(file, data);
  return data[key];
}

function pull(file, key, value) {
  const data = load(file);
  if (!Array.isArray(data[key])) return;
  data[key] = data[key].filter(v => v !== value);
  save(file, data);
  return data[key];
}

function has(file, key) {
  return key in load(file);
}

function keys(file) {
  return Object.keys(load(file));
}

function size(file) {
  return Object.keys(load(file)).length;
}

module.exports = { load, save, get, set, del, all, ensure, push, pull, has, keys, size };
