const DataManager = require('./DataManager');

function getUser(userId) {
  return DataManager.ensure('economy', userId, {
    wallet: 0, bank: 0, inventory: [], lastDaily: 0, lastWeekly: 0, lastMonthly: 0,
    lastWork: 0, lastBeg: 0, lastSearch: 0, prestige: 0, totalEarned: 0
  });
}

function saveUser(userId, data) {
  DataManager.set('economy', userId, data);
}

function getBalance(userId) {
  const u = getUser(userId);
  return { wallet: u.wallet, bank: u.bank, total: u.wallet + u.bank };
}

function addWallet(userId, amount) {
  const u = getUser(userId);
  u.wallet = Math.max(0, u.wallet + amount);
  if (amount > 0) u.totalEarned = (u.totalEarned || 0) + amount;
  saveUser(userId, u);
  return u.wallet;
}

function removeWallet(userId, amount) {
  const u = getUser(userId);
  u.wallet = Math.max(0, u.wallet - amount);
  saveUser(userId, u);
  return u.wallet;
}

function deposit(userId, amount) {
  const u = getUser(userId);
  const actual = Math.min(amount, u.wallet);
  u.wallet -= actual;
  u.bank += actual;
  saveUser(userId, u);
  return { deposited: actual, wallet: u.wallet, bank: u.bank };
}

function withdraw(userId, amount) {
  const u = getUser(userId);
  const actual = Math.min(amount, u.bank);
  u.bank -= actual;
  u.wallet += actual;
  saveUser(userId, u);
  return { withdrawn: actual, wallet: u.wallet, bank: u.bank };
}

function getLeaderboard(limit = 10) {
  const all = DataManager.all('economy');
  return Object.entries(all)
    .map(([id, d]) => ({ id, total: (d.wallet || 0) + (d.bank || 0), wallet: d.wallet || 0, bank: d.bank || 0 }))
    .sort((a, b) => b.total - a.total)
    .slice(0, limit);
}

function addItem(userId, item) {
  const u = getUser(userId);
  if (!u.inventory) u.inventory = [];
  const existing = u.inventory.find(i => i.id === item.id);
  if (existing) existing.amount = (existing.amount || 1) + 1;
  else u.inventory.push({ ...item, amount: 1 });
  saveUser(userId, u);
}

function removeItem(userId, itemId) {
  const u = getUser(userId);
  if (!u.inventory) return false;
  const idx = u.inventory.findIndex(i => i.id === itemId);
  if (idx === -1) return false;
  if (u.inventory[idx].amount > 1) u.inventory[idx].amount--;
  else u.inventory.splice(idx, 1);
  saveUser(userId, u);
  return true;
}

module.exports = { getUser, saveUser, getBalance, addWallet, removeWallet, deposit, withdraw, getLeaderboard, addItem, removeItem };
