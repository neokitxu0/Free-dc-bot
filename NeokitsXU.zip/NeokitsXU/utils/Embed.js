const { EmbedBuilder } = require('discord.js');

function getConfig() {
  try { return require('../config/config.json'); } catch { return { embedColor: '#5865F2', errorColor: '#ED4245', successColor: '#57F287', warningColor: '#FEE75C' }; }
}

module.exports = {
  success(title, description, fields = []) {
    const cfg = getConfig();
    const e = new EmbedBuilder().setColor(cfg.successColor).setDescription(`✅ **${title}**${description ? `\n${description}` : ''}`).setTimestamp();
    if (fields.length) e.addFields(fields);
    return e;
  },
  error(title, description, fields = []) {
    const cfg = getConfig();
    const e = new EmbedBuilder().setColor(cfg.errorColor).setDescription(`❌ **${title}**${description ? `\n${description}` : ''}`).setTimestamp();
    if (fields.length) e.addFields(fields);
    return e;
  },
  warn(title, description, fields = []) {
    const cfg = getConfig();
    const e = new EmbedBuilder().setColor(cfg.warningColor).setDescription(`⚠️ **${title}**${description ? `\n${description}` : ''}`).setTimestamp();
    if (fields.length) e.addFields(fields);
    return e;
  },
  info(title, description, fields = []) {
    const cfg = getConfig();
    const e = new EmbedBuilder().setColor(cfg.embedColor).setTitle(title);
    if (description) e.setDescription(description);
    if (fields.length) e.addFields(fields);
    e.setTimestamp();
    return e;
  },
  custom(options = {}) {
    const cfg = getConfig();
    const e = new EmbedBuilder().setColor(options.color || cfg.embedColor);
    if (options.title) e.setTitle(options.title);
    if (options.description) e.setDescription(options.description);
    if (options.thumbnail) e.setThumbnail(options.thumbnail);
    if (options.image) e.setImage(options.image);
    if (options.footer) e.setFooter(options.footer);
    if (options.author) e.setAuthor(options.author);
    if (options.fields && options.fields.length) e.addFields(options.fields);
    if (options.timestamp !== false) e.setTimestamp();
    if (options.url) e.setURL(options.url);
    return e;
  }
};
