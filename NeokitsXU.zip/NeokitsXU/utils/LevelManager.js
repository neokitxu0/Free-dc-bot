const DataManager = require('./DataManager');

function getXpForLevel(level) {
  return Math.floor(100 * Math.pow(level, 1.5));
}

function getLevelFromXp(xp) {
  let level = 0;
  while (xp >= getXpForLevel(level + 1)) {
    xp -= getXpForLevel(level + 1);
    level++;
  }
  return level;
}

function getUser(guildId, userId) {
  const key = `${guildId}-${userId}`;
  return DataManager.ensure('levels', key, { xp: 0, level: 0, totalXp: 0, messages: 0, lastMessage: 0 });
}

function saveUser(guildId, userId, data) {
  DataManager.set('levels', `${guildId}-${userId}`, data);
}

function addXp(guildId, userId, amount) {
  const u = getUser(guildId, userId);
  u.xp += amount;
  u.totalXp = (u.totalXp || 0) + amount;
  u.messages = (u.messages || 0) + 1;
  const oldLevel = u.level;
  while (u.xp >= getXpForLevel(u.level + 1)) {
    u.xp -= getXpForLevel(u.level + 1);
    u.level++;
  }
  saveUser(guildId, userId, u);
  return { leveledUp: u.level > oldLevel, oldLevel, newLevel: u.level, xp: u.xp, totalXp: u.totalXp };
}

function setXp(guildId, userId, xp) {
  const u = getUser(guildId, userId);
  u.totalXp = xp;
  u.xp = xp;
  u.level = 0;
  while (u.xp >= getXpForLevel(u.level + 1)) {
    u.xp -= getXpForLevel(u.level + 1);
    u.level++;
  }
  saveUser(guildId, userId, u);
  return u;
}

function setLevel(guildId, userId, level) {
  const u = getUser(guildId, userId);
  u.level = level;
  u.xp = 0;
  u.totalXp = 0;
  for (let i = 1; i <= level; i++) u.totalXp += getXpForLevel(i);
  saveUser(guildId, userId, u);
  return u;
}

function getLeaderboard(guildId, limit = 10) {
  const all = DataManager.all('levels');
  return Object.entries(all)
    .filter(([k]) => k.startsWith(guildId + '-'))
    .map(([k, d]) => ({ userId: k.split('-')[1], ...d }))
    .sort((a, b) => (b.totalXp || 0) - (a.totalXp || 0))
    .slice(0, limit);
}

function getRank(guildId, userId) {
  const lb = getLeaderboard(guildId, 9999);
  return lb.findIndex(u => u.userId === userId) + 1;
}

function resetUser(guildId, userId) {
  saveUser(guildId, userId, { xp: 0, level: 0, totalXp: 0, messages: 0, lastMessage: 0 });
}

module.exports = { getXpForLevel, getLevelFromXp, getUser, saveUser, addXp, setXp, setLevel, getLeaderboard, getRank, resetUser };
