const fs = require('fs');
const path = require('path');

const logsDir = path.join(__dirname, '..', 'logs');
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });

const colors = {
  reset: '\x1b[0m', bright: '\x1b[1m',
  red: '\x1b[31m', green: '\x1b[32m', yellow: '\x1b[33m',
  blue: '\x1b[34m', magenta: '\x1b[35m', cyan: '\x1b[36m', white: '\x1b[37m'
};

function timestamp() {
  return new Date().toISOString().replace('T', ' ').slice(0, 19);
}

function writeLog(level, message) {
  const line = `[${timestamp()}] [${level}] ${message}\n`;
  const file = path.join(logsDir, `bot-${new Date().toISOString().slice(0, 10)}.log`);
  try { fs.appendFileSync(file, line); } catch {}
}

const Logger = {
  info(msg) {
    console.log(`${colors.cyan}[INFO]${colors.reset} ${colors.bright}${timestamp()}${colors.reset} ${msg}`);
    writeLog('INFO', msg);
  },
  success(msg) {
    console.log(`${colors.green}[SUCCESS]${colors.reset} ${colors.bright}${timestamp()}${colors.reset} ${msg}`);
    writeLog('SUCCESS', msg);
  },
  warn(msg) {
    console.log(`${colors.yellow}[WARN]${colors.reset} ${colors.bright}${timestamp()}${colors.reset} ${msg}`);
    writeLog('WARN', msg);
  },
  error(msg) {
    console.log(`${colors.red}[ERROR]${colors.reset} ${colors.bright}${timestamp()}${colors.reset} ${msg}`);
    writeLog('ERROR', msg);
  },
  debug(msg) {
    if (process.env.DEBUG === 'true') {
      console.log(`${colors.magenta}[DEBUG]${colors.reset} ${colors.bright}${timestamp()}${colors.reset} ${msg}`);
      writeLog('DEBUG', msg);
    }
  },
  command(msg) {
    console.log(`${colors.blue}[CMD]${colors.reset} ${colors.bright}${timestamp()}${colors.reset} ${msg}`);
    writeLog('CMD', msg);
  },
  event(msg) {
    console.log(`${colors.magenta}[EVENT]${colors.reset} ${colors.bright}${timestamp()}${colors.reset} ${msg}`);
    writeLog('EVENT', msg);
  }
};

module.exports = Logger;
