const { createAudioPlayer, createAudioResource, AudioPlayerStatus, VoiceConnectionStatus, entersState, joinVoiceChannel, getVoiceConnection } = require('@discordjs/voice');
let playDl;
try { playDl = require('play-dl'); } catch {}

function createQueue(guildId) {
  return {
    guildId,
    textChannel: null,
    voiceChannel: null,
    connection: null,
    player: null,
    tracks: [],
    current: null,
    volume: 80,
    loop: 'none',
    autoplay: false,
    playing: false,
    paused: false,
    bassboost: false,
    nightcore: false,
    filters: []
  };
}

async function joinChannel(channel) {
  const connection = joinVoiceChannel({
    channelId: channel.id,
    guildId: channel.guild.id,
    adapterCreator: channel.guild.voiceAdapterCreator,
    selfDeaf: true,
    selfMute: false
  });
  try {
    await entersState(connection, VoiceConnectionStatus.Ready, 30_000);
  } catch (err) {
    connection.destroy();
    throw err;
  }
  return connection;
}

async function searchTrack(query) {
  if (!playDl) return null;
  try {
    if (query.match(/^https?:\/\//)) {
      const info = await playDl.video_info(query);
      return [{
        title: info.video_details.title,
        url: info.video_details.url,
        duration: info.video_details.durationInSec,
        thumbnail: info.video_details.thumbnails[0]?.url,
        author: info.video_details.channel?.name,
        requestedBy: null
      }];
    }
    const results = await playDl.search(query, { source: { youtube: 'video' }, limit: 1 });
    return results.map(v => ({
      title: v.title,
      url: v.url,
      duration: v.durationInSec,
      thumbnail: v.thumbnails[0]?.url,
      author: v.channel?.name,
      requestedBy: null
    }));
  } catch { return null; }
}

async function createStream(url) {
  if (!playDl) return null;
  try {
    const stream = await playDl.stream(url, { quality: 2 });
    return createAudioResource(stream.stream, {
      inputType: stream.type,
      inlineVolume: true
    });
  } catch { return null; }
}

function formatDuration(seconds) {
  if (!seconds) return '0:00';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  return `${m}:${String(s).padStart(2,'0')}`;
}

function shuffle(array) {
  const a = [...array];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

module.exports = { createQueue, joinChannel, searchTrack, createStream, formatDuration, shuffle };
