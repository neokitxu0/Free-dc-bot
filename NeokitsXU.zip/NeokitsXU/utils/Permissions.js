const { PermissionsBitField } = require('discord.js');

function hasPermission(member, permission) {
  if (!member) return false;
  if (member.id === member.guild.ownerId) return true;
  try {
    return member.permissions.has(PermissionsBitField.Flags[permission] || permission);
  } catch { return false; }
}

function isOwner(client, userId) {
  return userId === client.config.ownerId;
}

function isBlacklisted(client, userId) {
  return (client.config.blacklistedUsers || []).includes(userId);
}

function missingPerms(member, permissions) {
  const missing = [];
  for (const perm of permissions) {
    if (!hasPermission(member, perm)) missing.push(perm);
  }
  return missing;
}

function botHasPermission(guild, permission) {
  const me = guild.members.me;
  if (!me) return false;
  try {
    return me.permissions.has(PermissionsBitField.Flags[permission] || permission);
  } catch { return false; }
}

function formatPerms(perms) {
  return perms.map(p => `\`${p.replace(/([A-Z])/g, ' $1').trim()}\``).join(', ');
}

module.exports = { hasPermission, isOwner, isBlacklisted, missingPerms, botHasPermission, formatPerms };
