/**
 * NekoBot Configuration File
 * All bot-wide settings and defaults are defined here.
 */

module.exports = {
  // ─── Bot Identity ──────────────────────────────────────────────────────────
  botName: 'NekoBot',
  prefix: '.',
  ownerIds: [process.env.OWNER_ID || 'YOUR_DISCORD_ID'],
  supportServerId: process.env.SUPPORT_SERVER_ID || '',
  supportServerInvite: process.env.SUPPORT_SERVER_INVITE || 'https://discord.gg/yourinvite',

  // ─── Appearance ────────────────────────────────────────────────────────────
  colors: {
    primary: 0x9B59B6,    // Purple
    success: 0x2ECC71,    // Green
    error: 0xE74C3C,      // Red
    warning: 0xF39C12,    // Yellow
    info: 0x3498DB,       // Blue
    moderation: 0xE74C3C, // Red for mod actions
    economy: 0xF1C40F,    // Gold
    music: 0x1DB954,      // Spotify Green
    fun: 0xFF6B6B,        // Coral
    level: 0x9B59B6,      // Purple
  },

  // ─── Status ────────────────────────────────────────────────────────────────
  presence: {
    status: 'online', // online | idle | dnd | invisible
    activities: [
      { name: 'NekoCloud Hosting', type: 3 }, // 3 = Watching
      { name: '| .help', type: 2 },            // 2 = Listening
      { name: 'your server', type: 3 },
    ],
    activityRotationInterval: 30_000, // ms between status rotations
  },

  // ─── Economy ───────────────────────────────────────────────────────────────
  economy: {
    currency: '🪙',
    currencyName: 'Nekos',
    daily: { min: 100, max: 500 },
    weekly: { min: 500, max: 2000 },
    monthly: { min: 2000, max: 10000 },
    work: { min: 50, max: 300, cooldown: 3600 },      // 1h
    beg: { min: 1, max: 100, cooldown: 1800 },         // 30m
    crime: { min: 100, max: 1000, cooldown: 7200, failChance: 0.35 }, // 2h, 35% fail
    rob: { failChance: 0.50, minBal: 100, cooldown: 3600 },
    bankInterestRate: 0.005, // 0.5% daily interest
    shopItems: [
      { id: 'fishing_rod', name: '🎣 Fishing Rod', price: 500, description: 'Catch fish for coins' },
      { id: 'shovel', name: '⛏️ Shovel', price: 300, description: 'Dig for coins' },
      { id: 'laptop', name: '💻 Laptop', price: 2000, description: 'Work from home for more coins' },
      { id: 'lucky_coin', name: '🍀 Lucky Coin', price: 1000, description: 'Increases crime success rate' },
    ],
  },

  // ─── Leveling ──────────────────────────────────────────────────────────────
  leveling: {
    xpPerMessage: { min: 10, max: 25 },
    xpCooldown: 60_000,   // 1 minute XP cooldown per user
    xpFormula: (level) => 5 * level ** 2 + 50 * level + 100,
    levelUpMessage: true,
  },

  // ─── Moderation ────────────────────────────────────────────────────────────
  moderation: {
    antiSpam: {
      maxMessages: 5,
      interval: 5000,     // 5s window
      punishment: 'mute', // mute | kick | ban
      muteDuration: 300_000, // 5 minutes
    },
    antiLink: {
      punishment: 'delete', // delete | warn | mute | kick | ban
      whitelist: [],
    },
    antiBadWords: {
      punishment: 'delete',
      defaultWords: ['badword1', 'badword2'],
    },
    antiRaid: {
      joinThreshold: 10,   // joins per
      joinInterval: 10000, // 10 seconds
      punishment: 'kick',
    },
    antiMentionSpam: {
      maxMentions: 5,
      punishment: 'mute',
      muteDuration: 300_000,
    },
  },

  // ─── Tickets ───────────────────────────────────────────────────────────────
  tickets: {
    maxPerUser: 1,
    transcriptChannel: null,
    categories: [
      { id: 'general', label: '📋 General Support', description: 'General help and questions' },
      { id: 'billing', label: '💳 Billing', description: 'Payment and billing issues' },
      { id: 'technical', label: '🔧 Technical', description: 'Technical issues and bugs' },
      { id: 'report', label: '🚨 Report', description: 'Report a user or issue' },
    ],
  },

  // ─── AI ────────────────────────────────────────────────────────────────────
  ai: {
    model: 'gpt-3.5-turbo',
    maxTokens: 500,
    conversationMemoryLength: 10, // messages to remember
    systemPrompt: 'You are NekoBot, a friendly and helpful Discord bot assistant. Keep responses concise and helpful.',
  },

  // ─── Music ─────────────────────────────────────────────────────────────────
  music: {
    maxQueueSize: 100,
    defaultVolume: 50,
    leaveOnEmpty: true,
    leaveOnEmptyDelay: 300_000, // 5 minutes
    leaveOnFinish: true,
    leaveOnFinishDelay: 300_000,
  },

  // ─── Dashboard API ─────────────────────────────────────────────────────────
  dashboard: {
    enabled: true,
    port: process.env.DASHBOARD_PORT || 3000,
    secret: process.env.DASHBOARD_SECRET || 'changeme',
    clientId: process.env.DISCORD_CLIENT_ID || '',
    clientSecret: process.env.DISCORD_CLIENT_SECRET || '',
    redirectUri: process.env.REDIRECT_URI || 'http://localhost:3000/callback',
    jwtSecret: process.env.JWT_SECRET || 'changeme_jwt',
    jwtExpiry: '7d',
  },

  // ─── Logging ───────────────────────────────────────────────────────────────
  logging: {
    enabled: true,
    events: {
      messageDelete: true,
      messageEdit: true,
      memberJoin: true,
      memberLeave: true,
      memberUpdate: true,
      roleCreate: true,
      roleDelete: true,
      channelCreate: true,
      channelDelete: true,
      voiceState: true,
      banAdd: true,
      banRemove: true,
    },
  },

  // ─── Premium ───────────────────────────────────────────────────────────────
  premium: {
    features: ['ai_chat', 'music_filters', 'custom_prefix', 'advanced_automod'],
    roles: {
      tier1: process.env.PREMIUM_TIER1_ROLE || '',
      tier2: process.env.PREMIUM_TIER2_ROLE || '',
      tier3: process.env.PREMIUM_TIER3_ROLE || '',
    },
  },

  // ─── Emojis ────────────────────────────────────────────────────────────────
  emojis: {
    success: '✅',
    error: '❌',
    warning: '⚠️',
    loading: '⏳',
    info: 'ℹ️',
    coin: '🪙',
    music: '🎵',
    shield: '🛡️',
    ticket: '🎫',
    star: '⭐',
    crown: '👑',
    robot: '🤖',
    chart: '📊',
    lock: '🔒',
    unlock: '🔓',
    mute: '🔇',
    volume: '🔊',
    skip: '⏭️',
    stop: '⏹️',
    loop: '🔁',
    shuffle: '🔀',
    queue: '📋',
  },
};
