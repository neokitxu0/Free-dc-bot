/**
 * /aichannel — Set or disable the AI chat channel.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const Guild = require('../../models/Guild');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('aichannel')
    .setDescription('Set a channel where members can chat freely with NekoBot AI.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption(o => o.setName('channel').setDescription('Channel (leave empty to disable)').setRequired(false)),

  userPermissions: ['ManageGuild'],
  guildOnly: true,
  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply();

    const channel = interaction.options.getChannel('channel');

    await Guild.findOneAndUpdate(
      { guildId: interaction.guild.id },
      { 'channels.aiChannel': channel?.id || null },
      { upsert: true }
    );

    if (channel) {
      return interaction.editReply({
        embeds: [successEmbed('AI Channel Set', `${channel} is now the AI chat channel. Members can talk to NekoBot AI freely there!`)],
      });
    } else {
      return interaction.editReply({
        embeds: [successEmbed('AI Channel Disabled', 'The AI chat channel has been disabled.')],
      });
    }
  },
};
