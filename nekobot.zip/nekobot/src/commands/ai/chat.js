/**
 * /chat — Chat with NekoBot AI (powered by OpenAI).
 */

const { SlashCommandBuilder } = require('discord.js');
const { aiEmbed, errorEmbed } = require('../../utils/embed');
const { isPremium } = require('../../utils/permissions');
const User = require('../../models/User');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('chat')
    .setDescription('Chat with NekoBot AI.')
    .addStringOption(o => o.setName('message').setDescription('Your message').setRequired(true)),

  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply();

    if (!process.env.OPENAI_API_KEY) {
      return interaction.editReply({ embeds: [errorEmbed('AI Unavailable', 'AI features are not configured. Set `OPENAI_API_KEY` in your .env file.')] });
    }

    const message = interaction.options.getString('message');

    // Load conversation memory
    let userDoc = await User.findOne({ userId: interaction.user.id });
    if (!userDoc) userDoc = await User.create({ userId: interaction.user.id, username: interaction.user.tag });

    // Keep last N messages for context
    const recentMemory = userDoc.aiMemory.slice(-config.ai.conversationMemoryLength);

    const messages = [
      { role: 'system', content: config.ai.systemPrompt },
      ...recentMemory.map(m => ({ role: m.role, content: m.content })),
      { role: 'user', content: message },
    ];

    try {
      const OpenAI = require('openai');
      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

      const response = await openai.chat.completions.create({
        model: config.ai.model,
        messages,
        max_tokens: config.ai.maxTokens,
        temperature: 0.8,
      });

      const reply = response.choices[0]?.message?.content || 'I have no response.';

      // Save to memory
      userDoc.aiMemory.push({ role: 'user', content: message });
      userDoc.aiMemory.push({ role: 'assistant', content: reply });
      // Cap memory length
      if (userDoc.aiMemory.length > config.ai.conversationMemoryLength * 2) {
        userDoc.aiMemory = userDoc.aiMemory.slice(-config.ai.conversationMemoryLength * 2);
      }
      await userDoc.save();

      return interaction.editReply({
        embeds: [aiEmbed(reply.slice(0, 4096))
          .setFooter({ text: `${config.botName} AI | Model: ${config.ai.model}` })],
      });
    } catch (err) {
      return interaction.editReply({ embeds: [errorEmbed('AI Error', `Failed to get AI response: ${err.message}`)] });
    }
  },
};
