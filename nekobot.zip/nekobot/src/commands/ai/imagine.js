/**
 * /imagine — Generate an AI image using DALL-E.
 */

const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('imagine')
    .setDescription('Generate an AI image using DALL-E.')
    .addStringOption(o => o.setName('prompt').setDescription('Image description').setRequired(true))
    .addStringOption(o => o.setName('size').setDescription('Image size').setRequired(false)
      .addChoices(
        { name: '256x256 (small)', value: '256x256' },
        { name: '512x512 (medium)', value: '512x512' },
        { name: '1024x1024 (large)', value: '1024x1024' },
      )),

  cooldown: 15,

  async execute(client, interaction) {
    await interaction.deferReply();

    if (!process.env.OPENAI_API_KEY) {
      return interaction.editReply({ embeds: [errorEmbed('AI Unavailable', 'Set `OPENAI_API_KEY` to enable image generation.')] });
    }

    const prompt = interaction.options.getString('prompt');
    const size   = interaction.options.getString('size') || '512x512';

    try {
      const OpenAI = require('openai');
      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

      const response = await openai.images.generate({
        model: 'dall-e-2',
        prompt,
        n: 1,
        size,
      });

      const imageUrl = response.data[0]?.url;
      if (!imageUrl) throw new Error('No image URL returned');

      const embed = baseEmbed('primary')
        .setTitle('🎨 AI Generated Image')
        .setDescription(`**Prompt:** ${prompt}`)
        .setImage(imageUrl)
        .setFooter({ text: `Requested by ${interaction.user.tag}` });

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ embeds: [errorEmbed('Generation Failed', `Could not generate image: ${err.message}`)] });
    }
  },
};
