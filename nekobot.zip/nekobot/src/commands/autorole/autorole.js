/**
 * /autorole — Manage auto-roles assigned to new members.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embed');
const Guild = require('../../models/Guild');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('autorole')
    .setDescription('Manage auto-roles assigned when a member joins.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand(sub => sub
      .setName('add')
      .setDescription('Add an auto-role')
      .addRoleOption(o => o.setName('role').setDescription('Role to auto-assign').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('remove')
      .setDescription('Remove an auto-role')
      .addRoleOption(o => o.setName('role').setDescription('Role to remove').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('list')
      .setDescription('List all auto-roles')),

  userPermissions: ['ManageRoles'],
  botPermissions: ['ManageRoles'],
  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    let guildDoc = await Guild.findOneAndUpdate(
      { guildId: interaction.guild.id },
      {},
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    if (sub === 'add') {
      const role = interaction.options.getRole('role');

      if (guildDoc.roles.autoRole.includes(role.id)) {
        return interaction.editReply({ embeds: [errorEmbed('Already Added', `${role} is already an auto-role.`)] });
      }

      if (guildDoc.roles.autoRole.length >= 5) {
        return interaction.editReply({ embeds: [errorEmbed('Limit Reached', 'You can only have up to 5 auto-roles.')] });
      }

      // Check role hierarchy
      if (role.position >= interaction.guild.members.me.roles.highest.position) {
        return interaction.editReply({ embeds: [errorEmbed('Hierarchy Error', 'I cannot assign a role higher than or equal to my highest role.')] });
      }

      guildDoc.roles.autoRole.push(role.id);
      await guildDoc.save();

      return interaction.editReply({ embeds: [successEmbed('Auto-Role Added', `${role} will now be given to new members.`)] });
    }

    if (sub === 'remove') {
      const role = interaction.options.getRole('role');
      guildDoc.roles.autoRole = guildDoc.roles.autoRole.filter(r => r !== role.id);
      await guildDoc.save();
      return interaction.editReply({ embeds: [successEmbed('Auto-Role Removed', `${role} removed from auto-roles.`)] });
    }

    if (sub === 'list') {
      const roles = guildDoc.roles.autoRole;
      if (!roles.length) return interaction.editReply({ embeds: [infoEmbed('Auto-Roles', 'No auto-roles configured.')] });
      return interaction.editReply({
        embeds: [infoEmbed('Auto-Roles', `The following roles are assigned to new members:\n${roles.map(r => `<@&${r}>`).join('\n')}`)],
      });
    }
  },
};
