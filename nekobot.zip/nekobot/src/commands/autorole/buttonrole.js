/**
 * /buttonrole — Create a button-based role selection message.
 */

const {
  SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder,
  ButtonBuilder, ButtonStyle, EmbedBuilder,
} = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const AutoRole = require('../../models/AutoRole');
const Guild    = require('../../models/Guild');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('buttonrole')
    .setDescription('Create a button-based role selection panel.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addChannelOption(o => o.setName('channel').setDescription('Channel to send the panel').setRequired(true))
    .addStringOption(o => o.setName('title').setDescription('Panel title').setRequired(true))
    .addStringOption(o => o.setName('description').setDescription('Panel description').setRequired(true))
    // Support up to 5 role-button pairs
    .addRoleOption(o => o.setName('role1').setDescription('Role 1').setRequired(true))
    .addStringOption(o => o.setName('label1').setDescription('Button label for role 1').setRequired(true))
    .addRoleOption(o => o.setName('role2').setDescription('Role 2').setRequired(false))
    .addStringOption(o => o.setName('label2').setDescription('Button label for role 2').setRequired(false))
    .addRoleOption(o => o.setName('role3').setDescription('Role 3').setRequired(false))
    .addStringOption(o => o.setName('label3').setDescription('Button label for role 3').setRequired(false))
    .addRoleOption(o => o.setName('role4').setDescription('Role 4').setRequired(false))
    .addStringOption(o => o.setName('label4').setDescription('Button label for role 4').setRequired(false))
    .addRoleOption(o => o.setName('role5').setDescription('Role 5').setRequired(false))
    .addStringOption(o => o.setName('label5').setDescription('Button label for role 5').setRequired(false)),

  userPermissions: ['ManageRoles'],
  botPermissions:  ['ManageRoles'],
  guildOnly: true,
  cooldown: 10,

  async execute(client, interaction) {
    await interaction.deferReply({ ephemeral: true });

    const channel = interaction.options.getChannel('channel');
    const title   = interaction.options.getString('title');
    const description = interaction.options.getString('description');

    const roleEntries = [];
    for (let i = 1; i <= 5; i++) {
      const role  = interaction.options.getRole(`role${i}`);
      const label = interaction.options.getString(`label${i}`);
      if (role && label) roleEntries.push({ role, label });
    }

    if (!roleEntries.length) {
      return interaction.editReply({ embeds: [errorEmbed('Error', 'At least one role is required.')] });
    }

    // Build buttons (max 5 per row)
    const buttons = roleEntries.map(({ role, label }) =>
      new ButtonBuilder()
        .setCustomId(`role_${role.id}`)
        .setLabel(label.slice(0, 80))
        .setStyle(ButtonStyle.Primary)
    );

    const row = new ActionRowBuilder().addComponents(buttons);

    const embed = new EmbedBuilder()
      .setColor(0x9B59B6)
      .setTitle(title)
      .setDescription(description)
      .setFooter({ text: 'Click a button to toggle your role!' })
      .setTimestamp();

    const msg = await channel.send({ embeds: [embed], components: [row] });

    // Save to DB
    await AutoRole.create({
      guildId:   interaction.guild.id,
      type:      'button',
      messageId: msg.id,
      channelId: channel.id,
      roles:     roleEntries.map(({ role, label }) => ({ roleId: role.id, label })),
    });

    return interaction.editReply({ embeds: [successEmbed('Panel Created', `Button role panel sent to ${channel}.`)] });
  },
};
