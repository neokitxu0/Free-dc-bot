/**
 * /reactionrole — Create a reaction-based role assignment.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embed');
const Guild = require('../../models/Guild');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reactionrole')
    .setDescription('Create a reaction role assignment.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand(sub => sub
      .setName('add')
      .setDescription('Add a reaction role to a message')
      .addStringOption(o => o.setName('messageid').setDescription('Message ID').setRequired(true))
      .addStringOption(o => o.setName('emoji').setDescription('Emoji to react with').setRequired(true))
      .addRoleOption(o => o.setName('role').setDescription('Role to assign').setRequired(true))
      .addChannelOption(o => o.setName('channel').setDescription('Channel the message is in').setRequired(false)))
    .addSubcommand(sub => sub
      .setName('remove')
      .setDescription('Remove a reaction role')
      .addStringOption(o => o.setName('messageid').setDescription('Message ID').setRequired(true))
      .addStringOption(o => o.setName('emoji').setDescription('Emoji').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('list')
      .setDescription('List all reaction roles')),

  userPermissions: ['ManageRoles'],
  botPermissions:  ['ManageRoles', 'AddReactions'],
  guildOnly: true,
  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();

    let guildDoc = await Guild.findOneAndUpdate(
      { guildId: interaction.guild.id },
      {},
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    if (sub === 'add') {
      const messageId = interaction.options.getString('messageid');
      const emoji     = interaction.options.getString('emoji');
      const role      = interaction.options.getRole('role');
      const channel   = interaction.options.getChannel('channel') || interaction.channel;

      const msg = await channel.messages.fetch(messageId).catch(() => null);
      if (!msg) return interaction.editReply({ embeds: [errorEmbed('Error', 'Message not found. Make sure the message ID and channel are correct.')] });

      // React to the message
      await msg.react(emoji).catch(() => {
        return interaction.editReply({ embeds: [errorEmbed('Error', 'Could not react with that emoji. Make sure I have access to it.')] });
      });

      // Save to DB
      guildDoc.reactionRoles = guildDoc.reactionRoles || [];
      guildDoc.reactionRoles.push({
        messageId,
        channelId: channel.id,
        emoji,
        roleId: role.id,
      });
      await guildDoc.save();

      return interaction.editReply({ embeds: [successEmbed('Reaction Role Added', `Reacting with ${emoji} on that message will assign ${role}.`)] });
    }

    if (sub === 'remove') {
      const messageId = interaction.options.getString('messageid');
      const emoji     = interaction.options.getString('emoji');

      guildDoc.reactionRoles = (guildDoc.reactionRoles || []).filter(
        r => !(r.messageId === messageId && r.emoji === emoji)
      );
      await guildDoc.save();

      return interaction.editReply({ embeds: [successEmbed('Removed', 'Reaction role removed.')] });
    }

    if (sub === 'list') {
      const rr = guildDoc.reactionRoles || [];
      if (!rr.length) return interaction.editReply({ embeds: [infoEmbed('Reaction Roles', 'No reaction roles configured.')] });

      const fields = rr.slice(0, 10).map(r => ({
        name: `${r.emoji} in <#${r.channelId}>`,
        value: `Message: \`${r.messageId}\`\nRole: <@&${r.roleId}>`,
        inline: true,
      }));

      return interaction.editReply({ embeds: [infoEmbed('Reaction Roles', `${rr.length} reaction role(s) configured.`, fields)] });
    }
  },
};

/**
 * Handle reaction role add/remove — called from messageReactionAdd/Remove events.
 * Export for use in event files.
 */
async function handleReactionRole(reaction, user, add) {
  if (user.bot) return;
  if (!reaction.message.guild) return;

  const guildDoc = await Guild.findOne({ guildId: reaction.message.guild.id });
  if (!guildDoc?.reactionRoles?.length) return;

  const rr = guildDoc.reactionRoles.find(r =>
    r.messageId === reaction.message.id && r.emoji === (reaction.emoji.id || reaction.emoji.name)
  );
  if (!rr) return;

  const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
  if (!member) return;

  const role = reaction.message.guild.roles.cache.get(rr.roleId);
  if (!role) return;

  if (add) {
    await member.roles.add(role).catch(() => {});
  } else {
    await member.roles.remove(role).catch(() => {});
  }
}

module.exports.handleReactionRole = handleReactionRole;
