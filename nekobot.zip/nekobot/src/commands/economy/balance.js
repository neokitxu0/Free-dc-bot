/**
 * /balance — View your or another user's balance.
 */

const { SlashCommandBuilder } = require('discord.js');
const { economyEmbed } = require('../../utils/embed');
const { getEconomy } = require('../../utils/economy');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription("Check your or another user's wallet and bank balance.")
    .addUserOption(o => o.setName('user').setDescription('User to check (default: yourself)').setRequired(false)),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    const target = interaction.options.getUser('user') || interaction.user;
    const doc = await getEconomy(target.id, interaction.guild.id);

    const total = doc.wallet + doc.bank;

    return interaction.editReply({
      embeds: [economyEmbed(`${target.username}'s Balance`, `Here's the current balance breakdown:`, [
        { name: `${config.emojis.coin} Wallet`, value: `**${doc.wallet.toLocaleString()}** ${config.economy.currencyName}`, inline: true },
        { name: '🏦 Bank', value: `**${doc.bank.toLocaleString()}** / **${doc.bankLimit.toLocaleString()}** ${config.economy.currencyName}`, inline: true },
        { name: '💎 Total', value: `**${total.toLocaleString()}** ${config.economy.currencyName}`, inline: true },
      ]).setThumbnail(target.displayAvatarURL({ dynamic: true }))],
    });
  },
};
