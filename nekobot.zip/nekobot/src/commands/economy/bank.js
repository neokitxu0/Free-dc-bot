/**
 * /bank — Deposit, withdraw, or view bank info.
 */

const { SlashCommandBuilder } = require('discord.js');
const { economyEmbed, errorEmbed, successEmbed } = require('../../utils/embed');
const { getEconomy, deposit, withdraw } = require('../../utils/economy');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('bank')
    .setDescription('Manage your bank account.')
    .addSubcommand(sub => sub
      .setName('deposit')
      .setDescription('Deposit coins from wallet to bank')
      .addStringOption(o => o.setName('amount').setDescription('Amount or "all"').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('withdraw')
      .setDescription('Withdraw coins from bank to wallet')
      .addStringOption(o => o.setName('amount').setDescription('Amount or "all"').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('balance')
      .setDescription('View your bank balance')),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    if (sub === 'balance') {
      const doc = await getEconomy(interaction.user.id, interaction.guild.id);
      return interaction.editReply({
        embeds: [economyEmbed('Bank Account', '', [
          { name: '💰 Wallet', value: `${doc.wallet.toLocaleString()} ${config.emojis.coin}`, inline: true },
          { name: '🏦 Bank', value: `${doc.bank.toLocaleString()} ${config.emojis.coin}`, inline: true },
          { name: '📈 Capacity', value: `${doc.bankLimit.toLocaleString()} ${config.emojis.coin}`, inline: true },
        ])],
      });
    }

    const doc = await getEconomy(interaction.user.id, interaction.guild.id);
    const rawAmount = interaction.options.getString('amount');
    let amount;

    if (rawAmount.toLowerCase() === 'all') {
      amount = sub === 'deposit' ? doc.wallet : doc.bank;
    } else {
      amount = parseInt(rawAmount.replace(/,/g, ''), 10);
      if (isNaN(amount) || amount <= 0) {
        return interaction.editReply({ embeds: [errorEmbed('Invalid Amount', 'Please provide a valid positive amount or "all".')] });
      }
    }

    if (sub === 'deposit') {
      const result = await deposit(interaction.user.id, interaction.guild.id, amount);
      if (!result.success) return interaction.editReply({ embeds: [errorEmbed('Failed', result.reason)] });
      return interaction.editReply({
        embeds: [successEmbed('Deposited', `Deposited **${result.amount.toLocaleString()} ${config.emojis.coin}** into your bank.`)],
      });
    }

    if (sub === 'withdraw') {
      const result = await withdraw(interaction.user.id, interaction.guild.id, amount);
      if (!result.success) return interaction.editReply({ embeds: [errorEmbed('Failed', result.reason)] });
      return interaction.editReply({
        embeds: [successEmbed('Withdrawn', `Withdrew **${result.amount.toLocaleString()} ${config.emojis.coin}** from your bank.`)],
      });
    }
  },
};
