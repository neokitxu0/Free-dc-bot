/**
 * /beg — Beg for a small amount of coins.
 */

const { SlashCommandBuilder } = require('discord.js');
const { economyEmbed, errorEmbed } = require('../../utils/embed');
const { getEconomy, addCoins, checkCooldown, setCooldown, formatDuration, randInt } = require('../../utils/economy');
const config = require('../../../config');

const responses = [
  'A kind stranger gave you some coins! 🤗',
  'You found a few coins on the ground. 💰',
  'Someone felt sorry for you and tossed you some change. 😅',
  'You played your guitar on the street and people donated! 🎸',
  'A rich person walked by and tossed you some coins. 🎩',
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('beg')
    .setDescription('Beg for a small amount of coins.'),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    const doc = await getEconomy(interaction.user.id, interaction.guild.id);
    const remaining = checkCooldown(doc, 'beg');

    if (remaining > 0) {
      return interaction.editReply({
        embeds: [errorEmbed('Cooldown', `You begged too recently! Wait **${formatDuration(remaining)}**.`)],
      });
    }

    const earned = randInt(config.economy.beg.min, config.economy.beg.max);
    await setCooldown(interaction.user.id, interaction.guild.id, 'beg');
    await addCoins(interaction.user.id, interaction.guild.id, earned);

    const response = responses[Math.floor(Math.random() * responses.length)];

    return interaction.editReply({
      embeds: [economyEmbed('You Begged!', `${response}\n\nYou received **${earned} ${config.emojis.coin}**.`)],
    });
  },
};
