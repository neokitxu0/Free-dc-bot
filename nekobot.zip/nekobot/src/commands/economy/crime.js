/**
 * /crime — Commit a crime for a chance at big rewards (or failure).
 */

const { SlashCommandBuilder } = require('discord.js');
const { economyEmbed, errorEmbed } = require('../../utils/embed');
const { getEconomy, addCoins, removeCoins, checkCooldown, setCooldown, formatDuration, randInt } = require('../../utils/economy');
const config = require('../../../config');

const successScenarios = [
  'You hacked into a corporate server and transferred funds. 💻',
  'You pulled off a slick bank heist! 🏦',
  'You forged some documents and sold them. 📄',
  'You pickpocketed a rich tourist. 💼',
  'You ran an underground gambling ring. 🎰',
];
const failScenarios = [
  'You got caught by the police and paid a fine! 🚔',
  'Your heist plan fell apart and you lost money. 💸',
  'You tripped an alarm system and had to run! 🚨',
  'Your partner ratted you out. You paid bail. 🚓',
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('crime')
    .setDescription('Commit a crime for big rewards — but risk getting caught!'),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    const doc = await getEconomy(interaction.user.id, interaction.guild.id);
    const remaining = checkCooldown(doc, 'crime');

    if (remaining > 0) {
      return interaction.editReply({
        embeds: [errorEmbed('Cooling Down', `Lay low for **${formatDuration(remaining)}** before committing another crime.`)],
      });
    }

    await setCooldown(interaction.user.id, interaction.guild.id, 'crime');

    const failed = Math.random() < config.economy.crime.failChance;

    if (failed) {
      const fine = randInt(50, 300);
      await removeCoins(interaction.user.id, interaction.guild.id, fine);
      const scenario = failScenarios[Math.floor(Math.random() * failScenarios.length)];
      return interaction.editReply({
        embeds: [errorEmbed('Crime Failed!', `${scenario}\n\nYou were fined **${fine.toLocaleString()} ${config.emojis.coin}**.`)],
      });
    }

    const earned = randInt(config.economy.crime.min, config.economy.crime.max);
    await addCoins(interaction.user.id, interaction.guild.id, earned);
    const scenario = successScenarios[Math.floor(Math.random() * successScenarios.length)];

    return interaction.editReply({
      embeds: [economyEmbed('Crime Successful!', `${scenario}\n\nYou earned **${earned.toLocaleString()} ${config.emojis.coin}**!`)],
    });
  },
};
