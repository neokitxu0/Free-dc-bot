/**
 * /daily — Claim your daily coins reward.
 */

const { SlashCommandBuilder } = require('discord.js');
const { economyEmbed, errorEmbed } = require('../../utils/embed');
const { getEconomy, addCoins, checkCooldown, setCooldown, formatDuration, randInt } = require('../../utils/economy');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Claim your daily coins reward.'),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    const doc = await getEconomy(interaction.user.id, interaction.guild.id);
    const remaining = checkCooldown(doc, 'daily');

    if (remaining > 0) {
      return interaction.editReply({
        embeds: [errorEmbed('Cooldown', `You already claimed your daily reward! Come back in **${formatDuration(remaining)}**.`)],
      });
    }

    // Streak bonus
    const lastDaily = doc.cooldowns.daily || 0;
    const hoursSince = (Date.now() - lastDaily) / 3_600_000;
    const streakReset = hoursSince > 48;

    if (streakReset) doc.streaks.daily = 0;
    doc.streaks.daily = (doc.streaks.daily || 0) + 1;

    const base = randInt(config.economy.daily.min, config.economy.daily.max);
    const streakBonus = Math.floor(base * (doc.streaks.daily - 1) * 0.1);
    const total = base + streakBonus;

    await setCooldown(interaction.user.id, interaction.guild.id, 'daily');
    await addCoins(interaction.user.id, interaction.guild.id, total);

    const updated = await getEconomy(interaction.user.id, interaction.guild.id);

    return interaction.editReply({
      embeds: [economyEmbed('Daily Reward Claimed!', `You received **${total.toLocaleString()} ${config.emojis.coin}**!`, [
        { name: '🔥 Streak',      value: `${doc.streaks.daily} day${doc.streaks.daily !== 1 ? 's' : ''}`, inline: true },
        { name: '💵 Base Reward', value: `${base.toLocaleString()} ${config.emojis.coin}`, inline: true },
        { name: '🎁 Streak Bonus', value: `+${streakBonus.toLocaleString()} ${config.emojis.coin}`, inline: true },
        { name: '💰 New Wallet Balance', value: `${updated.wallet.toLocaleString()} ${config.emojis.coin}`, inline: false },
      ])],
    });
  },
};
