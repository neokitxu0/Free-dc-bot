/**
 * /inventory — View your item inventory.
 */

const { SlashCommandBuilder } = require('discord.js');
const { economyEmbed, errorEmbed } = require('../../utils/embed');
const { getEconomy } = require('../../utils/economy');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('inventory')
    .setDescription('View your item inventory.')
    .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)),

  guildOnly: true,
  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply();
    const target = interaction.options.getUser('user') || interaction.user;
    const doc = await getEconomy(target.id, interaction.guild.id);

    if (!doc.inventory.length) {
      return interaction.editReply({
        embeds: [errorEmbed('Empty Inventory', `${target.username} doesn't have any items yet. Buy from \`/shop\`!`)],
      });
    }

    const fields = doc.inventory.map(item => ({
      name: item.name,
      value: `**Quantity:** ${item.quantity}\n**Acquired:** <t:${Math.floor(new Date(item.acquiredAt).getTime() / 1000)}:R>`,
      inline: true,
    }));

    return interaction.editReply({
      embeds: [economyEmbed(`${target.username}'s Inventory`, `${doc.inventory.length} item type(s)`, fields)
        .setThumbnail(target.displayAvatarURL({ dynamic: true }))],
    });
  },
};
