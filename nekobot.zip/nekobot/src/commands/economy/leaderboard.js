/**
 * /leaderboard economy — Top richest users in this server.
 */

const { SlashCommandBuilder } = require('discord.js');
const { economyEmbed, errorEmbed } = require('../../utils/embed');
const { getLeaderboard } = require('../../utils/economy');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('richest')
    .setDescription('View the richest users in this server.'),

  guildOnly: true,
  cooldown: 10,

  async execute(client, interaction) {
    await interaction.deferReply();

    const top = await getLeaderboard(interaction.guild.id, 10);

    if (!top.length) {
      return interaction.editReply({ embeds: [errorEmbed('No Data', 'No economy data for this server yet.')] });
    }

    const medals = ['🥇', '🥈', '🥉'];
    const rows = await Promise.all(top.map(async (doc, i) => {
      const user = await client.users.fetch(doc.userId).catch(() => null);
      const name = user?.username || 'Unknown';
      const medal = medals[i] || `**${i + 1}.**`;
      return `${medal} **${name}** — ${(doc.wallet + doc.bank).toLocaleString()} ${config.emojis.coin}`;
    }));

    return interaction.editReply({
      embeds: [economyEmbed(
        `💰 ${interaction.guild.name} — Economy Leaderboard`,
        rows.join('\n'),
      ).setThumbnail(interaction.guild.iconURL({ dynamic: true }))],
    });
  },
};
