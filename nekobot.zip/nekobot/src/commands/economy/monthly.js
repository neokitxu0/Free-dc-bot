/**
 * /monthly — Claim your monthly coins reward.
 */

const { SlashCommandBuilder } = require('discord.js');
const { economyEmbed, errorEmbed } = require('../../utils/embed');
const { getEconomy, addCoins, checkCooldown, setCooldown, formatDuration, randInt } = require('../../utils/economy');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('monthly')
    .setDescription('Claim your monthly coins reward.'),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    const doc = await getEconomy(interaction.user.id, interaction.guild.id);
    const remaining = checkCooldown(doc, 'monthly');

    if (remaining > 0) {
      return interaction.editReply({
        embeds: [errorEmbed('Cooldown', `Your monthly reward resets in **${formatDuration(remaining)}**.`)],
      });
    }

    const earned = randInt(config.economy.monthly.min, config.economy.monthly.max);
    await setCooldown(interaction.user.id, interaction.guild.id, 'monthly');
    await addCoins(interaction.user.id, interaction.guild.id, earned);

    return interaction.editReply({
      embeds: [economyEmbed('Monthly Reward Claimed! 🎉', `You received **${earned.toLocaleString()} ${config.emojis.coin}**! See you next month!`)],
    });
  },
};
