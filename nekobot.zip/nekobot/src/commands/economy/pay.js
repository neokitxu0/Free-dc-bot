/**
 * /pay — Transfer coins to another user.
 */

const { SlashCommandBuilder } = require('discord.js');
const { economyEmbed, errorEmbed } = require('../../utils/embed');
const { getEconomy, transferCoins } = require('../../utils/economy');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pay')
    .setDescription('Pay another user some coins.')
    .addUserOption(o => o.setName('user').setDescription('User to pay').setRequired(true))
    .addIntegerOption(o => o.setName('amount').setDescription('Amount to pay').setMinValue(1).setRequired(true)),

  guildOnly: true,
  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply();

    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');

    if (target.id === interaction.user.id) return interaction.editReply({ embeds: [errorEmbed('Error', "You can't pay yourself!")] });
    if (target.bot) return interaction.editReply({ embeds: [errorEmbed('Error', "You can't pay a bot!")] });

    const success = await transferCoins(interaction.user.id, target.id, interaction.guild.id, amount);

    if (!success) {
      const doc = await getEconomy(interaction.user.id, interaction.guild.id);
      return interaction.editReply({
        embeds: [errorEmbed('Insufficient Funds', `You only have **${doc.wallet.toLocaleString()} ${config.emojis.coin}** in your wallet.`)],
      });
    }

    return interaction.editReply({
      embeds: [economyEmbed('Payment Sent!', `Successfully paid **${amount.toLocaleString()} ${config.emojis.coin}** to ${target}.`)],
    });
  },
};
