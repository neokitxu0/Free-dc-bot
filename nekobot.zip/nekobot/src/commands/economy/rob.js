/**
 * /rob — Attempt to rob another user's wallet.
 */

const { SlashCommandBuilder } = require('discord.js');
const { economyEmbed, errorEmbed } = require('../../utils/embed');
const { getEconomy, addCoins, removeCoins, checkCooldown, setCooldown, formatDuration, randInt } = require('../../utils/economy');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rob')
    .setDescription("Attempt to rob another user's wallet.")
    .addUserOption(o => o.setName('user').setDescription('User to rob').setRequired(true)),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    const target = interaction.options.getUser('user');
    if (target.id === interaction.user.id) {
      return interaction.editReply({ embeds: [errorEmbed('Error', "You can't rob yourself!")] });
    }
    if (target.bot) {
      return interaction.editReply({ embeds: [errorEmbed('Error', "You can't rob a bot!")] });
    }

    const robberDoc = await getEconomy(interaction.user.id, interaction.guild.id);
    const remaining = checkCooldown(robberDoc, 'rob');

    if (remaining > 0) {
      return interaction.editReply({
        embeds: [errorEmbed('Cooldown', `Wait **${formatDuration(remaining)}** before robbing again.`)],
      });
    }

    const targetDoc = await getEconomy(target.id, interaction.guild.id);

    if (targetDoc.wallet < config.economy.rob.minBal) {
      return interaction.editReply({
        embeds: [errorEmbed('Too Poor', `${target.username} doesn't have enough coins in their wallet to rob (minimum: ${config.economy.rob.minBal} ${config.emojis.coin}).`)],
      });
    }

    await setCooldown(interaction.user.id, interaction.guild.id, 'rob');

    const failed = Math.random() < config.economy.rob.failChance;

    if (failed) {
      const fine = randInt(50, 250);
      await removeCoins(interaction.user.id, interaction.guild.id, fine);
      await addCoins(target.id, interaction.guild.id, fine);
      return interaction.editReply({
        embeds: [errorEmbed('Rob Failed!', `You got caught trying to rob ${target.username}!\nYou paid **${fine.toLocaleString()} ${config.emojis.coin}** as a fine.`)],
      });
    }

    const stolen = Math.floor(targetDoc.wallet * (Math.random() * 0.3 + 0.1));
    await removeCoins(target.id, interaction.guild.id, stolen);
    await addCoins(interaction.user.id, interaction.guild.id, stolen);

    return interaction.editReply({
      embeds: [economyEmbed('Rob Successful!', `You successfully robbed **${stolen.toLocaleString()} ${config.emojis.coin}** from ${target.username}!`)],
    });
  },
};
