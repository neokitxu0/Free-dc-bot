/**
 * /shop — Browse and buy items from the server shop.
 */

const {
  SlashCommandBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder,
  ActionRowBuilder,
} = require('discord.js');
const { economyEmbed, errorEmbed, successEmbed } = require('../../utils/embed');
const { getEconomy, removeCoins } = require('../../utils/economy');
const Economy = require('../../models/Economy');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shop')
    .setDescription('Browse the server shop.'),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    const items = config.economy.shopItems;

    const fields = items.map(item => ({
      name: item.name,
      value: `${item.description}\n**Price:** ${item.price.toLocaleString()} ${config.emojis.coin}`,
      inline: true,
    }));

    const menu = new StringSelectMenuBuilder()
      .setCustomId('shop_buy')
      .setPlaceholder('Select an item to buy...')
      .addOptions(items.map(item =>
        new StringSelectMenuOptionBuilder()
          .setLabel(item.name)
          .setValue(item.id)
          .setDescription(`${item.price.toLocaleString()} ${config.emojis.coin}`)
      ));

    const row = new ActionRowBuilder().addComponents(menu);

    return interaction.editReply({
      embeds: [economyEmbed('🛒 Server Shop', 'Select an item below to purchase it.', fields)],
      components: [row],
    });
  },
};

// Called by selectMenuHandler
async function handleShopSelect(client, interaction) {
  await interaction.deferReply({ ephemeral: true });

  const itemId = interaction.values[0];
  const item   = config.economy.shopItems.find(i => i.id === itemId);
  if (!item) return interaction.editReply({ content: 'Item not found.' });

  const doc = await getEconomy(interaction.user.id, interaction.guild.id);
  if (doc.wallet < item.price) {
    return interaction.editReply({
      embeds: [errorEmbed('Insufficient Funds', `You need **${item.price.toLocaleString()} ${config.emojis.coin}** to buy this item.`)],
    });
  }

  // Check if already owned
  const already = doc.inventory.find(i => i.itemId === item.id);
  if (already) {
    already.quantity++;
  } else {
    doc.inventory.push({ itemId: item.id, name: item.name, quantity: 1 });
  }

  await removeCoins(interaction.user.id, interaction.guild.id, item.price);
  await Economy.findOneAndUpdate(
    { userId: interaction.user.id, guildId: interaction.guild.id },
    { $set: { inventory: doc.inventory } }
  );

  return interaction.editReply({
    embeds: [successEmbed('Item Purchased!', `You bought **${item.name}** for **${item.price.toLocaleString()} ${config.emojis.coin}**!`)],
  });
}

module.exports.handleShopSelect = handleShopSelect;
