/**
 * /weekly — Claim your weekly coins reward.
 */

const { SlashCommandBuilder } = require('discord.js');
const { economyEmbed, errorEmbed } = require('../../utils/embed');
const { getEconomy, addCoins, checkCooldown, setCooldown, formatDuration, randInt } = require('../../utils/economy');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('weekly')
    .setDescription('Claim your weekly coins reward.'),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    const doc = await getEconomy(interaction.user.id, interaction.guild.id);
    const remaining = checkCooldown(doc, 'weekly');

    if (remaining > 0) {
      return interaction.editReply({
        embeds: [errorEmbed('Cooldown', `Your weekly reward resets in **${formatDuration(remaining)}**.`)],
      });
    }

    const earned = randInt(config.economy.weekly.min, config.economy.weekly.max);
    await setCooldown(interaction.user.id, interaction.guild.id, 'weekly');
    await addCoins(interaction.user.id, interaction.guild.id, earned);

    return interaction.editReply({
      embeds: [economyEmbed('Weekly Reward Claimed!', `You received **${earned.toLocaleString()} ${config.emojis.coin}**! Come back next week!`)],
    });
  },
};
