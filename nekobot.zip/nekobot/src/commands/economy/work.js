/**
 * /work — Work to earn coins.
 */

const { SlashCommandBuilder } = require('discord.js');
const { economyEmbed, errorEmbed } = require('../../utils/embed');
const { getEconomy, addCoins, checkCooldown, setCooldown, formatDuration, randInt } = require('../../utils/economy');
const config = require('../../../config');

const jobs = [
  'You worked as a 🧑‍💻 developer and fixed some bugs.',
  'You worked as a 🍕 pizza delivery person.',
  'You worked as a 🎵 musician and played at a local café.',
  'You worked as a 🏋️ gym trainer and coached 5 clients.',
  'You worked as a 👨‍🍳 chef and cooked amazing meals.',
  'You worked as a 🚗 Uber driver and ferried people around.',
  'You worked as a 📦 package delivery driver.',
  'You taught an online class as a 📚 teacher.',
  'You sold handmade crafts as a 🎨 artist.',
  'You wrote articles as a ✍️ freelance writer.',
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('work')
    .setDescription('Work to earn some coins.'),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    const doc = await getEconomy(interaction.user.id, interaction.guild.id);
    const remaining = checkCooldown(doc, 'work');

    if (remaining > 0) {
      return interaction.editReply({
        embeds: [errorEmbed('Cooldown', `You're tired from working! Rest for **${formatDuration(remaining)}**.`)],
      });
    }

    const earned = randInt(config.economy.work.min, config.economy.work.max);
    await setCooldown(interaction.user.id, interaction.guild.id, 'work');
    await addCoins(interaction.user.id, interaction.guild.id, earned);

    const job = jobs[Math.floor(Math.random() * jobs.length)];

    return interaction.editReply({
      embeds: [economyEmbed('Work Complete!', `${job}\n\nYou earned **${earned.toLocaleString()} ${config.emojis.coin}**!`)],
    });
  },
};
