/**
 * /avatar — Get a user's avatar in full resolution.
 */

const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription("Get a user's avatar in full resolution.")
    .addUserOption(o => o.setName('user').setDescription('User (defaults to yourself)').setRequired(false)),

  cooldown: 3,

  async execute(client, interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const member = interaction.guild?.members.cache.get(user.id);

    const globalAv = user.displayAvatarURL({ dynamic: true, size: 4096 });
    const serverAv = member?.displayAvatarURL({ dynamic: true, size: 4096 });

    const embed = baseEmbed('primary')
      .setTitle(`${user.username}'s Avatar`)
      .setImage(serverAv || globalAv);

    if (serverAv && serverAv !== globalAv) {
      embed.setDescription(`[Global Avatar](${globalAv}) | [Server Avatar](${serverAv})`);
    } else {
      embed.setDescription(`[Download](${globalAv})`);
    }

    return interaction.reply({ embeds: [embed] });
  },
};
