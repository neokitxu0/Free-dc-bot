/**
 * /banner — Get a user's profile banner.
 */

const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('banner')
    .setDescription("Get a user's profile banner.")
    .addUserOption(o => o.setName('user').setDescription('User (defaults to yourself)').setRequired(false)),

  cooldown: 3,

  async execute(client, interaction) {
    const user = await client.users.fetch(
      interaction.options.getUser('user')?.id || interaction.user.id,
      { force: true }
    );

    const bannerUrl = user.bannerURL({ dynamic: true, size: 4096 });

    if (!bannerUrl) {
      return interaction.reply({
        embeds: [errorEmbed('No Banner', `${user.username} does not have a profile banner.`)],
      });
    }

    const embed = baseEmbed('primary')
      .setTitle(`${user.username}'s Banner`)
      .setImage(bannerUrl)
      .setDescription(`[Download](${bannerUrl})`);

    return interaction.reply({ embeds: [embed] });
  },
};
