/**
 * /calculator — Evaluate a math expression safely.
 */

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed, errorEmbed } = require('../../utils/embed');

// Safe expression evaluator (no eval)
function safeEval(expression) {
  const sanitized = expression.replace(/[^0-9+\-*/().%\s^]/g, '');
  if (!sanitized.trim()) throw new Error('Invalid expression');
  // Use Function constructor in a restricted manner
  return Function(`"use strict"; return (${sanitized.replace(/\^/g, '**')})`)();
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('calculator')
    .setDescription('Evaluate a math expression.')
    .addStringOption(o => o.setName('expression').setDescription('Math expression (e.g. 2+2*5)').setRequired(true)),

  cooldown: 3,

  async execute(client, interaction) {
    const expression = interaction.options.getString('expression');

    try {
      const result = safeEval(expression);

      if (typeof result !== 'number' || !isFinite(result)) throw new Error('Result is not a finite number');

      return interaction.reply({
        embeds: [infoEmbed('🧮 Calculator', `**Input:** \`${expression}\`\n**Result:** \`${result}\``)],
      });
    } catch (err) {
      return interaction.reply({
        embeds: [errorEmbed('Invalid Expression', `Could not evaluate: \`${expression}\`\n\nUse standard math operators: + - * / ( ) ^ %`)],
        ephemeral: true,
      });
    }
  },
};
