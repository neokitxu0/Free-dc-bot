/**
 * /coinflip — Flip a coin, with optional betting.
 */

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed, errorEmbed, successEmbed } = require('../../utils/embed');
const { getEconomy, addCoins, removeCoins } = require('../../utils/economy');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('Flip a coin! Guess correctly to double your bet.')
    .addStringOption(o => o.setName('choice').setDescription('Heads or Tails').setRequired(true)
      .addChoices({ name: '🪙 Heads', value: 'heads' }, { name: '🪙 Tails', value: 'tails' }))
    .addIntegerOption(o => o.setName('bet').setDescription('Amount to bet (optional)').setMinValue(1).setRequired(false)),

  cooldown: 3,
  guildOnly: true,

  async execute(client, interaction) {
    await interaction.deferReply();

    const choice  = interaction.options.getString('choice');
    const bet     = interaction.options.getInteger('bet');
    const result  = Math.random() < 0.5 ? 'heads' : 'tails';
    const won     = choice === result;
    const emoji   = result === 'heads' ? '🪙 Heads' : '🪙 Tails';

    if (bet && interaction.guild) {
      const doc = await getEconomy(interaction.user.id, interaction.guild.id);
      if (bet > doc.wallet) {
        return interaction.editReply({ embeds: [errorEmbed('Insufficient Funds', `You only have **${doc.wallet.toLocaleString()} ${config.emojis.coin}**.`)] });
      }

      if (won) {
        await addCoins(interaction.user.id, interaction.guild.id, bet);
        return interaction.editReply({
          embeds: [successEmbed('You Won! 🎉', `The coin landed on **${emoji}**!\nYou guessed correctly and won **${bet.toLocaleString()} ${config.emojis.coin}**!`)],
        });
      } else {
        await removeCoins(interaction.user.id, interaction.guild.id, bet);
        return interaction.editReply({
          embeds: [errorEmbed('You Lost!', `The coin landed on **${emoji}**.\nYou guessed **${choice}** and lost **${bet.toLocaleString()} ${config.emojis.coin}**.`)],
        });
      }
    }

    return interaction.editReply({
      embeds: [infoEmbed('Coin Flip', `The coin landed on **${emoji}**!\nYou guessed **${choice}** — ${won ? '✅ Correct!' : '❌ Wrong!'}`)],
    });
  },
};
