/**
 * /iq — Check a user's "IQ" (fun random command).
 */

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('iq')
    .setDescription("Check a user's IQ score (for fun!).")
    .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)),

  cooldown: 5,

  async execute(client, interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    // Consistent result per user (seeded)
    const seed = [...user.id].reduce((a, c) => a + c.charCodeAt(0), 0);
    const iq   = ((seed * 31337) % 100) + 60; // 60–159

    let label;
    if (iq < 70)        label = '😴 Borderline';
    else if (iq < 90)   label = '🙂 Below Average';
    else if (iq < 110)  label = '👍 Average';
    else if (iq < 130)  label = '🧠 Above Average';
    else if (iq < 145)  label = '💡 Gifted';
    else                label = '🚀 Genius';

    // Add a pinch of randomness per-run
    const displayed = iq + Math.floor(Math.random() * 5 - 2);

    return interaction.reply({
      embeds: [infoEmbed(`🧠 IQ Test — ${user.username}`, `${user.username}'s IQ is **${displayed}**\n${label}`)
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))],
    });
  },
};
