/**
 * /joke — Get a random joke.
 */

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed, errorEmbed } = require('../../utils/embed');
const axios = require('axios');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('joke')
    .setDescription('Get a random joke.')
    .addStringOption(o => o.setName('category').setDescription('Category').setRequired(false)
      .addChoices(
        { name: 'Any', value: 'Any' },
        { name: 'Programming', value: 'Programming' },
        { name: 'Pun', value: 'Pun' },
        { name: 'Misc', value: 'Misc' },
        { name: 'Dark', value: 'Dark' },
      )),

  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply();

    const category = interaction.options.getString('category') || 'Any';
    const url = `https://v2.jokeapi.dev/joke/${category}?safe-mode`;

    try {
      const { data } = await axios.get(url, { timeout: 5000 });

      if (data.type === 'twopart') {
        return interaction.editReply({
          embeds: [infoEmbed('😂 Joke', `**${data.setup}**\n\n||${data.delivery}||`)],
        });
      } else {
        return interaction.editReply({
          embeds: [infoEmbed('😂 Joke', data.joke)],
        });
      }
    } catch {
      return interaction.editReply({ embeds: [errorEmbed('Error', 'Could not fetch a joke. Try again!')] });
    }
  },
};
