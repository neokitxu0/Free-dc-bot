/**
 * /meme — Get a random meme from Reddit.
 */

const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../../utils/embed');
const axios = require('axios');

const subreddits = ['memes', 'dankmemes', 'me_irl', 'funny', 'AdviceAnimals'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('meme')
    .setDescription('Get a random meme from Reddit.'),

  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply();

    const sub = subreddits[Math.floor(Math.random() * subreddits.length)];

    try {
      const { data } = await axios.get(`https://www.reddit.com/r/${sub}/hot.json?limit=50`, {
        headers: { 'User-Agent': 'NekoBot/1.0' },
        timeout: 8000,
      });

      const posts = data.data.children.filter(p =>
        !p.data.over_18 && !p.data.stickied &&
        (p.data.url.endsWith('.jpg') || p.data.url.endsWith('.png') || p.data.url.endsWith('.gif'))
      );

      if (!posts.length) throw new Error('No valid posts');

      const post = posts[Math.floor(Math.random() * posts.length)].data;

      const embed = baseEmbed('fun')
        .setTitle(post.title.slice(0, 256))
        .setURL(`https://reddit.com${post.permalink}`)
        .setImage(post.url)
        .setFooter({ text: `👍 ${post.ups.toLocaleString()} | r/${sub}` });

      return interaction.editReply({ embeds: [embed] });
    } catch {
      return interaction.editReply({ embeds: [errorEmbed('Error', 'Could not fetch a meme. Try again later!')] });
    }
  },
};
