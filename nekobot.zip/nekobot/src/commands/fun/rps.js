/**
 * /rps — Play Rock, Paper, Scissors against the bot.
 */

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embed');

const choices = { rock: '🪨', paper: '📄', scissors: '✂️' };
const outcomes = {
  rock:     { rock: 'draw', paper: 'lose', scissors: 'win' },
  paper:    { rock: 'win', paper: 'draw', scissors: 'lose' },
  scissors: { rock: 'lose', paper: 'win', scissors: 'draw' },
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rps')
    .setDescription('Play Rock, Paper, Scissors against NekoBot!')
    .addStringOption(o => o.setName('choice').setDescription('Your choice').setRequired(true)
      .addChoices(
        { name: '🪨 Rock', value: 'rock' },
        { name: '📄 Paper', value: 'paper' },
        { name: '✂️ Scissors', value: 'scissors' },
      )),

  cooldown: 3,

  async execute(client, interaction) {
    const userChoice = interaction.options.getString('choice');
    const botChoice  = ['rock', 'paper', 'scissors'][Math.floor(Math.random() * 3)];
    const outcome    = outcomes[userChoice][botChoice];

    const resultText = {
      win:  '🎉 You win! I chose poorly.',
      lose: '😈 I win! Better luck next time.',
      draw: '🤝 It\'s a draw!',
    }[outcome];

    const color = outcome === 'win' ? 'success' : outcome === 'lose' ? 'error' : 'warning';

    const embed = require('../../utils/embed').baseEmbed(color)
      .setTitle('Rock Paper Scissors')
      .addFields(
        { name: 'Your choice', value: `${choices[userChoice]} ${userChoice}`, inline: true },
        { name: "NekoBot's choice", value: `${choices[botChoice]} ${botChoice}`, inline: true },
        { name: 'Result', value: resultText, inline: false },
      );

    return interaction.reply({ embeds: [embed] });
  },
};
