/**
 * /trivia — Answer a random trivia question.
 */

const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const { infoEmbed, successEmbed, errorEmbed } = require('../../utils/embed');
const axios = require('axios');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('trivia')
    .setDescription('Answer a random trivia question!')
    .addStringOption(o => o.setName('category').setDescription('Category').setRequired(false)
      .addChoices(
        { name: 'General Knowledge', value: '9' },
        { name: 'Science', value: '17' },
        { name: 'History', value: '23' },
        { name: 'Sports', value: '21' },
        { name: 'Geography', value: '22' },
        { name: 'Entertainment', value: '11' },
      )),

  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply();

    const category = interaction.options.getString('category') || '';
    const url = `https://opentdb.com/api.php?amount=1&type=multiple${category ? `&category=${category}` : ''}`;

    let question, correct, incorrect, allAnswers;

    try {
      const { data } = await axios.get(url, { timeout: 5000 });
      if (!data.results?.length) throw new Error('No results');
      const q = data.results[0];
      question  = q.question.replace(/&quot;/g, '"').replace(/&#039;/g, "'").replace(/&amp;/g, '&');
      correct   = q.correct_answer.replace(/&quot;/g, '"').replace(/&#039;/g, "'");
      incorrect = q.incorrect_answers.map(a => a.replace(/&quot;/g, '"').replace(/&#039;/g, "'"));
      allAnswers = [...incorrect, correct].sort(() => Math.random() - 0.5);
    } catch {
      return interaction.editReply({ embeds: [errorEmbed('API Error', 'Could not fetch a trivia question. Try again later!')] });
    }

    const letters = ['A', 'B', 'C', 'D'];
    const buttons = allAnswers.map((ans, i) =>
      new ButtonBuilder()
        .setCustomId(`trivia_${ans === correct ? 'correct' : 'wrong'}_${i}`)
        .setLabel(`${letters[i]}: ${ans.slice(0, 50)}`)
        .setStyle(ButtonStyle.Primary)
    );

    const row = new ActionRowBuilder().addComponents(buttons);

    await interaction.editReply({
      embeds: [infoEmbed('🧠 Trivia', question, [{ name: 'Options', value: allAnswers.map((a, i) => `**${letters[i]}:** ${a}`).join('\n') }])],
      components: [row],
    });

    const collector = interaction.channel.createMessageComponentCollector({
      filter: i => i.user.id === interaction.user.id && i.customId.startsWith('trivia_'),
      time: 30_000,
      max: 1,
    });

    collector.on('collect', async (btnInteraction) => {
      const isCorrect = btnInteraction.customId.startsWith('trivia_correct');
      await btnInteraction.update({
        embeds: [isCorrect
          ? successEmbed('Correct! 🎉', `The answer was **${correct}**! Well done!`)
          : errorEmbed('Wrong! ❌', `The correct answer was **${correct}**.`)],
        components: [],
      });
    });

    collector.on('end', async (_, reason) => {
      if (reason === 'time') {
        await interaction.editReply({
          embeds: [errorEmbed('Time Up!', `The correct answer was **${correct}**.`)],
          components: [],
        }).catch(() => {});
      }
    });
  },
};
