/**
 * /rank — Show a user's current rank and XP.
 */

const { SlashCommandBuilder } = require('discord.js');
const { errorEmbed } = require('../../utils/embed');
const { getRankEmbed } = require('../../utils/level');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription("View your or another user's rank and XP.")
    .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)),

  guildOnly: true,
  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply();

    const user = interaction.options.getUser('user') || interaction.user;
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);

    if (!member) {
      return interaction.editReply({ embeds: [errorEmbed('Not Found', 'That user is not in this server.')] });
    }

    const embed = await getRankEmbed(member, interaction.guild.id);
    return interaction.editReply({ embeds: [embed] });
  },
};
