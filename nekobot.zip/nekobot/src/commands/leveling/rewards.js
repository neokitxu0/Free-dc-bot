/**
 * /rewards — Manage level-up role rewards.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embed');
const Guild = require('../../models/Guild');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rewards')
    .setDescription('Manage level-up role rewards.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub
      .setName('add')
      .setDescription('Add a level reward')
      .addIntegerOption(o => o.setName('level').setDescription('Level required').setMinValue(1).setRequired(true))
      .addRoleOption(o => o.setName('role').setDescription('Role to grant').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('remove')
      .setDescription('Remove a level reward')
      .addIntegerOption(o => o.setName('level').setDescription('Level to remove reward from').setMinValue(1).setRequired(true)))
    .addSubcommand(sub => sub
      .setName('list')
      .setDescription('List all level rewards')),

  userPermissions: ['ManageGuild'],
  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    let guildDoc = await Guild.findOneAndUpdate(
      { guildId: interaction.guild.id },
      {},
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    if (sub === 'add') {
      const level = interaction.options.getInteger('level');
      const role  = interaction.options.getRole('role');

      guildDoc.roles.levelRoles = guildDoc.roles.levelRoles.filter(r => r.level !== level);
      guildDoc.roles.levelRoles.push({ level, roleId: role.id });
      await guildDoc.save();

      return interaction.editReply({
        embeds: [successEmbed('Reward Added', `At level **${level}**, members will receive ${role}.`)],
      });
    }

    if (sub === 'remove') {
      const level = interaction.options.getInteger('level');
      guildDoc.roles.levelRoles = guildDoc.roles.levelRoles.filter(r => r.level !== level);
      await guildDoc.save();
      return interaction.editReply({ embeds: [successEmbed('Reward Removed', `Removed reward for level **${level}**.`)] });
    }

    if (sub === 'list') {
      const rewards = guildDoc.roles.levelRoles.sort((a, b) => a.level - b.level);
      if (!rewards.length) return interaction.editReply({ embeds: [infoEmbed('No Rewards', 'No level rewards configured.')] });

      const fields = rewards.map(r => ({ name: `Level ${r.level}`, value: `<@&${r.roleId}>`, inline: true }));
      return interaction.editReply({ embeds: [infoEmbed('Level Rewards', 'Roles granted on level-up:', fields)] });
    }
  },
};
