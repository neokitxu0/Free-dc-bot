/**
 * /toplevel — View the server's level leaderboard.
 */

const { SlashCommandBuilder } = require('discord.js');
const { levelEmbed, errorEmbed } = require('../../utils/embed');
const { getLevelLeaderboard } = require('../../utils/level');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('toplevel')
    .setDescription('View the top leveled users in this server.'),

  guildOnly: true,
  cooldown: 10,

  async execute(client, interaction) {
    await interaction.deferReply();

    const top = await getLevelLeaderboard(interaction.guild.id, 10);
    if (!top.length) {
      return interaction.editReply({ embeds: [errorEmbed('No Data', 'No level data for this server yet.')] });
    }

    const medals = ['🥇', '🥈', '🥉'];
    const rows = await Promise.all(top.map(async (doc, i) => {
      const user = await client.users.fetch(doc.userId).catch(() => null);
      const name = user?.username || 'Unknown';
      return `${medals[i] || `**${i + 1}.**`} **${name}** — Level ${doc.level} (${doc.totalXp.toLocaleString()} XP)`;
    }));

    return interaction.editReply({
      embeds: [levelEmbed(`📈 ${interaction.guild.name} — Level Leaderboard`, rows.join('\n'))
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))],
    });
  },
};
