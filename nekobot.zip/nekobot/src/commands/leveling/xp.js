/**
 * /xp — Set or add XP to a user (admin only).
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const Level = require('../../models/Level');
const { xpForLevel } = require('../../utils/level');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('xp')
    .setDescription('Manage XP for users.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub
      .setName('add')
      .setDescription('Add XP to a user')
      .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
      .addIntegerOption(o => o.setName('amount').setDescription('XP to add').setMinValue(1).setRequired(true)))
    .addSubcommand(sub => sub
      .setName('set')
      .setDescription('Set a user\'s level')
      .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
      .addIntegerOption(o => o.setName('level').setDescription('Level to set').setMinValue(0).setRequired(true)))
    .addSubcommand(sub => sub
      .setName('reset')
      .setDescription('Reset a user\'s XP and level')
      .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))),

  userPermissions: ['ManageGuild'],
  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();
    const sub  = interaction.options.getSubcommand();
    const user = interaction.options.getUser('user');

    if (sub === 'add') {
      const amount = interaction.options.getInteger('amount');
      await Level.findOneAndUpdate(
        { userId: user.id, guildId: interaction.guild.id },
        { $inc: { xp: amount, totalXp: amount } },
        { upsert: true, new: true }
      );
      return interaction.editReply({ embeds: [successEmbed('XP Added', `Added **${amount} XP** to ${user}.`)] });
    }

    if (sub === 'set') {
      const level = interaction.options.getInteger('level');
      let totalXp = 0;
      for (let i = 0; i < level; i++) totalXp += xpForLevel(i);
      await Level.findOneAndUpdate(
        { userId: user.id, guildId: interaction.guild.id },
        { level, xp: 0, totalXp },
        { upsert: true }
      );
      return interaction.editReply({ embeds: [successEmbed('Level Set', `Set ${user}'s level to **${level}**.`)] });
    }

    if (sub === 'reset') {
      await Level.findOneAndUpdate(
        { userId: user.id, guildId: interaction.guild.id },
        { level: 0, xp: 0, totalXp: 0 }
      );
      return interaction.editReply({ embeds: [successEmbed('XP Reset', `Reset ${user}'s XP and level.`)] });
    }
  },
};
