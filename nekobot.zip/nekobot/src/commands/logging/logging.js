/**
 * /logging — Configure the comprehensive logging system.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, infoEmbed } = require('../../utils/embed');
const Guild = require('../../models/Guild');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('logging')
    .setDescription('Configure the server logging system.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub
      .setName('setup')
      .setDescription('Set a log channel for specific events')
      .addStringOption(o => o.setName('type').setDescription('Log type').setRequired(true)
        .addChoices(
          { name: 'Mod Log',      value: 'modLog' },
          { name: 'Message Log',  value: 'messageLog' },
          { name: 'Member Log',   value: 'memberLog' },
          { name: 'Voice Log',    value: 'voiceLog' },
          { name: 'Role Log',     value: 'roleLog' },
          { name: 'Channel Log',  value: 'channelLog' },
          { name: 'Ticket Log',   value: 'ticketLog' },
        ))
      .addChannelOption(o => o.setName('channel').setDescription('Log channel').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('toggle')
      .setDescription('Toggle a specific log event on/off')
      .addStringOption(o => o.setName('event').setDescription('Event to toggle').setRequired(true)
        .addChoices(
          { name: 'Message Delete', value: 'messageDelete' },
          { name: 'Message Edit',   value: 'messageEdit' },
          { name: 'Member Join',    value: 'memberJoin' },
          { name: 'Member Leave',   value: 'memberLeave' },
          { name: 'Voice State',    value: 'voiceState' },
          { name: 'Role Changes',   value: 'roleChanges' },
          { name: 'Channel Changes',value: 'channelChanges' },
          { name: 'Bans',           value: 'bans' },
        ))
      .addBooleanOption(o => o.setName('enabled').setDescription('Enable or disable').setRequired(true)))
    .addSubcommand(sub => sub.setName('status').setDescription('View current logging configuration')),

  userPermissions: ['ManageGuild'],
  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    let guildDoc = await Guild.findOneAndUpdate(
      { guildId: interaction.guild.id },
      {},
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    if (sub === 'setup') {
      const type    = interaction.options.getString('type');
      const channel = interaction.options.getChannel('channel');

      guildDoc.channels[type] = channel.id;
      await guildDoc.save();

      return interaction.editReply({
        embeds: [successEmbed('Log Channel Set', `**${type}** events will now be logged to ${channel}.`)],
      });
    }

    if (sub === 'toggle') {
      const event   = interaction.options.getString('event');
      const enabled = interaction.options.getBoolean('enabled');

      guildDoc.logging[event] = enabled;
      await guildDoc.save();

      return interaction.editReply({
        embeds: [successEmbed('Logging Updated', `**${event}** logging is now **${enabled ? 'enabled' : 'disabled'}**.`)],
      });
    }

    if (sub === 'status') {
      const s = (v) => v ? '✅' : '❌';
      const c = (id) => id ? `<#${id}>` : '❌ Not set';
      const log = guildDoc.logging;

      return interaction.editReply({
        embeds: [infoEmbed('Logging Status', '', [
          { name: 'Channels', value: [
            `📋 Mod Log: ${c(guildDoc.channels.modLog)}`,
            `💬 Message Log: ${c(guildDoc.channels.messageLog)}`,
            `👥 Member Log: ${c(guildDoc.channels.memberLog)}`,
            `🎙️ Voice Log: ${c(guildDoc.channels.voiceLog)}`,
            `🏷️ Role Log: ${c(guildDoc.channels.roleLog)}`,
            `📁 Channel Log: ${c(guildDoc.channels.channelLog)}`,
          ].join('\n'), inline: false },
          { name: 'Events', value: [
            `${s(log.messageDelete)} Message Delete`,
            `${s(log.messageEdit)} Message Edit`,
            `${s(log.memberJoin)} Member Join`,
            `${s(log.memberLeave)} Member Leave`,
            `${s(log.voiceState)} Voice State`,
            `${s(log.roleChanges)} Role Changes`,
            `${s(log.channelChanges)} Channel Changes`,
            `${s(log.bans)} Bans`,
          ].join('\n'), inline: false },
        ])],
      });
    }
  },
};
