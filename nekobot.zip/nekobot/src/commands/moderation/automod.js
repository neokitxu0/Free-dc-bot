/**
 * /automod — Configure the AutoMod system for this server.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embed');
const Guild = require('../../models/Guild');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('automod')
    .setDescription('Configure the AutoMod system.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub
      .setName('toggle')
      .setDescription('Enable or disable an AutoMod feature')
      .addStringOption(o => o.setName('feature').setDescription('Feature to toggle').setRequired(true)
        .addChoices(
          { name: 'Anti-Spam', value: 'antiSpam' },
          { name: 'Anti-Link', value: 'antiLink' },
          { name: 'Anti-Bad Words', value: 'antiBadWords' },
          { name: 'Anti-Raid', value: 'antiRaid' },
          { name: 'Anti-Mention Spam', value: 'antiMentionSpam' },
          { name: 'Anti-Bot', value: 'antiBot' },
          { name: 'Anti-Webhook', value: 'antiWebhook' },
        ))
      .addBooleanOption(o => o.setName('enabled').setDescription('Enable or disable').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('status')
      .setDescription('View current AutoMod settings'))
    .addSubcommand(sub => sub
      .setName('badword')
      .setDescription('Add or remove a bad word')
      .addStringOption(o => o.setName('action').setDescription('add/remove').setRequired(true)
        .addChoices({ name: 'Add', value: 'add' }, { name: 'Remove', value: 'remove' }))
      .addStringOption(o => o.setName('word').setDescription('Word to add/remove').setRequired(true))),

  userPermissions: ['ManageGuild'],
  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    let guildDoc = await Guild.findOneAndUpdate(
      { guildId: interaction.guild.id },
      {},
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    if (sub === 'toggle') {
      const feature = interaction.options.getString('feature');
      const enabled = interaction.options.getBoolean('enabled');

      guildDoc.automod[feature] = enabled;
      await guildDoc.save();

      return interaction.editReply({
        embeds: [successEmbed('AutoMod Updated', `**${feature}** has been ${enabled ? '✅ enabled' : '❌ disabled'}.`)],
      });
    }

    if (sub === 'status') {
      const am = guildDoc.automod;
      const status = (v) => v ? '✅' : '❌';

      return interaction.editReply({
        embeds: [infoEmbed('AutoMod Status', `AutoMod configuration for **${interaction.guild.name}**`, [
          { name: '🛡️ Anti-Spam',          value: status(am.antiSpam),        inline: true },
          { name: '🔗 Anti-Link',           value: status(am.antiLink),        inline: true },
          { name: '🤬 Anti-Bad Words',      value: status(am.antiBadWords),    inline: true },
          { name: '⚡ Anti-Raid',           value: status(am.antiRaid),        inline: true },
          { name: '💬 Anti-Mention Spam',   value: status(am.antiMentionSpam), inline: true },
          { name: '🤖 Anti-Bot',            value: status(am.antiBot),         inline: true },
          { name: '🪝 Anti-Webhook',        value: status(am.antiWebhook),     inline: true },
          { name: '📝 Bad Words Count',     value: `${am.badWords?.length || 0}`, inline: true },
        ])],
      });
    }

    if (sub === 'badword') {
      const action = interaction.options.getString('action');
      const word   = interaction.options.getString('word').toLowerCase();

      if (!guildDoc.automod.badWords) guildDoc.automod.badWords = [];

      if (action === 'add') {
        if (guildDoc.automod.badWords.includes(word)) {
          return interaction.editReply({ embeds: [errorEmbed('Already Exists', `\`${word}\` is already in the bad words list.`)] });
        }
        guildDoc.automod.badWords.push(word);
        await guildDoc.save();
        return interaction.editReply({ embeds: [successEmbed('Word Added', `Added \`${word}\` to the bad words list.`)] });
      }

      if (action === 'remove') {
        guildDoc.automod.badWords = guildDoc.automod.badWords.filter(w => w !== word);
        await guildDoc.save();
        return interaction.editReply({ embeds: [successEmbed('Word Removed', `Removed \`${word}\` from the bad words list.`)] });
      }
    }
  },
};
