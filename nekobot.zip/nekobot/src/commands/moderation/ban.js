/**
 * /ban — Ban a member from the server.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { modEmbed, errorEmbed, successEmbed } = require('../../utils/embed');
const { canModerate } = require('../../utils/permissions');
const { sendModLog } = require('../../utils/antiSpam');
const Warn = require('../../models/Warn');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server.')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName('user').setDescription('The user to ban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the ban').setRequired(false))
    .addIntegerOption(o => o.setName('days').setDescription('Days of messages to delete (0-7)').setMinValue(0).setMaxValue(7).setRequired(false)),

  userPermissions: ['BanMembers'],
  botPermissions:  ['BanMembers'],
  guildOnly: true,
  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply();

    const target  = interaction.options.getUser('user');
    const reason  = interaction.options.getString('reason') || 'No reason provided';
    const days    = interaction.options.getInteger('days') ?? 0;
    const member  = await interaction.guild.members.fetch(target.id).catch(() => null);

    // Self-ban check
    if (target.id === interaction.user.id) {
      return interaction.editReply({ embeds: [errorEmbed('Error', 'You cannot ban yourself.')] });
    }

    // Bot ban check
    if (target.id === client.user.id) {
      return interaction.editReply({ embeds: [errorEmbed('Error', 'I cannot ban myself.')] });
    }

    // Hierarchy check (only if member is in server)
    if (member) {
      if (!canModerate(interaction.member, member)) {
        return interaction.editReply({ embeds: [errorEmbed('Error', 'You cannot ban someone with a higher or equal role.')] });
      }
      if (!canModerate(interaction.guild.members.me, member)) {
        return interaction.editReply({ embeds: [errorEmbed('Error', 'I cannot ban this member — they have a higher role than me.')] });
      }
    }

    try {
      // DM the user before banning
      await target.send({
        embeds: [modEmbed({
          action: `You have been banned from ${interaction.guild.name}`,
          target,
          moderator: interaction.user,
          reason,
        })],
      }).catch(() => {});

      await interaction.guild.bans.create(target.id, {
        reason: `${interaction.user.tag} | ${reason}`,
        deleteMessageSeconds: days * 86400,
      });

      const embed = modEmbed({
        action: 'Member Banned',
        target,
        moderator: interaction.user,
        reason,
        guildIcon: interaction.guild.iconURL(),
      });

      await interaction.editReply({ embeds: [embed] });
      await sendModLog(interaction.guild, { action: 'Ban', target, punishment: 'ban' });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Error', `Failed to ban: ${err.message}`)] });
    }
  },
};
