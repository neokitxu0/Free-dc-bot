/**
 * /kick — Kick a member from the server.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { modEmbed, errorEmbed } = require('../../utils/embed');
const { canModerate } = require('../../utils/permissions');
const { sendModLog } = require('../../utils/antiSpam');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server.')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption(o => o.setName('user').setDescription('The user to kick').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the kick').setRequired(false)),

  userPermissions: ['KickMembers'],
  botPermissions:  ['KickMembers'],
  guildOnly: true,
  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply();

    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!target) return interaction.editReply({ embeds: [errorEmbed('Error', 'That user is not in this server.')] });
    if (target.id === interaction.user.id) return interaction.editReply({ embeds: [errorEmbed('Error', 'You cannot kick yourself.')] });
    if (target.id === client.user.id) return interaction.editReply({ embeds: [errorEmbed('Error', 'I cannot kick myself.')] });

    if (!canModerate(interaction.member, target)) {
      return interaction.editReply({ embeds: [errorEmbed('Error', 'You cannot kick someone with a higher or equal role.')] });
    }
    if (!canModerate(interaction.guild.members.me, target)) {
      return interaction.editReply({ embeds: [errorEmbed('Error', 'I cannot kick this member.')] });
    }

    try {
      await target.user.send({
        embeds: [modEmbed({ action: `You have been kicked from ${interaction.guild.name}`, target: target.user, moderator: interaction.user, reason })],
      }).catch(() => {});

      await target.kick(`${interaction.user.tag} | ${reason}`);
      await interaction.editReply({ embeds: [modEmbed({ action: 'Member Kicked', target: target.user, moderator: interaction.user, reason })] });
      await sendModLog(interaction.guild, { action: 'Kick', target: target.user, punishment: 'kick' });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Error', `Failed to kick: ${err.message}`)] });
    }
  },
};
