/**
 * /lock — Lock a channel so members cannot send messages.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Lock a channel, preventing members from sending messages.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption(o => o.setName('channel').setDescription('Channel to lock (defaults to current)').setRequired(false))
    .addStringOption(o => o.setName('reason').setDescription('Reason for locking').setRequired(false)),

  userPermissions: ['ManageChannels'],
  botPermissions:  ['ManageChannels'],
  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const reason  = interaction.options.getString('reason') || 'No reason provided';

    try {
      await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
        SendMessages: false,
      }, { reason: `Lock by ${interaction.user.tag} | ${reason}` });

      await interaction.editReply({
        embeds: [successEmbed('Channel Locked', `🔒 ${channel} has been locked.\n**Reason:** ${reason}`)],
      });

      if (channel.id !== interaction.channelId) {
        await channel.send({ embeds: [errorEmbed('🔒 Channel Locked', `This channel has been locked by ${interaction.user}.\n**Reason:** ${reason}`)] });
      }
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Error', `Could not lock channel: ${err.message}`)] });
    }
  },
};
