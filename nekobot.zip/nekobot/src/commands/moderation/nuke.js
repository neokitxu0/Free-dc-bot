/**
 * /nuke — Clone a channel and delete the original (nukes all messages).
 */

const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { warningEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nuke')
    .setDescription('Delete and recreate this channel, removing all messages.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption(o => o.setName('channel').setDescription('Channel to nuke (defaults to current)').setRequired(false)),

  userPermissions: ['ManageChannels'],
  botPermissions:  ['ManageChannels'],
  guildOnly: true,
  cooldown: 30,

  async execute(client, interaction) {
    const channel = interaction.options.getChannel('channel') || interaction.channel;

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`confirm_nuke_${channel.id}`)
        .setLabel('⚠️ Confirm Nuke')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('cancel_nuke')
        .setLabel('Cancel')
        .setStyle(ButtonStyle.Secondary),
    );

    await interaction.reply({
      embeds: [warningEmbed('Confirm Nuke', `Are you sure you want to nuke ${channel}? This will **permanently delete all messages**.`)],
      components: [row],
      ephemeral: true,
    });
  },
};
