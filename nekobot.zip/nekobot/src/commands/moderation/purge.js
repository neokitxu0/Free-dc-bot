/**
 * /purge — Bulk delete messages from a channel.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Bulk delete messages from this channel.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption(o => o.setName('amount').setDescription('Number of messages to delete (1-100)').setMinValue(1).setMaxValue(100).setRequired(true))
    .addUserOption(o => o.setName('user').setDescription('Only delete messages from this user').setRequired(false))
    .addStringOption(o => o.setName('filter').setDescription('Filter: bots | links | embeds').setRequired(false)
      .addChoices({ name: 'Bots only', value: 'bots' }, { name: 'Links only', value: 'links' }, { name: 'Embeds only', value: 'embeds' })),

  userPermissions: ['ManageMessages'],
  botPermissions:  ['ManageMessages'],
  guildOnly: true,
  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply({ ephemeral: true });

    const amount    = interaction.options.getInteger('amount');
    const targetUser = interaction.options.getUser('user');
    const filter    = interaction.options.getString('filter');

    let messages = await interaction.channel.messages.fetch({ limit: 100 });

    // Filter by user
    if (targetUser) messages = messages.filter(m => m.author.id === targetUser.id);

    // Apply content filters
    if (filter === 'bots')   messages = messages.filter(m => m.author.bot);
    if (filter === 'links')  messages = messages.filter(m => /(https?:\/\/)\S+/.test(m.content));
    if (filter === 'embeds') messages = messages.filter(m => m.embeds.length > 0);

    // Discord only allows bulk delete of messages <14 days old
    const twoWeeksAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
    messages = messages.filter(m => m.createdTimestamp > twoWeeksAgo);

    // Limit to requested amount
    const toDelete = [...messages.values()].slice(0, amount);

    if (toDelete.length === 0) {
      return interaction.editReply({ embeds: [errorEmbed('No Messages', 'No messages matching the criteria found (messages must be under 14 days old).')] });
    }

    const deleted = await interaction.channel.bulkDelete(toDelete, true).catch(() => null);

    const count = deleted?.size ?? toDelete.length;
    return interaction.editReply({
      embeds: [successEmbed('Messages Purged', `Successfully deleted **${count}** message${count !== 1 ? 's' : ''}.`)],
    });
  },
};
