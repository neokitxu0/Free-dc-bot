/**
 * /slowmode — Set or disable slowmode in a channel.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Set slowmode for a channel.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addIntegerOption(o => o.setName('seconds').setDescription('Slowmode delay in seconds (0 to disable)').setMinValue(0).setMaxValue(21600).setRequired(true))
    .addChannelOption(o => o.setName('channel').setDescription('Channel (defaults to current)').setRequired(false)),

  userPermissions: ['ManageChannels'],
  botPermissions:  ['ManageChannels'],
  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    const seconds = interaction.options.getInteger('seconds');
    const channel = interaction.options.getChannel('channel') || interaction.channel;

    try {
      await channel.setRateLimitPerUser(seconds, `Slowmode by ${interaction.user.tag}`);

      const msg = seconds === 0
        ? `Slowmode has been **disabled** in ${channel}.`
        : `Slowmode set to **${seconds} second${seconds !== 1 ? 's' : ''}** in ${channel}.`;

      await interaction.editReply({ embeds: [successEmbed('Slowmode Updated', msg)] });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Error', `Could not set slowmode: ${err.message}`)] });
    }
  },
};
