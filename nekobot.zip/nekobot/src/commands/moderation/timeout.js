/**
 * /timeout — Timeout (mute) a member for a duration.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { modEmbed, errorEmbed } = require('../../utils/embed');
const { canModerate } = require('../../utils/permissions');
const { sendModLog } = require('../../utils/antiSpam');
const ms = require('ms');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout a member for a specified duration.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('The user to timeout').setRequired(true))
    .addStringOption(o => o.setName('duration').setDescription('Duration (e.g. 10m, 1h, 1d)').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)),

  userPermissions: ['ModerateMembers'],
  botPermissions:  ['ModerateMembers'],
  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    const target   = interaction.options.getMember('user');
    const duration = interaction.options.getString('duration');
    const reason   = interaction.options.getString('reason') || 'No reason provided';

    if (!target) return interaction.editReply({ embeds: [errorEmbed('Error', 'User not found in this server.')] });

    const durationMs = ms(duration);
    if (!durationMs || durationMs < 5000 || durationMs > 2419200000) {
      return interaction.editReply({ embeds: [errorEmbed('Invalid Duration', 'Duration must be between 5s and 28d (e.g. `10m`, `1h`, `1d`).')] });
    }

    if (!canModerate(interaction.member, target)) {
      return interaction.editReply({ embeds: [errorEmbed('Error', 'You cannot timeout someone with a higher or equal role.')] });
    }

    try {
      await target.timeout(durationMs, `${interaction.user.tag} | ${reason}`);
      await interaction.editReply({
        embeds: [modEmbed({ action: 'Member Timed Out', target: target.user, moderator: interaction.user, reason, duration })],
      });
      await sendModLog(interaction.guild, { action: 'Timeout', target: target.user, punishment: `timeout (${duration})` });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Error', `Failed to timeout: ${err.message}`)] });
    }
  },
};
