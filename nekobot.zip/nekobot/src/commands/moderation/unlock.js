/**
 * /unlock — Unlock a previously locked channel.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Unlock a channel.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption(o => o.setName('channel').setDescription('Channel to unlock').setRequired(false))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)),

  userPermissions: ['ManageChannels'],
  botPermissions:  ['ManageChannels'],
  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const reason  = interaction.options.getString('reason') || 'No reason provided';

    try {
      await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
        SendMessages: null, // Reset to default
      }, { reason: `Unlock by ${interaction.user.tag} | ${reason}` });

      await interaction.editReply({ embeds: [successEmbed('Channel Unlocked', `🔓 ${channel} has been unlocked.\n**Reason:** ${reason}`)] });

      if (channel.id !== interaction.channelId) {
        await channel.send({ embeds: [successEmbed('🔓 Channel Unlocked', `This channel has been unlocked by ${interaction.user}.`)] });
      }
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Error', `Could not unlock channel: ${err.message}`)] });
    }
  },
};
