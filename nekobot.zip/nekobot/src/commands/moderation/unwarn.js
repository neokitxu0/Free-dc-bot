/**
 * /unwarn — Remove a specific warning from a user.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embed');
const Warn = require('../../models/Warn');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unwarn')
    .setDescription('Remove a warning from a user, or list all warnings.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand(sub => sub
      .setName('remove')
      .setDescription('Remove a specific warning by ID')
      .addStringOption(o => o.setName('id').setDescription('Warning ID').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('list')
      .setDescription('List all warnings for a user')
      .addUserOption(o => o.setName('user').setDescription('User').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('clear')
      .setDescription('Clear all warnings for a user')
      .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))),

  userPermissions: ['ModerateMembers'],
  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    if (sub === 'remove') {
      const id = interaction.options.getString('id').toUpperCase();
      const warn = await Warn.findOne({ warnId: id, guildId: interaction.guild.id });
      if (!warn) return interaction.editReply({ embeds: [errorEmbed('Not Found', `No warning found with ID \`${id}\`.`)] });

      warn.active = false;
      await warn.save();
      return interaction.editReply({ embeds: [successEmbed('Warning Removed', `Warning \`${id}\` has been removed.`)] });
    }

    if (sub === 'list') {
      const user = interaction.options.getUser('user');
      const warns = await Warn.find({ guildId: interaction.guild.id, userId: user.id, active: true }).sort({ createdAt: -1 });

      if (!warns.length) return interaction.editReply({ embeds: [infoEmbed('No Warnings', `${user.tag} has no active warnings.`)] });

      const fields = warns.slice(0, 10).map(w => ({
        name: `\`${w.warnId}\` — <t:${Math.floor(w.createdAt.getTime() / 1000)}:R>`,
        value: `**Reason:** ${w.reason}\n**Mod:** <@${w.moderatorId}>`,
      }));

      return interaction.editReply({
        embeds: [infoEmbed(`Warnings for ${user.tag}`, `**Total:** ${warns.length} active warnings`, fields)
          .setThumbnail(user.displayAvatarURL({ dynamic: true }))],
      });
    }

    if (sub === 'clear') {
      const user = interaction.options.getUser('user');
      const result = await Warn.updateMany({ guildId: interaction.guild.id, userId: user.id }, { active: false });
      return interaction.editReply({ embeds: [successEmbed('Warnings Cleared', `Cleared ${result.modifiedCount} warnings for ${user.tag}.`)] });
    }
  },
};
