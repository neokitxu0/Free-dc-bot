/**
 * /warn — Warn a member and store in database.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { modEmbed, errorEmbed, infoEmbed } = require('../../utils/embed');
const Warn = require('../../models/Warn');
const { sendModLog } = require('../../utils/antiSpam');
const crypto = require('crypto');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a member.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('User to warn').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the warning').setRequired(true)),

  userPermissions: ['ModerateMembers'],
  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    if (target.bot) return interaction.editReply({ embeds: [errorEmbed('Error', 'You cannot warn a bot.')] });

    const warnId = crypto.randomBytes(4).toString('hex').toUpperCase();

    const warn = await Warn.create({
      warnId,
      guildId: interaction.guild.id,
      userId: target.id,
      moderatorId: interaction.user.id,
      reason,
    });

    const totalWarns = await Warn.countDocuments({ guildId: interaction.guild.id, userId: target.id, active: true });

    await target.send({
      embeds: [modEmbed({ action: `You have been warned in ${interaction.guild.name}`, target, moderator: interaction.user, reason })
        .addFields({ name: 'Warning ID', value: `\`${warnId}\``, inline: true }, { name: 'Total Warnings', value: `${totalWarns}`, inline: true })],
    }).catch(() => {});

    await interaction.editReply({
      embeds: [modEmbed({ action: 'Member Warned', target, moderator: interaction.user, reason })
        .addFields({ name: 'Warning ID', value: `\`${warnId}\``, inline: true }, { name: 'Total Warnings', value: `${totalWarns}`, inline: true })],
    });

    await sendModLog(interaction.guild, { action: 'Warn', target, punishment: `warn (ID: ${warnId})` });
  },
};
