/**
 * /loop — Toggle loop mode for the queue or current track.
 */

const { SlashCommandBuilder } = require('discord.js');
const { musicEmbed, errorEmbed } = require('../../utils/embed');
const { useQueue, QueueRepeatMode } = require('discord-player');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('loop')
    .setDescription('Set the loop mode.')
    .addStringOption(o => o.setName('mode').setDescription('Loop mode').setRequired(true)
      .addChoices(
        { name: '🚫 Off', value: 'off' },
        { name: '🔂 Track', value: 'track' },
        { name: '🔁 Queue', value: 'queue' },
        { name: '🔀 Autoplay', value: 'autoplay' },
      )),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) {
      return interaction.reply({ embeds: [errorEmbed('No Music', 'Nothing is playing.')], ephemeral: true });
    }

    const modes = {
      off:      QueueRepeatMode.OFF,
      track:    QueueRepeatMode.TRACK,
      queue:    QueueRepeatMode.QUEUE,
      autoplay: QueueRepeatMode.AUTOPLAY,
    };

    const mode  = interaction.options.getString('mode');
    queue.setRepeatMode(modes[mode]);

    const labels = { off: '🚫 Off', track: '🔂 Track', queue: '🔁 Queue', autoplay: '🔀 Autoplay' };

    return interaction.reply({
      embeds: [musicEmbed('Loop Mode', `Loop mode set to **${labels[mode]}**`)],
    });
  },
};
