/**
 * /play — Play a song or playlist in a voice channel.
 */

const { SlashCommandBuilder } = require('discord.js');
const { musicEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Play a song or playlist in your voice channel.')
    .addStringOption(o => o.setName('query').setDescription('Song name, URL, or Spotify link').setRequired(true)),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();

    if (!interaction.member.voice.channelId) {
      return interaction.editReply({ embeds: [errorEmbed('No Voice Channel', 'You must be in a voice channel to play music.')] });
    }

    if (!client.player) {
      return interaction.editReply({ embeds: [errorEmbed('Music Unavailable', 'Music player is not initialized.')] });
    }

    const query = interaction.options.getString('query');

    try {
      const { track } = await client.player.play(interaction.member.voice.channel, query, {
        nodeOptions: {
          metadata: {
            channel: interaction.channel,
            client: interaction.guild.members.me,
            requestedBy: interaction.user,
          },
          selfDeaf: true,
          volume: 50,
          leaveOnEmpty: true,
          leaveOnEmptyDelay: 300_000,
          leaveOnEnd: true,
          leaveOnEndDelay: 300_000,
        },
      });

      return interaction.editReply({
        embeds: [musicEmbed('Added to Queue', `**[${track.title}](${track.url})**`, [
          { name: '👤 Artist', value: track.author, inline: true },
          { name: '⏱️ Duration', value: track.duration, inline: true },
          { name: '🙏 Requested by', value: interaction.user.toString(), inline: true },
        ]).setThumbnail(track.thumbnail)],
      });
    } catch (err) {
      return interaction.editReply({ embeds: [errorEmbed('Playback Error', `Could not play that track: ${err.message}`)] });
    }
  },
};
