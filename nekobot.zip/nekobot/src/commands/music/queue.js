/**
 * /queue — View the current music queue.
 */

const { SlashCommandBuilder } = require('discord.js');
const { musicEmbed, errorEmbed } = require('../../utils/embed');
const { useQueue } = require('discord-player');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('queue')
    .setDescription('View the current music queue.')
    .addIntegerOption(o => o.setName('page').setDescription('Page number').setMinValue(1).setRequired(false)),

  guildOnly: true,
  cooldown: 5,

  async execute(client, interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) {
      return interaction.reply({ embeds: [errorEmbed('Empty Queue', 'There is nothing in the queue.')], ephemeral: true });
    }

    const page  = (interaction.options.getInteger('page') || 1) - 1;
    const perPage = 10;
    const tracks  = queue.tracks.toArray();
    const totalPages = Math.ceil(tracks.length / perPage) || 1;
    const current = queue.currentTrack;

    const slice = tracks.slice(page * perPage, (page + 1) * perPage);
    const queueStr = slice.length
      ? slice.map((t, i) => `\`${page * perPage + i + 1}.\` **[${t.title}](${t.url})** — ${t.duration}`).join('\n')
      : 'No more tracks in queue.';

    return interaction.reply({
      embeds: [musicEmbed(`Queue — Page ${page + 1}/${totalPages}`, queueStr, [
        { name: '🎵 Now Playing', value: `**[${current.title}](${current.url})** — ${current.duration}`, inline: false },
        { name: '📋 Total tracks', value: `${tracks.length}`, inline: true },
        { name: '🔁 Loop mode', value: queue.repeatMode === 0 ? 'Off' : queue.repeatMode === 1 ? 'Track' : 'Queue', inline: true },
      ])],
    });
  },
};
