/**
 * /shuffle — Shuffle the music queue.
 */

const { SlashCommandBuilder } = require('discord.js');
const { musicEmbed, errorEmbed } = require('../../utils/embed');
const { useQueue } = require('discord-player');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shuffle')
    .setDescription('Shuffle the current music queue.'),

  guildOnly: true,
  cooldown: 5,

  async execute(client, interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.tracks.size) {
      return interaction.reply({ embeds: [errorEmbed('Empty Queue', 'The queue is empty.')], ephemeral: true });
    }

    queue.tracks.shuffle();

    return interaction.reply({
      embeds: [musicEmbed('Queue Shuffled', `🔀 Shuffled **${queue.tracks.size}** tracks in the queue.`)],
    });
  },
};
