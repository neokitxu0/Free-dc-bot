/**
 * /skip — Skip the current song.
 */

const { SlashCommandBuilder } = require('discord.js');
const { musicEmbed, errorEmbed } = require('../../utils/embed');
const { useQueue } = require('discord-player');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('skip')
    .setDescription('Skip the current song.'),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) {
      return interaction.reply({ embeds: [errorEmbed('No Music', 'There is nothing playing right now.')], ephemeral: true });
    }

    const current = queue.currentTrack;
    queue.node.skip();

    return interaction.reply({
      embeds: [musicEmbed('Skipped', `Skipped **[${current.title}](${current.url})**`)],
    });
  },
};
