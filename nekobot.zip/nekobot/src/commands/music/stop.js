/**
 * /stop — Stop the music and clear the queue.
 */

const { SlashCommandBuilder } = require('discord.js');
const { musicEmbed, errorEmbed } = require('../../utils/embed');
const { useQueue } = require('discord-player');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stop')
    .setDescription('Stop the music and clear the queue.'),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) {
      return interaction.reply({ embeds: [errorEmbed('No Music', 'Nothing is playing.')], ephemeral: true });
    }

    queue.delete();

    return interaction.reply({
      embeds: [musicEmbed('Stopped', '⏹️ Music stopped and queue cleared.')],
    });
  },
};
