/**
 * /volume — Set the playback volume.
 */

const { SlashCommandBuilder } = require('discord.js');
const { musicEmbed, errorEmbed } = require('../../utils/embed');
const { useQueue } = require('discord-player');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Set the playback volume (1-100).')
    .addIntegerOption(o => o.setName('level').setDescription('Volume level (1-100)').setMinValue(1).setMaxValue(100).setRequired(true)),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) {
      return interaction.reply({ embeds: [errorEmbed('No Music', 'Nothing is playing.')], ephemeral: true });
    }

    const level = interaction.options.getInteger('level');
    queue.node.setVolume(level);

    const bar = '█'.repeat(Math.round(level / 10)) + '░'.repeat(10 - Math.round(level / 10));
    return interaction.reply({
      embeds: [musicEmbed('Volume Set', `🔊 Volume: \`[${bar}]\` **${level}%**`)],
    });
  },
};
