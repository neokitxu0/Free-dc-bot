/**
 * /blacklist — Blacklist or un-blacklist users/guilds.
 */

const { SlashCommandBuilder } = require('discord.js');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embed');
const Blacklist = require('../../models/Blacklist');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('blacklist')
    .setDescription('[OWNER] Manage the global blacklist.')
    .addSubcommand(sub => sub
      .setName('add')
      .setDescription('Add a user or guild to the blacklist')
      .addStringOption(o => o.setName('id').setDescription('User or Guild ID').setRequired(true))
      .addStringOption(o => o.setName('type').setDescription('Type').setRequired(true)
        .addChoices({ name: 'User', value: 'user' }, { name: 'Guild', value: 'guild' }))
      .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)))
    .addSubcommand(sub => sub
      .setName('remove')
      .setDescription('Remove from blacklist')
      .addStringOption(o => o.setName('id').setDescription('User or Guild ID').setRequired(true))
      .addStringOption(o => o.setName('type').setDescription('Type').setRequired(true)
        .addChoices({ name: 'User', value: 'user' }, { name: 'Guild', value: 'guild' })))
    .addSubcommand(sub => sub
      .setName('list')
      .setDescription('List blacklisted users/guilds')),

  ownerOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const id     = interaction.options.getString('id');
      const type   = interaction.options.getString('type');
      const reason = interaction.options.getString('reason') || 'No reason provided';

      await Blacklist.findOneAndUpdate(
        { id, type },
        { id, type, reason, by: interaction.user.id },
        { upsert: true, new: true }
      );

      // If blacklisting a guild, leave it
      if (type === 'guild' && client.guilds.cache.has(id)) {
        await client.guilds.cache.get(id)?.leave();
      }

      return interaction.editReply({ embeds: [successEmbed('Blacklisted', `${type} \`${id}\` has been blacklisted.\n**Reason:** ${reason}`)] });
    }

    if (sub === 'remove') {
      const id   = interaction.options.getString('id');
      const type = interaction.options.getString('type');
      await Blacklist.deleteOne({ id, type });
      return interaction.editReply({ embeds: [successEmbed('Removed', `${type} \`${id}\` removed from blacklist.`)] });
    }

    if (sub === 'list') {
      const entries = await Blacklist.find().limit(25).lean();
      if (!entries.length) return interaction.editReply({ embeds: [infoEmbed('Blacklist', 'No blacklisted entries.')] });
      const rows = entries.map(e => `\`${e.id}\` [${e.type}] — ${e.reason}`).join('\n');
      return interaction.editReply({ embeds: [infoEmbed('Blacklist', rows.slice(0, 4096))] });
    }
  },
};
