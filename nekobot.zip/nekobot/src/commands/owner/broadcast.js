/**
 * /broadcast — Send a message to all guilds' system channels.
 */

const { SlashCommandBuilder } = require('discord.js');
const { successEmbed, warningEmbed } = require('../../utils/embed');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('broadcast')
    .setDescription('[OWNER] Broadcast a message to all guild system channels.')
    .addStringOption(o => o.setName('message').setDescription('Message to broadcast').setRequired(true))
    .addBooleanOption(o => o.setName('confirm').setDescription('Confirm the broadcast').setRequired(true)),

  ownerOnly: true,
  cooldown: 30,

  async execute(client, interaction) {
    await interaction.deferReply({ ephemeral: true });

    const message = interaction.options.getString('message');
    const confirm = interaction.options.getBoolean('confirm');

    if (!confirm) {
      return interaction.editReply({ embeds: [warningEmbed('Cancelled', 'Broadcast cancelled (confirm was false).')] });
    }

    const embed = warningEmbed(
      `📢 Global Announcement from ${config.botName}`,
      message
    ).setFooter({ text: `Sent by: ${interaction.user.tag}` });

    let sent = 0, failed = 0;

    for (const [, guild] of client.guilds.cache) {
      const channel = guild.systemChannel
        || guild.channels.cache.find(c => c.type === 0 && c.permissionsFor(guild.members.me)?.has('SendMessages'));

      if (channel) {
        await channel.send({ embeds: [embed] }).then(() => sent++).catch(() => failed++);
      } else {
        failed++;
      }
    }

    return interaction.editReply({
      embeds: [successEmbed('Broadcast Complete', `**Sent:** ${sent} guilds\n**Failed:** ${failed} guilds`)],
    });
  },
};
