/**
 * /eval — Execute arbitrary JavaScript code. Owner only!
 */

const { SlashCommandBuilder } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const util = require('util');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('eval')
    .setDescription('[OWNER] Execute JavaScript code.')
    .addStringOption(o => o.setName('code').setDescription('Code to execute').setRequired(true))
    .addBooleanOption(o => o.setName('async').setDescription('Wrap in async function').setRequired(false))
    .addBooleanOption(o => o.setName('silent').setDescription('Silent mode (no output)').setRequired(false)),

  ownerOnly: true,
  cooldown: 0,

  async execute(client, interaction) {
    await interaction.deferReply({ ephemeral: true });

    let code = interaction.options.getString('code');
    const isAsync = interaction.options.getBoolean('async') ?? false;
    const silent  = interaction.options.getBoolean('silent') ?? false;

    if (isAsync) code = `(async () => { ${code} })()`;

    const start = Date.now();
    let result, type;

    try {
      result = await eval(code); // eslint-disable-line no-eval
      type   = typeof result;
      result = util.inspect(result, { depth: 1 });
    } catch (err) {
      return interaction.editReply({
        embeds: [errorEmbed('Eval Error', `\`\`\`js\n${err.message.slice(0, 1000)}\n\`\`\``)],
      });
    }

    if (silent) return interaction.editReply({ content: '✅ Executed silently.' });

    const duration = Date.now() - start;
    const output   = result.length > 1000 ? result.slice(0, 1000) + '...' : result;

    return interaction.editReply({
      embeds: [successEmbed('Eval Result', `\`\`\`js\n${output}\n\`\`\``, [
        { name: 'Type',     value: `\`${type}\``,     inline: true },
        { name: 'Duration', value: `${duration}ms`,   inline: true },
      ])],
    });
  },
};
