/**
 * /maintenance — Toggle maintenance mode.
 */

const { SlashCommandBuilder } = require('discord.js');
const { successEmbed } = require('../../utils/embed');
const Guild = require('../../models/Guild');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('maintenance')
    .setDescription('[OWNER] Toggle maintenance mode for a guild or globally.')
    .addBooleanOption(o => o.setName('enabled').setDescription('Enable or disable maintenance').setRequired(true))
    .addStringOption(o => o.setName('guild').setDescription('Guild ID (leave empty for current guild)').setRequired(false)),

  ownerOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply({ ephemeral: true });

    const enabled = interaction.options.getBoolean('enabled');
    const guildId = interaction.options.getString('guild') || interaction.guild?.id;

    if (!guildId) return interaction.editReply({ content: 'No guild specified.' });

    await Guild.findOneAndUpdate(
      { guildId },
      { maintenance: enabled },
      { upsert: true }
    );

    return interaction.editReply({
      embeds: [successEmbed('Maintenance Mode', `Maintenance mode is now **${enabled ? '🔧 enabled' : '✅ disabled'}** for guild \`${guildId}\`.`)],
    });
  },
};
