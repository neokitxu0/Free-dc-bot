/**
 * /reload — Reload commands or events without restarting the bot.
 */

const { SlashCommandBuilder } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embed');
const { loadCommands, reloadCommand } = require('../../handlers/commandHandler');
const { loadEvents, reloadEvents } = require('../../handlers/eventHandler');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reload')
    .setDescription('[OWNER] Reload commands or events.')
    .addSubcommand(sub => sub
      .setName('command')
      .setDescription('Reload a specific command')
      .addStringOption(o => o.setName('name').setDescription('Command name').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('all-commands')
      .setDescription('Reload all commands'))
    .addSubcommand(sub => sub
      .setName('events')
      .setDescription('Reload all events')),

  ownerOnly: true,
  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();

    try {
      if (sub === 'command') {
        const name = interaction.options.getString('name');
        const reloaded = await reloadCommand(client, name);
        return interaction.editReply({ embeds: [successEmbed('Command Reloaded', `✅ \`/${reloaded}\` has been reloaded.`)] });
      }

      if (sub === 'all-commands') {
        await loadCommands(client);
        return interaction.editReply({ embeds: [successEmbed('Commands Reloaded', `✅ ${client.commands.size} commands reloaded.`)] });
      }

      if (sub === 'events') {
        await reloadEvents(client);
        return interaction.editReply({ embeds: [successEmbed('Events Reloaded', '✅ All events have been reloaded.')] });
      }
    } catch (err) {
      return interaction.editReply({ embeds: [errorEmbed('Reload Error', err.message)] });
    }
  },
};
