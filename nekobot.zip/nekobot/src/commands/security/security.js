/**
 * /security — Configure the advanced security system.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, infoEmbed } = require('../../utils/embed');
const Guild = require('../../models/Guild');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('security')
    .setDescription('Configure the server security system.')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub => sub
      .setName('toggle')
      .setDescription('Toggle a security feature')
      .addStringOption(o => o.setName('feature').setDescription('Feature').setRequired(true)
        .addChoices(
          { name: 'Anti-Nuke',           value: 'antiNuke' },
          { name: 'Anti-Channel Delete', value: 'antiChannelDelete' },
          { name: 'Anti-Role Delete',    value: 'antiRoleDelete' },
          { name: 'Anti-Ban',            value: 'antiBan' },
          { name: 'Anti-Kick',           value: 'antiKick' },
        ))
      .addBooleanOption(o => o.setName('enabled').setDescription('Enable/disable').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('whitelist')
      .setDescription('Add or remove a user from the security whitelist')
      .addStringOption(o => o.setName('action').setDescription('add/remove').setRequired(true)
        .addChoices({ name: 'Add', value: 'add' }, { name: 'Remove', value: 'remove' }))
      .addUserOption(o => o.setName('user').setDescription('User').setRequired(true)))
    .addSubcommand(sub => sub.setName('status').setDescription('View security status')),

  userPermissions: ['Administrator'],
  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    let guildDoc = await Guild.findOneAndUpdate(
      { guildId: interaction.guild.id },
      {},
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    if (sub === 'toggle') {
      const feature = interaction.options.getString('feature');
      const enabled = interaction.options.getBoolean('enabled');
      guildDoc.security[feature] = enabled;
      await guildDoc.save();
      return interaction.editReply({
        embeds: [successEmbed('Security Updated', `**${feature}** is now **${enabled ? '✅ enabled' : '❌ disabled'}**.`)],
      });
    }

    if (sub === 'whitelist') {
      const action = interaction.options.getString('action');
      const user   = interaction.options.getUser('user');

      if (!guildDoc.security.whitelist) guildDoc.security.whitelist = [];

      if (action === 'add') {
        if (!guildDoc.security.whitelist.includes(user.id)) guildDoc.security.whitelist.push(user.id);
      } else {
        guildDoc.security.whitelist = guildDoc.security.whitelist.filter(id => id !== user.id);
      }
      await guildDoc.save();
      return interaction.editReply({
        embeds: [successEmbed('Whitelist Updated', `${user.tag} has been ${action === 'add' ? 'added to' : 'removed from'} the security whitelist.`)],
      });
    }

    if (sub === 'status') {
      const s = (v) => v ? '✅' : '❌';
      const sec = guildDoc.security;
      return interaction.editReply({
        embeds: [infoEmbed('Security Status', '', [
          { name: '🛡️ Features', value: [
            `${s(sec.antiNuke)} Anti-Nuke`,
            `${s(sec.antiChannelDelete)} Anti-Channel Delete`,
            `${s(sec.antiRoleDelete)} Anti-Role Delete`,
            `${s(sec.antiBan)} Anti-Ban`,
            `${s(sec.antiKick)} Anti-Kick`,
          ].join('\n'), inline: true },
          { name: '✅ Whitelist', value: sec.whitelist?.map(id => `<@${id}>`).join('\n') || 'None', inline: true },
        ])],
      });
    }
  },
};
