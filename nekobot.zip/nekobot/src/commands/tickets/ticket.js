/**
 * /ticket — Create a ticket panel and manage tickets.
 */

const {
  SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder,
  ButtonBuilder, ButtonStyle, EmbedBuilder,
  ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle,
} = require('discord.js');
const { successEmbed, errorEmbed, ticketEmbed, infoEmbed } = require('../../utils/embed');
const Guild  = require('../../models/Guild');
const Ticket = require('../../models/Ticket');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Manage the ticket system.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub
      .setName('setup')
      .setDescription('Create the ticket panel in a channel')
      .addChannelOption(o => o.setName('channel').setDescription('Panel channel').setRequired(true))
      .addStringOption(o => o.setName('title').setDescription('Panel title').setRequired(false))
      .addStringOption(o => o.setName('description').setDescription('Panel description').setRequired(false)))
    .addSubcommand(sub => sub
      .setName('close')
      .setDescription('Close a ticket (run inside a ticket channel)'))
    .addSubcommand(sub => sub
      .setName('claim')
      .setDescription('Claim a ticket (run inside a ticket channel)'))
    .addSubcommand(sub => sub
      .setName('rename')
      .setDescription('Rename a ticket channel')
      .addStringOption(o => o.setName('name').setDescription('New name').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('add')
      .setDescription('Add a user to this ticket')
      .addUserOption(o => o.setName('user').setDescription('User to add').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('remove')
      .setDescription('Remove a user from this ticket')
      .addUserOption(o => o.setName('user').setDescription('User to remove').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('list')
      .setDescription('List open tickets in this server'))
    .addSubcommand(sub => sub
      .setName('staffrole')
      .setDescription('Set a staff role for tickets')
      .addRoleOption(o => o.setName('role').setDescription('Staff role').setRequired(true))),

  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();

    let guildDoc = await Guild.findOneAndUpdate(
      { guildId: interaction.guild.id },
      {},
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    // ── Setup Ticket Panel ─────────────────────────────────────────────────
    if (sub === 'setup') {
      const channel     = interaction.options.getChannel('channel');
      const panelTitle  = interaction.options.getString('title') || '🎫 Open a Support Ticket';
      const panelDesc   = interaction.options.getString('description') || 'Click the button below to open a support ticket.\nOur team will assist you shortly!';

      const embed = new EmbedBuilder()
        .setColor(config.colors.primary)
        .setTitle(panelTitle)
        .setDescription(panelDesc)
        .setFooter({ text: `${config.botName} Ticket System` })
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('ticket_open')
          .setLabel('Open a Ticket')
          .setEmoji('🎫')
          .setStyle(ButtonStyle.Primary)
      );

      const msg = await channel.send({ embeds: [embed], components: [row] });

      guildDoc.tickets.enabled = true;
      guildDoc.tickets.panelChannelId = channel.id;
      guildDoc.tickets.panelMessageId = msg.id;
      await guildDoc.save();

      return interaction.editReply({ embeds: [successEmbed('Ticket Panel Created', `Panel sent to ${channel}.`)] });
    }

    // ── Close Ticket ────────────────────────────────────────────────────────
    if (sub === 'close') {
      const ticket = await Ticket.findOne({ channelId: interaction.channelId });
      if (!ticket) return interaction.editReply({ embeds: [errorEmbed('Error', 'This is not a ticket channel.')] });

      const { generateTranscript } = require('../../utils/transcript');
      const transcriptPath = await generateTranscript(interaction.channel).catch(() => null);

      if (transcriptPath && guildDoc.channels.ticketLog) {
        const logCh = interaction.guild.channels.cache.get(guildDoc.channels.ticketLog);
        if (logCh) {
          const { AttachmentBuilder } = require('discord.js');
          await logCh.send({
            embeds: [ticketEmbed('Ticket Closed', `**ID:** ${ticket.ticketId}\n**Closed by:** ${interaction.user.tag}`)],
            files: [new AttachmentBuilder(transcriptPath, { name: `${ticket.ticketId}.html` })],
          });
        }
      }

      ticket.status = 'closed';
      ticket.closedBy = interaction.user.id;
      ticket.closedAt = new Date();
      await ticket.save();

      await interaction.editReply({ embeds: [successEmbed('Ticket Closing', 'Ticket will be deleted in 5 seconds.')] });
      setTimeout(() => interaction.channel.delete(`Closed by ${interaction.user.tag}`).catch(() => {}), 5000);
    }

    // ── Rename ──────────────────────────────────────────────────────────────
    if (sub === 'rename') {
      const name = interaction.options.getString('name');
      await interaction.channel.setName(name).catch(() => {});
      return interaction.editReply({ embeds: [successEmbed('Renamed', `Channel renamed to \`${name}\`.`)] });
    }

    // ── Add User ────────────────────────────────────────────────────────────
    if (sub === 'add') {
      const user = interaction.options.getUser('user');
      await interaction.channel.permissionOverwrites.edit(user.id, {
        ViewChannel: true, SendMessages: true, ReadMessageHistory: true,
      });
      return interaction.editReply({ embeds: [successEmbed('User Added', `${user} has been added to this ticket.`)] });
    }

    // ── Remove User ─────────────────────────────────────────────────────────
    if (sub === 'remove') {
      const user = interaction.options.getUser('user');
      await interaction.channel.permissionOverwrites.edit(user.id, { ViewChannel: false });
      return interaction.editReply({ embeds: [successEmbed('User Removed', `${user} has been removed from this ticket.`)] });
    }

    // ── List Open Tickets ───────────────────────────────────────────────────
    if (sub === 'list') {
      const tickets = await Ticket.find({ guildId: interaction.guild.id, status: { $in: ['open', 'claimed'] } }).limit(15);
      if (!tickets.length) return interaction.editReply({ embeds: [infoEmbed('Tickets', 'No open tickets.')] });

      const fields = tickets.map(t => ({
        name: t.ticketId,
        value: `<#${t.channelId}> | <@${t.userId}> | ${t.status}`,
        inline: false,
      }));

      return interaction.editReply({ embeds: [infoEmbed(`Open Tickets (${tickets.length})`, '', fields)] });
    }

    // ── Staff Role ──────────────────────────────────────────────────────────
    if (sub === 'staffrole') {
      const role = interaction.options.getRole('role');
      if (!guildDoc.tickets.staffRoles.includes(role.id)) guildDoc.tickets.staffRoles.push(role.id);
      await guildDoc.save();
      return interaction.editReply({ embeds: [successEmbed('Staff Role Set', `${role} can now manage tickets.`)] });
    }
  },
};
