/**
 * /botinfo — Display NekoBot information and statistics.
 */

const { SlashCommandBuilder, version: djsVersion } = require('discord.js');
const { infoEmbed } = require('../../utils/embed');
const config = require('../../../config');
const os = require('os');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botinfo')
    .setDescription('View information and statistics about NekoBot.'),

  cooldown: 5,

  async execute(client, interaction) {
    const uptime = process.uptime();
    const d = Math.floor(uptime / 86400);
    const h = Math.floor((uptime % 86400) / 3600);
    const m = Math.floor((uptime % 3600) / 60);
    const s = Math.floor(uptime % 60);
    const uptimeStr = `${d}d ${h}h ${m}m ${s}s`;

    const memUsed = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
    const memTotal = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
    const cpuLoad = os.loadavg()[0].toFixed(2);

    const embed = infoEmbed(
      `${config.botName}`,
      `A highly advanced Discord bot with moderation, economy, music, leveling, AI, and more.`,
      [
        { name: '🤖 Version',      value: '1.0.0',           inline: true },
        { name: '📡 discord.js',   value: `v${djsVersion}`,  inline: true },
        { name: '🟢 Node.js',      value: process.version,   inline: true },
        { name: '⏱️ Uptime',       value: uptimeStr,         inline: true },
        { name: '🏠 Guilds',       value: `${client.guilds.cache.size}`,  inline: true },
        { name: '👥 Users',        value: `${client.users.cache.size}`,   inline: true },
        { name: '📝 Commands',     value: `${client.commands.size}`,      inline: true },
        { name: '💾 Memory',       value: `${memUsed} MB`,  inline: true },
        { name: '💻 CPU Load',     value: `${cpuLoad}%`,    inline: true },
        { name: '🌐 Latency',      value: `${client.ws.ping}ms`,          inline: true },
        { name: '👑 Developer',    value: 'NekoBot Team',   inline: true },
        { name: '🔗 Support',      value: `[Join Server](${config.supportServerInvite})`, inline: true },
      ]
    ).setThumbnail(client.user.displayAvatarURL({ dynamic: true }));

    return interaction.reply({ embeds: [embed] });
  },
};
