/**
 * /invite — Get NekoBot's invite link.
 */

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embed');
const config = require('../../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invite')
    .setDescription("Get NekoBot's invite link."),

  cooldown: 5,

  async execute(client, interaction) {
    const inviteUrl = `https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`;

    return interaction.reply({
      embeds: [infoEmbed('📨 Invite NekoBot', `Click the links below to add me to your server or join our support server.`, [
        { name: '🤖 Invite Link',    value: `[Click here](${inviteUrl})`, inline: true },
        { name: '💬 Support Server', value: `[Join here](${config.supportServerInvite})`, inline: true },
      ]).setThumbnail(client.user.displayAvatarURL({ dynamic: true }))],
    });
  },
};
