/**
 * /ping — Check the bot's latency.
 */

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription("Check NekoBot's latency and API response time."),

  cooldown: 5,

  async execute(client, interaction) {
    const start = Date.now();
    await interaction.reply({ content: '⏳ Calculating...' });
    const latency = Date.now() - start;
    const wsLatency = client.ws.ping;

    const getEmoji = (ms) => ms < 100 ? '🟢' : ms < 200 ? '🟡' : '🔴';

    await interaction.editReply({
      content: null,
      embeds: [infoEmbed('🏓 Pong!', 'Latency information:', [
        { name: `${getEmoji(latency)} API Latency`,      value: `\`${latency}ms\``,   inline: true },
        { name: `${getEmoji(wsLatency)} WebSocket Ping`, value: `\`${wsLatency}ms\``, inline: true },
      ])],
    });
  },
};
