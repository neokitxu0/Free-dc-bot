/**
 * /serverinfo — Display detailed server information.
 */

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('View detailed information about this server.'),

  guildOnly: true,
  cooldown: 5,

  async execute(client, interaction) {
    const { guild } = interaction;
    await guild.fetch();

    const owner = await guild.fetchOwner();
    const channels = guild.channels.cache;
    const roles    = guild.roles.cache.filter(r => r.id !== guild.id);

    const textCh  = channels.filter(c => c.type === 0).size;
    const voiceCh = channels.filter(c => c.type === 2).size;
    const catCh   = channels.filter(c => c.type === 4).size;

    const verificationLevels = ['None', 'Low', 'Medium', 'High', 'Very High'];
    const boostTiers = ['None', 'Tier 1', 'Tier 2', 'Tier 3'];

    const embed = infoEmbed(
      guild.name,
      guild.description || 'No description.',
      [
        { name: '👑 Owner',           value: owner.user.tag,              inline: true },
        { name: '🆔 Server ID',       value: guild.id,                    inline: true },
        { name: '📅 Created',         value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },
        { name: '👥 Members',         value: `${guild.memberCount}`,      inline: true },
        { name: '🤖 Bots',            value: `${guild.members.cache.filter(m => m.user.bot).size}`, inline: true },
        { name: '💎 Boost Level',     value: boostTiers[guild.premiumTier] || 'None', inline: true },
        { name: '🔋 Boosts',          value: `${guild.premiumSubscriptionCount || 0}`, inline: true },
        { name: '🔒 Verification',    value: verificationLevels[guild.verificationLevel], inline: true },
        { name: '📁 Channels',        value: `💬 ${textCh} | 🔊 ${voiceCh} | 📁 ${catCh}`, inline: true },
        { name: '🏷️ Roles',          value: `${roles.size}`,             inline: true },
        { name: '😀 Emojis',          value: `${guild.emojis.cache.size}`, inline: true },
        { name: '🎭 Stickers',        value: `${guild.stickers.cache.size}`, inline: true },
      ]
    )
    .setThumbnail(guild.iconURL({ dynamic: true, size: 256 }))
    .setImage(guild.bannerURL({ dynamic: true, size: 1024 }) || null);

    return interaction.reply({ embeds: [embed] });
  },
};
