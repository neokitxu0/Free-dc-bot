/**
 * /stats — View detailed bot statistics.
 */

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embed');
const os = require('os');
const mongoose = require('mongoose');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('View detailed NekoBot statistics.'),

  cooldown: 10,

  async execute(client, interaction) {
    await interaction.deferReply();

    const uptime = process.uptime();
    const d = Math.floor(uptime / 86400);
    const h = Math.floor((uptime % 86400) / 3600);
    const m = Math.floor((uptime % 3600) / 60);

    const mem     = process.memoryUsage();
    const heapMB  = (mem.heapUsed / 1024 / 1024).toFixed(2);
    const rssMB   = (mem.rss / 1024 / 1024).toFixed(2);
    const totalMB = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
    const freeMB  = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);

    const dbState = ['Disconnected', 'Connected', 'Connecting', 'Disconnecting'][mongoose.connection.readyState] || 'Unknown';

    const totalGuildMembers = client.guilds.cache.reduce((a, g) => a + g.memberCount, 0);

    const embed = infoEmbed('📊 NekoBot Statistics', '', [
      { name: '🌐 Guilds',     value: `${client.guilds.cache.size}`,      inline: true },
      { name: '👥 Users',      value: `${client.users.cache.size}`,       inline: true },
      { name: '🤖 Total Members', value: `${totalGuildMembers.toLocaleString()}`, inline: true },
      { name: '📝 Commands',   value: `${client.commands.size}`,          inline: true },
      { name: '📡 Shards',     value: `${client.ws.shards.size || 1}`,    inline: true },
      { name: '🏓 WS Ping',    value: `${client.ws.ping}ms`,              inline: true },
      { name: '⏱️ Uptime',     value: `${d}d ${h}h ${m}m`,               inline: true },
      { name: '💾 Heap Used',  value: `${heapMB} MB`,                     inline: true },
      { name: '🖥️ RAM Used',   value: `${rssMB} MB`,                     inline: true },
      { name: '💿 System RAM', value: `${(totalMB - freeMB).toFixed(2)}/${totalMB} GB`, inline: true },
      { name: '🗄️ Database',  value: dbState,                             inline: true },
      { name: '🟢 Node.js',   value: process.version,                     inline: true },
    ])
    .setThumbnail(client.user.displayAvatarURL({ dynamic: true }));

    return interaction.editReply({ embeds: [embed] });
  },
};
