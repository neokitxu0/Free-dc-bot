/**
 * /suggest — Submit a suggestion via modal.
 */

const {
  SlashCommandBuilder, ModalBuilder, TextInputBuilder,
  TextInputStyle, ActionRowBuilder, EmbedBuilder,
  ButtonBuilder, ButtonStyle,
} = require('discord.js');
const { errorEmbed, successEmbed } = require('../../utils/embed');
const Guild = require('../../models/Guild');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('suggest')
    .setDescription('Submit a suggestion for the server.'),

  guildOnly: true,
  cooldown: 30,

  async execute(client, interaction) {
    const modal = new ModalBuilder()
      .setCustomId('suggest_submit')
      .setTitle('Submit a Suggestion');

    const titleInput = new TextInputBuilder()
      .setCustomId('suggest_title')
      .setLabel('Title')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('Brief title for your suggestion')
      .setRequired(true)
      .setMaxLength(100);

    const bodyInput = new TextInputBuilder()
      .setCustomId('suggest_body')
      .setLabel('Suggestion')
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder('Describe your suggestion in detail...')
      .setRequired(true)
      .setMaxLength(1000);

    modal.addComponents(
      new ActionRowBuilder().addComponents(titleInput),
      new ActionRowBuilder().addComponents(bodyInput),
    );

    await interaction.showModal(modal);
  },
};

async function handleSuggestModal(client, interaction) {
  const guildDoc = await Guild.findOne({ guildId: interaction.guild.id });
  const suggestChannel = guildDoc?.channels?.suggestChannel;

  if (!suggestChannel) {
    return interaction.reply({
      embeds: [errorEmbed('Not Configured', 'No suggestion channel set. Ask an admin to set one up.')],
      ephemeral: true,
    });
  }

  const channel = interaction.guild.channels.cache.get(suggestChannel);
  if (!channel) return interaction.reply({ content: 'Suggestion channel not found.', ephemeral: true });

  const title = interaction.fields.getTextInputValue('suggest_title');
  const body  = interaction.fields.getTextInputValue('suggest_body');

  const embed = new EmbedBuilder()
    .setColor(0x9B59B6)
    .setTitle(`💡 Suggestion: ${title}`)
    .setDescription(body)
    .addFields({ name: 'Submitted by', value: `${interaction.user.tag}` })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('suggest_upvote').setLabel('👍 Upvote').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('suggest_downvote').setLabel('👎 Downvote').setStyle(ButtonStyle.Danger),
  );

  await channel.send({ embeds: [embed], components: [row] });

  return interaction.reply({
    embeds: [successEmbed('Suggestion Submitted', 'Your suggestion has been submitted!')],
    ephemeral: true,
  });
}

module.exports.handleSuggestModal = handleSuggestModal;
