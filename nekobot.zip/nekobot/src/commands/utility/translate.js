/**
 * /translate — Translate text to another language.
 */

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed, errorEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('translate')
    .setDescription('Translate text to another language.')
    .addStringOption(o => o.setName('text').setDescription('Text to translate').setRequired(true))
    .addStringOption(o => o.setName('to').setDescription('Target language code (e.g. en, es, fr, de, ja)').setRequired(true))
    .addStringOption(o => o.setName('from').setDescription('Source language code (auto-detect if omitted)').setRequired(false)),

  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply();

    const text = interaction.options.getString('text');
    const to   = interaction.options.getString('to');
    const from = interaction.options.getString('from') || 'auto';

    try {
      const translate = require('translate-google');
      const result = await translate(text, { from, to });

      return interaction.editReply({
        embeds: [infoEmbed('🌐 Translation', '', [
          { name: `Original (${from === 'auto' ? 'auto' : from})`, value: text.slice(0, 1024), inline: false },
          { name: `Translated (${to})`, value: result.slice(0, 1024), inline: false },
        ])],
      });
    } catch (err) {
      return interaction.editReply({ embeds: [errorEmbed('Translation Error', `Could not translate: ${err.message}`)] });
    }
  },
};
