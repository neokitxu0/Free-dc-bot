/**
 * /uptime — Show how long NekoBot has been online.
 */

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('uptime')
    .setDescription('Check how long NekoBot has been running.'),

  cooldown: 5,

  async execute(client, interaction) {
    const uptime = process.uptime();
    const d = Math.floor(uptime / 86400);
    const h = Math.floor((uptime % 86400) / 3600);
    const m = Math.floor((uptime % 3600) / 60);
    const s = Math.floor(uptime % 60);

    const startTimestamp = Math.floor((Date.now() - uptime * 1000) / 1000);

    return interaction.reply({
      embeds: [infoEmbed('⏱️ Uptime', `NekoBot has been online for **${d}d ${h}h ${m}m ${s}s**`, [
        { name: '🟢 Online Since', value: `<t:${startTimestamp}:F>`, inline: true },
        { name: '📡 WebSocket',    value: `${client.ws.ping}ms`,    inline: true },
      ])],
    });
  },
};
