/**
 * /userinfo — Display detailed user information.
 */

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embed');
const Warn  = require('../../models/Warn');
const Level = require('../../models/Level');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('View detailed information about a user.')
    .addUserOption(o => o.setName('user').setDescription('User to view').setRequired(false)),

  guildOnly: true,
  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply();

    const user   = interaction.options.getUser('user') || interaction.user;
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);

    const warnCount  = await Warn.countDocuments({ guildId: interaction.guild.id, userId: user.id, active: true });
    const levelData  = await Level.findOne({ guildId: interaction.guild.id, userId: user.id });

    const statusEmojis = { online: '🟢', idle: '🟡', dnd: '🔴', offline: '⚫' };
    const presence = member?.presence?.status || 'offline';

    const fields = [
      { name: '🆔 User ID',    value: user.id,                               inline: true },
      { name: '📅 Registered', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
      { name: `${statusEmojis[presence]} Status`, value: presence, inline: true },
    ];

    if (member) {
      fields.push(
        { name: '📥 Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: '🎭 Nickname', value: member.nickname || 'None', inline: true },
        { name: '💎 Booster', value: member.premiumSince ? `<t:${Math.floor(member.premiumSinceTimestamp / 1000)}:R>` : 'No', inline: true },
        { name: '🏷️ Top Role', value: member.roles.highest.toString(), inline: true },
        { name: `🏷️ Roles (${member.roles.cache.size - 1})`, value: member.roles.cache.filter(r => r.id !== interaction.guild.id).map(r => r.toString()).slice(0, 10).join(', ') || 'None', inline: false },
      );
    }

    fields.push(
      { name: '⚠️ Warnings', value: `${warnCount}`, inline: true },
      { name: '📈 Level', value: levelData ? `${levelData.level} (${levelData.totalXp.toLocaleString()} XP)` : 'No data', inline: true },
    );

    const embed = infoEmbed(`${user.username}${user.bot ? ' [BOT]' : ''}`, '', fields)
      .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 256 }));

    return interaction.editReply({ embeds: [embed] });
  },
};
