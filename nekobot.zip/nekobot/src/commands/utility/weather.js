/**
 * /weather — Get current weather for a location.
 */

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed, errorEmbed } = require('../../utils/embed');
const axios = require('axios');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('weather')
    .setDescription('Get the current weather for a location.')
    .addStringOption(o => o.setName('location').setDescription('City name or zip code').setRequired(true)),

  cooldown: 5,

  async execute(client, interaction) {
    await interaction.deferReply();

    if (!process.env.OPENWEATHER_API_KEY) {
      return interaction.editReply({ embeds: [errorEmbed('Unavailable', 'Weather API key is not configured.')] });
    }

    const location = interaction.options.getString('location');

    try {
      const { data } = await axios.get('https://api.openweathermap.org/data/2.5/weather', {
        params: { q: location, appid: process.env.OPENWEATHER_API_KEY, units: 'metric' },
        timeout: 8000,
      });

      const temp    = data.main.temp.toFixed(1);
      const feels   = data.main.feels_like.toFixed(1);
      const humid   = data.main.humidity;
      const wind    = data.wind.speed.toFixed(1);
      const desc    = data.weather[0].description;
      const icon    = `https://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png`;

      return interaction.editReply({
        embeds: [infoEmbed(
          `🌤️ Weather — ${data.name}, ${data.sys.country}`,
          `**${desc.charAt(0).toUpperCase() + desc.slice(1)}**`,
          [
            { name: '🌡️ Temperature', value: `${temp}°C / ${(temp * 9/5 + 32).toFixed(1)}°F`, inline: true },
            { name: '🤔 Feels Like',  value: `${feels}°C / ${(feels * 9/5 + 32).toFixed(1)}°F`, inline: true },
            { name: '💧 Humidity',    value: `${humid}%`,  inline: true },
            { name: '💨 Wind',        value: `${wind} m/s`, inline: true },
            { name: '🌅 Sunrise',     value: `<t:${data.sys.sunrise}:t>`, inline: true },
            { name: '🌇 Sunset',      value: `<t:${data.sys.sunset}:t>`, inline: true },
          ]
        ).setThumbnail(icon)],
      });
    } catch (err) {
      const msg = err.response?.status === 404
        ? `Location \`${location}\` not found.`
        : `Could not fetch weather: ${err.message}`;
      return interaction.editReply({ embeds: [errorEmbed('Error', msg)] });
    }
  },
};
