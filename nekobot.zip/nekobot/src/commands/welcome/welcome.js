/**
 * /welcome — Configure the welcome and leave system.
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embed');
const Guild = require('../../models/Guild');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('welcome')
    .setDescription('Configure the welcome and leave system.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub
      .setName('setup')
      .setDescription('Set the welcome channel and message')
      .addChannelOption(o => o.setName('channel').setDescription('Welcome channel').setRequired(true))
      .addStringOption(o => o.setName('message').setDescription('Welcome message ({user}, {server}, {count})').setRequired(false))
      .addStringOption(o => o.setName('type').setDescription('Message type').setRequired(false)
        .addChoices({ name: 'Text', value: 'text' }, { name: 'Embed', value: 'embed' }, { name: 'Card', value: 'card' })))
    .addSubcommand(sub => sub
      .setName('leave')
      .setDescription('Configure leave messages')
      .addChannelOption(o => o.setName('channel').setDescription('Leave channel').setRequired(true))
      .addStringOption(o => o.setName('message').setDescription('Leave message ({username}, {server})').setRequired(false)))
    .addSubcommand(sub => sub
      .setName('disable')
      .setDescription('Disable welcome or leave messages')
      .addStringOption(o => o.setName('type').setDescription('Which to disable').setRequired(true)
        .addChoices({ name: 'Welcome', value: 'welcome' }, { name: 'Leave', value: 'leave' }, { name: 'Both', value: 'both' })))
    .addSubcommand(sub => sub.setName('test').setDescription('Send a test welcome/leave message'))
    .addSubcommand(sub => sub.setName('status').setDescription('View current welcome/leave settings')),

  userPermissions: ['ManageGuild'],
  guildOnly: true,
  cooldown: 3,

  async execute(client, interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    let guildDoc = await Guild.findOneAndUpdate(
      { guildId: interaction.guild.id },
      {},
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    if (sub === 'setup') {
      const channel = interaction.options.getChannel('channel');
      const message = interaction.options.getString('message') || guildDoc.welcome.message;
      const type    = interaction.options.getString('type') || 'embed';

      guildDoc.channels.welcomeChannel = channel.id;
      guildDoc.welcome.enabled = true;
      guildDoc.welcome.message = message;
      guildDoc.welcome.type    = type;
      await guildDoc.save();

      return interaction.editReply({
        embeds: [successEmbed('Welcome Setup', `Welcome messages configured!\n**Channel:** ${channel}\n**Type:** ${type}\n**Message:** ${message}`)],
      });
    }

    if (sub === 'leave') {
      const channel = interaction.options.getChannel('channel');
      const message = interaction.options.getString('message') || guildDoc.leave.message;

      guildDoc.channels.leaveChannel = channel.id;
      guildDoc.leave.enabled = true;
      guildDoc.leave.message = message;
      await guildDoc.save();

      return interaction.editReply({
        embeds: [successEmbed('Leave Setup', `Leave messages configured!\n**Channel:** ${channel}\n**Message:** ${message}`)],
      });
    }

    if (sub === 'disable') {
      const type = interaction.options.getString('type');
      if (type === 'welcome' || type === 'both') guildDoc.welcome.enabled = false;
      if (type === 'leave' || type === 'both') guildDoc.leave.enabled = false;
      await guildDoc.save();
      return interaction.editReply({ embeds: [successEmbed('Disabled', `${type} messages have been disabled.`)] });
    }

    if (sub === 'test') {
      // Simulate a member join
      const event = require('../../events/guildMemberAdd');
      await event.execute(client, interaction.member);
      return interaction.editReply({ embeds: [successEmbed('Test Sent', 'A test welcome message has been sent.')] });
    }

    if (sub === 'status') {
      return interaction.editReply({
        embeds: [infoEmbed('Welcome Settings', `Settings for **${interaction.guild.name}**`, [
          { name: '📥 Welcome', value: guildDoc.welcome.enabled ? `✅ <#${guildDoc.channels.welcomeChannel}>` : '❌ Disabled', inline: true },
          { name: '📤 Leave',   value: guildDoc.leave.enabled   ? `✅ <#${guildDoc.channels.leaveChannel}>`   : '❌ Disabled', inline: true },
          { name: '📝 Welcome Message', value: guildDoc.welcome.message, inline: false },
          { name: '📝 Leave Message',   value: guildDoc.leave.message,   inline: false },
        ])],
      });
    }
  },
};
