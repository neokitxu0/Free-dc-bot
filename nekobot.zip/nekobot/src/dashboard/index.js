/**
 * NekoBot Dashboard REST API
 * Provides endpoints for a web dashboard to manage guilds, view stats, and configure the bot.
 * Secured via Discord OAuth2 + JWT tokens.
 */

const express = require('express');
const cors    = require('cors');
const jwt     = require('jsonwebtoken');
const axios   = require('axios');
const config  = require('../../config');
const logger  = require('../utils/logger');
const Guild   = require('../models/Guild');
const Economy = require('../models/Economy');
const Level   = require('../models/Level');
const Ticket  = require('../models/Ticket');
const Warn    = require('../models/Warn');

const app = express();

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.DASHBOARD_ORIGIN || '*',
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logger
app.use((req, _res, next) => {
  logger.debug(`[Dashboard] ${req.method} ${req.path}`);
  next();
});

// ─── Auth Middleware ──────────────────────────────────────────────────────────
function auth(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'No token provided' });

  try {
    req.user = jwt.verify(token, config.dashboard.jwtSecret);
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

function ownerOnly(req, res, next) {
  const { isOwner } = require('../utils/permissions');
  if (!isOwner(req.user.id)) return res.status(403).json({ error: 'Owner only' });
  next();
}

// ─── Health Check ─────────────────────────────────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', uptime: process.uptime() });
});

// ─── OAuth2 — Get Auth URL ────────────────────────────────────────────────────
app.get('/auth/url', (_req, res) => {
  const params = new URLSearchParams({
    client_id:    config.dashboard.clientId,
    redirect_uri: config.dashboard.redirectUri,
    response_type:'code',
    scope:        'identify guilds',
  });
  res.json({ url: `https://discord.com/oauth2/authorize?${params}` });
});

// ─── OAuth2 — Exchange Code for Token ────────────────────────────────────────
app.post('/auth/callback', async (req, res) => {
  const { code } = req.body;
  if (!code) return res.status(400).json({ error: 'No code provided' });

  try {
    // Exchange code for Discord access token
    const tokenRes = await axios.post('https://discord.com/api/oauth2/token',
      new URLSearchParams({
        client_id:     config.dashboard.clientId,
        client_secret: config.dashboard.clientSecret,
        grant_type:    'authorization_code',
        code,
        redirect_uri:  config.dashboard.redirectUri,
      }),
      { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
    );

    const discordToken = tokenRes.data.access_token;

    // Fetch Discord user
    const userRes = await axios.get('https://discord.com/api/users/@me', {
      headers: { Authorization: `Bearer ${discordToken}` },
    });
    const user = userRes.data;

    // Issue JWT
    const jwtToken = jwt.sign(
      { id: user.id, username: user.username, avatar: user.avatar },
      config.dashboard.jwtSecret,
      { expiresIn: config.dashboard.jwtExpiry }
    );

    res.json({ token: jwtToken, user: { id: user.id, username: user.username, avatar: user.avatar } });
  } catch (err) {
    logger.error(`[Dashboard/auth] ${err.message}`);
    res.status(500).json({ error: 'Authentication failed' });
  }
});

// ─── GET /api/me — Current user info ────────────────────────────────────────
app.get('/api/me', auth, (req, res) => {
  res.json({ user: req.user });
});

// ─── GET /api/stats — Global bot stats ──────────────────────────────────────
app.get('/api/stats', auth, async (req, res) => {
  try {
    // client is attached when start() is called
    const client = app.locals.client;
    res.json({
      guilds:   client.guilds.cache.size,
      users:    client.users.cache.size,
      commands: client.commands.size,
      uptime:   process.uptime(),
      ping:     client.ws.ping,
      memory:   (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2) + ' MB',
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── GET /api/guilds — Guilds the user manages (mutual with bot) ─────────────
app.get('/api/guilds', auth, async (req, res) => {
  // For full implementation, pass the Discord OAuth access token from client
  // and fetch /users/@me/guilds from Discord, filter by MANAGE_GUILD permission & bot presence.
  // This simplified version returns all bot guilds (suitable for owner dashboard).
  const client = app.locals.client;
  const guilds = client.guilds.cache.map(g => ({
    id:   g.id,
    name: g.name,
    icon: g.iconURL({ dynamic: true }),
    members: g.memberCount,
  }));
  res.json({ guilds });
});

// ─── GET /api/guilds/:id — Single guild config ────────────────────────────────
app.get('/api/guilds/:id', auth, async (req, res) => {
  const guildDoc = await Guild.findOne({ guildId: req.params.id }).lean();
  if (!guildDoc) return res.status(404).json({ error: 'Guild not found' });
  res.json(guildDoc);
});

// ─── PATCH /api/guilds/:id — Update guild config ─────────────────────────────
app.patch('/api/guilds/:id', auth, async (req, res) => {
  const allowed = ['prefix', 'welcome', 'leave', 'automod', 'logging', 'leveling', 'security'];
  const update  = {};

  for (const key of allowed) {
    if (req.body[key] !== undefined) update[key] = req.body[key];
  }

  const guildDoc = await Guild.findOneAndUpdate(
    { guildId: req.params.id },
    { $set: update },
    { new: true, upsert: true }
  ).lean();

  res.json(guildDoc);
});

// ─── GET /api/guilds/:id/economy — Economy leaderboard ───────────────────────
app.get('/api/guilds/:id/economy', auth, async (req, res) => {
  const top = await Economy.find({ guildId: req.params.id }).sort({ wallet: -1 }).limit(50).lean();
  res.json({ leaderboard: top });
});

// ─── GET /api/guilds/:id/levels — Level leaderboard ──────────────────────────
app.get('/api/guilds/:id/levels', auth, async (req, res) => {
  const top = await Level.find({ guildId: req.params.id }).sort({ totalXp: -1 }).limit(50).lean();
  res.json({ leaderboard: top });
});

// ─── GET /api/guilds/:id/tickets — Ticket list ───────────────────────────────
app.get('/api/guilds/:id/tickets', auth, async (req, res) => {
  const tickets = await Ticket.find({ guildId: req.params.id }).sort({ createdAt: -1 }).limit(50).lean();
  res.json({ tickets });
});

// ─── GET /api/guilds/:id/warns/:userId — User warnings ───────────────────────
app.get('/api/guilds/:id/warns/:userId', auth, async (req, res) => {
  const warns = await Warn.find({ guildId: req.params.id, userId: req.params.userId }).lean();
  res.json({ warns });
});

// ─── Owner-only: GET /api/owner/guilds — All guilds ──────────────────────────
app.get('/api/owner/guilds', auth, ownerOnly, async (_req, res) => {
  const docs = await Guild.find().lean();
  res.json({ guilds: docs });
});

// ─── 404 Handler ─────────────────────────────────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// ─── Error Handler ────────────────────────────────────────────────────────────
app.use((err, _req, res, _next) => {
  logger.error(`[Dashboard] Unhandled error: ${err.message}`);
  res.status(500).json({ error: 'Internal server error' });
});

// ─── Start ────────────────────────────────────────────────────────────────────
function start(client) {
  app.locals.client = client;
  app.listen(config.dashboard.port, () => {
    logger.info(`[Dashboard] API listening on port ${config.dashboard.port}`);
  });
}

module.exports = { start };
