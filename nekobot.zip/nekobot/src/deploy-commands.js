/**
 * Deploy Slash Commands
 * Run this script once to register / update slash commands with Discord.
 *
 * Usage:
 *   node src/deploy-commands.js          — deploy globally (takes up to 1h to propagate)
 *   GUILD_ID=123 node src/deploy-commands.js  — deploy to a single guild instantly
 */

require('dotenv').config();

const { REST, Routes } = require('discord.js');
const fs   = require('fs');
const path = require('path');
const logger = require('./utils/logger');

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const categories = fs.readdirSync(commandsPath);

for (const category of categories) {
  const categoryPath = path.join(commandsPath, category);
  if (!fs.statSync(categoryPath).isDirectory()) continue;

  const files = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'));
  for (const file of files) {
    try {
      const command = require(path.join(categoryPath, file));
      if (command?.data) commands.push(command.data.toJSON());
    } catch (err) {
      logger.warn(`Skipping ${file}: ${err.message}`);
    }
  }
}

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
const clientId = process.env.DISCORD_CLIENT_ID;
const guildId  = process.env.GUILD_ID;

(async () => {
  try {
    logger.info(`Deploying ${commands.length} commands...`);

    if (guildId) {
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
      logger.info(`✅ Deployed ${commands.length} commands to guild ${guildId}`);
    } else {
      await rest.put(Routes.applicationCommands(clientId), { body: commands });
      logger.info(`✅ Deployed ${commands.length} commands globally`);
    }
  } catch (err) {
    logger.error(`Failed to deploy: ${err.message}`);
    process.exit(1);
  }
})();
