/**
 * AI Channel Message Handler
 * When a non-bot message is sent in the configured AI channel,
 * NekoBot auto-replies using OpenAI.
 */

const Guild  = require('../models/Guild');
const User   = require('../models/User');
const config = require('../../config');
const logger = require('../utils/logger');
const { aiEmbed } = require('../utils/embed');

module.exports = {
  name: 'messageCreate',
  once: false,

  async execute(client, message) {
    if (message.author.bot || !message.guild) return;

    try {
      const guildDoc = await Guild.findOne({ guildId: message.guild.id });
      if (!guildDoc?.channels?.aiChannel) return;
      if (message.channelId !== guildDoc.channels.aiChannel) return;
      if (!process.env.OPENAI_API_KEY) return;

      // Show typing indicator
      await message.channel.sendTyping();

      let userDoc = await User.findOne({ userId: message.author.id });
      if (!userDoc) userDoc = await User.create({ userId: message.author.id, username: message.author.tag });

      const recentMemory = userDoc.aiMemory.slice(-config.ai.conversationMemoryLength);

      const OpenAI = require('openai');
      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

      const response = await openai.chat.completions.create({
        model: config.ai.model,
        messages: [
          { role: 'system', content: config.ai.systemPrompt },
          ...recentMemory.map(m => ({ role: m.role, content: m.content })),
          { role: 'user', content: message.content },
        ],
        max_tokens: config.ai.maxTokens,
        temperature: 0.8,
      });

      const reply = response.choices[0]?.message?.content;
      if (!reply) return;

      // Update memory
      userDoc.aiMemory.push({ role: 'user', content: message.content });
      userDoc.aiMemory.push({ role: 'assistant', content: reply });
      if (userDoc.aiMemory.length > config.ai.conversationMemoryLength * 2) {
        userDoc.aiMemory = userDoc.aiMemory.slice(-config.ai.conversationMemoryLength * 2);
      }
      await userDoc.save();

      await message.reply({ embeds: [aiEmbed(reply.slice(0, 4096))] });
    } catch (err) {
      if (err.code !== 50013) { // Ignore missing permissions
        logger.error(`[aiMessageHandler] ${err.message}`);
      }
    }
  },
};
