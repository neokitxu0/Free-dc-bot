/**
 * Channel Delete Event — Security & Logging
 */

const Guild  = require('../models/Guild');
const logger = require('../utils/logger');
const { EmbedBuilder, AuditLogEvent } = require('discord.js');

module.exports = {
  name: 'channelDelete',
  once: false,

  async execute(client, channel) {
    if (!channel.guild) return;

    try {
      const guildDoc = await Guild.findOne({ guildId: channel.guild.id });
      if (!guildDoc) return;

      // ── Anti-Nuke / Anti-Channel-Delete ───────────────────────────────────
      if (guildDoc.security?.antiChannelDelete || guildDoc.security?.antiNuke) {
        // Fetch audit log to find who deleted the channel
        await new Promise(r => setTimeout(r, 500)); // small delay for audit log propagation
        const logs = await channel.guild.fetchAuditLogs({ type: AuditLogEvent.ChannelDelete, limit: 1 }).catch(() => null);
        const entry = logs?.entries.first();

        if (entry && entry.executor && !guildDoc.security.whitelist?.includes(entry.executor.id)) {
          const { isOwner } = require('../utils/permissions');
          if (!isOwner(entry.executor.id)) {
            // Recreate the channel
            await channel.guild.channels.create({
              name: channel.name,
              type: channel.type,
              parent: channel.parentId,
              permissionOverwrites: channel.permissionOverwrites.cache.toJSON(),
              reason: 'Anti-Nuke: Channel recreation',
            }).catch(() => {});

            // Punish the offender
            const member = await channel.guild.members.fetch(entry.executor.id).catch(() => null);
            if (member) await member.ban({ reason: 'Anti-Nuke: Mass channel deletion' }).catch(() => {});
          }
        }
      }

      // ── Channel Log ───────────────────────────────────────────────────────
      if (guildDoc.logging?.channelChanges && guildDoc.channels?.channelLog) {
        const logCh = channel.guild.channels.cache.get(guildDoc.channels.channelLog);
        if (logCh) {
          const embed = new EmbedBuilder()
            .setColor(0xE74C3C)
            .setTitle('🗑️ Channel Deleted')
            .addFields(
              { name: 'Name', value: channel.name, inline: true },
              { name: 'Type', value: channel.type.toString(), inline: true },
              { name: 'ID', value: channel.id, inline: true },
            )
            .setTimestamp();
          await logCh.send({ embeds: [embed] });
        }
      }
    } catch (err) {
      logger.error(`[channelDelete] ${err.message}`);
    }
  },
};
