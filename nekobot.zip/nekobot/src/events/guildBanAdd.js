/**
 * Guild Ban Add Event — Security (Anti-Ban) & Logging
 */

const Guild  = require('../models/Guild');
const logger = require('../utils/logger');
const { EmbedBuilder, AuditLogEvent } = require('discord.js');

module.exports = {
  name: 'guildBanAdd',
  once: false,

  async execute(client, ban) {
    const { guild, user } = ban;

    try {
      const guildDoc = await Guild.findOne({ guildId: guild.id });
      if (!guildDoc) return;

      await new Promise(r => setTimeout(r, 500));
      const logs = await guild.fetchAuditLogs({ type: AuditLogEvent.MemberBanAdd, limit: 1 }).catch(() => null);
      const entry = logs?.entries.first();
      const executor = entry?.executor;

      // ── Anti-Ban ──────────────────────────────────────────────────────────
      if (guildDoc.security?.antiBan && executor) {
        const { isOwner } = require('../utils/permissions');
        const whitelisted = guildDoc.security.whitelist?.includes(executor.id)
          || isOwner(executor.id)
          || executor.id === client.user.id;

        if (!whitelisted) {
          // Unban the victim
          await guild.bans.remove(user.id, 'Anti-Ban: unauthorized ban').catch(() => {});
          // Ban the executor
          const member = await guild.members.fetch(executor.id).catch(() => null);
          if (member) await member.ban({ reason: 'Anti-Nuke: Unauthorized mass ban' }).catch(() => {});
        }
      }

      // ── Ban Log ────────────────────────────────────────────────────────────
      if (guildDoc.logging?.bans && guildDoc.channels?.modLog) {
        const logCh = guild.channels.cache.get(guildDoc.channels.modLog);
        if (logCh) {
          const embed = new EmbedBuilder()
            .setColor(0xE74C3C)
            .setTitle('🔨 Member Banned')
            .addFields(
              { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
              { name: 'Moderator', value: executor ? `${executor.tag}` : 'Unknown', inline: true },
              { name: 'Reason', value: entry?.reason || 'No reason provided', inline: false },
            )
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setTimestamp();
          await logCh.send({ embeds: [embed] });
        }
      }
    } catch (err) {
      logger.error(`[guildBanAdd] ${err.message}`);
    }
  },
};
