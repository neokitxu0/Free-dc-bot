/**
 * Guild Member Add Event
 * Handles welcome messages, auto-roles, and anti-raid.
 */

const Guild = require('../models/Guild');
const { checkAntiRaid } = require('../utils/antiSpam');
const logger = require('../utils/logger');

module.exports = {
  name: 'guildMemberAdd',
  once: false,

  async execute(client, member) {
    const { guild } = member;

    try {
      const guildDoc = await Guild.findOne({ guildId: guild.id });
      if (!guildDoc) return;

      // ── Anti-Raid ──────────────────────────────────────────────────────────
      if (guildDoc.automod?.antiRaid) {
        await checkAntiRaid(guild, member);
      }

      // ── Anti-Bot ───────────────────────────────────────────────────────────
      if (guildDoc.automod?.antiBot && member.user.bot) {
        await member.kick('Anti-Bot: Bot joined without whitelist').catch(() => {});
        return;
      }

      // ── Auto Role ──────────────────────────────────────────────────────────
      if (guildDoc.roles?.autoRole?.length) {
        for (const roleId of guildDoc.roles.autoRole) {
          const role = guild.roles.cache.get(roleId);
          if (role) await member.roles.add(role).catch(() => {});
        }
      }

      // ── Welcome Message ────────────────────────────────────────────────────
      if (guildDoc.welcome?.enabled && guildDoc.channels?.welcomeChannel) {
        const channel = guild.channels.cache.get(guildDoc.channels.welcomeChannel);
        if (!channel) return;

        const memberCount = guild.memberCount;
        let message = guildDoc.welcome.message
          .replace(/{user}/g, member.toString())
          .replace(/{username}/g, member.user.username)
          .replace(/{server}/g, guild.name)
          .replace(/{count}/g, memberCount.toLocaleString());

        if (guildDoc.welcome.type === 'embed') {
          const { EmbedBuilder } = require('discord.js');
          const embed = new EmbedBuilder()
            .setColor(guildDoc.welcome.embedColor || '#9B59B6')
            .setTitle(`Welcome to ${guild.name}!`)
            .setDescription(message)
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
            .setFooter({ text: `Member #${memberCount}` })
            .setTimestamp();
          await channel.send({ embeds: [embed] });
        } else {
          await channel.send({ content: message });
        }
      }

      // ── Member Log ─────────────────────────────────────────────────────────
      if (guildDoc.logging?.memberJoin && guildDoc.channels?.memberLog) {
        const logCh = guild.channels.cache.get(guildDoc.channels.memberLog);
        if (logCh) {
          const { EmbedBuilder } = require('discord.js');
          const embed = new EmbedBuilder()
            .setColor(0x2ECC71)
            .setTitle('📥 Member Joined')
            .setDescription(`${member} (${member.user.tag})`)
            .addFields(
              { name: 'ID', value: member.id, inline: true },
              { name: 'Account Created', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true },
            )
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .setTimestamp();
          await logCh.send({ embeds: [embed] });
        }
      }
    } catch (err) {
      logger.error(`[guildMemberAdd] ${err.message}`);
    }
  },
};
