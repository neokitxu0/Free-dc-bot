/**
 * Guild Member Remove Event
 * Handles leave messages and member leave logs.
 */

const Guild  = require('../models/Guild');
const logger = require('../utils/logger');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'guildMemberRemove',
  once: false,

  async execute(client, member) {
    const { guild } = member;

    try {
      const guildDoc = await Guild.findOne({ guildId: guild.id });
      if (!guildDoc) return;

      // ── Leave Message ──────────────────────────────────────────────────────
      if (guildDoc.leave?.enabled && guildDoc.channels?.leaveChannel) {
        const channel = guild.channels.cache.get(guildDoc.channels.leaveChannel);
        if (channel) {
          let message = guildDoc.leave.message
            .replace(/{user}/g, member.toString())
            .replace(/{username}/g, member.user.username)
            .replace(/{server}/g, guild.name);
          await channel.send({ content: message }).catch(() => {});
        }
      }

      // ── Member Log ─────────────────────────────────────────────────────────
      if (guildDoc.logging?.memberLeave && guildDoc.channels?.memberLog) {
        const logCh = guild.channels.cache.get(guildDoc.channels.memberLog);
        if (logCh) {
          const embed = new EmbedBuilder()
            .setColor(0xE74C3C)
            .setTitle('📤 Member Left')
            .setDescription(`${member.user.tag}`)
            .addFields(
              { name: 'ID', value: member.id, inline: true },
              { name: 'Joined', value: member.joinedAt ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'Unknown', inline: true },
              { name: 'Roles', value: member.roles.cache.filter(r => r.id !== guild.id).map(r => r.toString()).join(', ') || 'None', inline: false },
            )
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .setTimestamp();
          await logCh.send({ embeds: [embed] });
        }
      }
    } catch (err) {
      logger.error(`[guildMemberRemove] ${err.message}`);
    }
  },
};
