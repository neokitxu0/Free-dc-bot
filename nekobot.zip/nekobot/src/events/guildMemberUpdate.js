/**
 * Guild Member Update Event — Role/Nickname logging
 */

const Guild  = require('../models/Guild');
const logger = require('../utils/logger');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'guildMemberUpdate',
  once: false,

  async execute(client, oldMember, newMember) {
    if (!newMember.guild) return;

    try {
      const guildDoc = await Guild.findOne({ guildId: newMember.guild.id });
      if (!guildDoc?.logging?.roleChanges || !guildDoc?.channels?.memberLog) return;

      const logCh = newMember.guild.channels.cache.get(guildDoc.channels.memberLog);
      if (!logCh) return;

      const oldRoles = oldMember.roles.cache;
      const newRoles = newMember.roles.cache;

      const added   = newRoles.filter(r => !oldRoles.has(r.id));
      const removed = oldRoles.filter(r => !newRoles.has(r.id));
      const nickChanged = oldMember.nickname !== newMember.nickname;

      if (!added.size && !removed.size && !nickChanged) return;

      const embed = new EmbedBuilder()
        .setColor(0x3498DB)
        .setTitle('👤 Member Updated')
        .setDescription(`${newMember.user.tag} (${newMember.id})`)
        .setTimestamp();

      if (added.size)   embed.addFields({ name: '✅ Roles Added', value: added.map(r => r.toString()).join(', ') });
      if (removed.size) embed.addFields({ name: '❌ Roles Removed', value: removed.map(r => r.toString()).join(', ') });
      if (nickChanged)  embed.addFields({
        name: '✏️ Nickname Changed',
        value: `**Before:** ${oldMember.nickname || '*None*'}\n**After:** ${newMember.nickname || '*None*'}`,
      });

      await logCh.send({ embeds: [embed] });
    } catch (err) {
      logger.error(`[guildMemberUpdate] ${err.message}`);
    }
  },
};
