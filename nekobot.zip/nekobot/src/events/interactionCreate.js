/**
 * Interaction Create Event
 * Routes all interaction types to their appropriate handlers.
 */

const logger = require('../utils/logger');
const { errorEmbed } = require('../utils/embed');
const { validateCommandPermissions, isBlacklisted } = require('../utils/permissions');
const { handleButton }     = require('../handlers/buttonHandler');
const { handleSelectMenu } = require('../handlers/selectMenuHandler');
const { handleModal }      = require('../handlers/modalHandler');
const Guild = require('../models/Guild');

module.exports = {
  name: 'interactionCreate',
  once: false,

  async execute(client, interaction) {
    // ── Buttons ──────────────────────────────────────────────────────────────
    if (interaction.isButton()) {
      return handleButton(client, interaction);
    }

    // ── Select Menus ─────────────────────────────────────────────────────────
    if (interaction.isAnySelectMenu()) {
      return handleSelectMenu(client, interaction);
    }

    // ── Modals ───────────────────────────────────────────────────────────────
    if (interaction.isModalSubmit()) {
      return handleModal(client, interaction);
    }

    // ── Slash Commands ───────────────────────────────────────────────────────
    if (!interaction.isChatInputCommand() && !interaction.isContextMenuCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    // Global blacklist check
    const blacklisted = await isBlacklisted(interaction.user.id);
    if (blacklisted) {
      return interaction.reply({
        embeds: [errorEmbed('Blacklisted', 'You have been blacklisted from using this bot.')],
        ephemeral: true,
      });
    }

    // Maintenance mode check (owner can bypass)
    const { isOwner } = require('../utils/permissions');
    if (!isOwner(interaction.user.id) && interaction.guild) {
      const guildDoc = await Guild.findOne({ guildId: interaction.guild.id });
      if (guildDoc?.maintenance) {
        return interaction.reply({
          embeds: [errorEmbed('Maintenance', '🔧 The bot is currently under maintenance. Please try again later.')],
          ephemeral: true,
        });
      }
    }

    // Permission validation
    const permCheck = validateCommandPermissions(interaction, command);
    if (!permCheck.allowed) {
      return interaction.reply({
        embeds: [errorEmbed('Missing Permissions', permCheck.reason)],
        ephemeral: true,
      });
    }

    // Cooldown check
    const { cooldowns } = client;
    if (!cooldowns.has(command.data.name)) cooldowns.set(command.data.name, new Map());
    const now = Date.now();
    const timestamps = cooldowns.get(command.data.name);
    const cooldownAmount = (command.cooldown || 3) * 1000;

    if (timestamps.has(interaction.user.id)) {
      const expiry = timestamps.get(interaction.user.id) + cooldownAmount;
      if (now < expiry) {
        const remaining = ((expiry - now) / 1000).toFixed(1);
        return interaction.reply({
          embeds: [errorEmbed('Cooldown', `⏳ Please wait **${remaining}s** before using \`/${command.data.name}\` again.`)],
          ephemeral: true,
        });
      }
    }
    timestamps.set(interaction.user.id, now);
    setTimeout(() => timestamps.delete(interaction.user.id), cooldownAmount);

    // Execute
    try {
      await command.execute(client, interaction);
    } catch (err) {
      logger.error(`[Command/${interaction.commandName}] ${err.stack}`);
      const errReply = {
        embeds: [errorEmbed('Error', `An unexpected error occurred.\n\`\`\`${err.message}\`\`\``)],
        ephemeral: true,
      };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(errReply).catch(() => {});
      } else {
        await interaction.reply(errReply).catch(() => {});
      }
    }
  },
};
