/**
 * Message Create Event
 * Handles prefix commands, XP gain, and automod.
 */

const { checkAntiSpam, checkAntiLink, checkAntiBadWords, checkAntiMentionSpam } = require('../utils/antiSpam');
const { addXp, handleLevelRewards } = require('../utils/level');
const Guild = require('../models/Guild');
const config = require('../../config');
const { randInt } = require('../utils/economy');
const logger = require('../utils/logger');

module.exports = {
  name: 'messageCreate',
  once: false,

  async execute(client, message) {
    if (message.author.bot || !message.guild) return;

    // ── AutoMod ───────────────────────────────────────────────────────────────
    try {
      // Check automod in parallel for performance
      const [spam, link, badWord, mention] = await Promise.all([
        checkAntiSpam(message),
        checkAntiLink(message),
        checkAntiBadWords(message),
        checkAntiMentionSpam(message),
      ]);

      // If message was deleted by automod, stop processing
      if (link || badWord) return;
    } catch (err) {
      logger.error(`[AutoMod] ${err.message}`);
    }

    // ── XP / Leveling ─────────────────────────────────────────────────────────
    try {
      const guildDoc = await Guild.findOne({ guildId: message.guild.id });
      const levelingEnabled = guildDoc?.leveling?.enabled !== false;

      if (levelingEnabled) {
        // Skip if channel or role is excluded
        const noXpChannels = guildDoc?.leveling?.noXpChannels || [];
        const noXpRoles    = guildDoc?.leveling?.noXpRoles || [];
        const memberRoles  = message.member.roles.cache.map(r => r.id);

        const skip = noXpChannels.includes(message.channelId)
          || noXpRoles.some(r => memberRoles.includes(r));

        if (!skip) {
          const xpGain = randInt(config.leveling.xpPerMessage.min, config.leveling.xpPerMessage.max);
          const { leveled, newLevel } = await addXp(message.author.id, message.guild.id, xpGain);

          if (leveled) {
            await handleLevelRewards(message.guild, message.member, newLevel);

            if (guildDoc?.leveling?.levelUpMsg !== false) {
              const levelUpChannel = guildDoc?.channels?.levelUpChannel
                ? message.guild.channels.cache.get(guildDoc.channels.levelUpChannel)
                : message.channel;

              if (levelUpChannel) {
                await levelUpChannel.send({
                  content: `🎉 GG ${message.author}! You leveled up to **Level ${newLevel}**!`,
                }).catch(() => {});
              }
            }
          }
        }
      }
    } catch (err) {
      logger.error(`[Leveling] ${err.message}`);
    }

    // ── Prefix Commands (legacy support) ─────────────────────────────────────
    const guildPrefix = config.prefix; // TODO: load per-guild prefix from DB
    if (!message.content.startsWith(guildPrefix)) return;

    // Prefix commands are deprecated in favor of slash commands.
    // This block handles the .help fallback.
    const args = message.content.slice(guildPrefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    if (commandName === 'help') {
      const categories = [...new Set(client.commands.map(c => c.category))];
      const embed = require('../utils/embed').infoEmbed(
        `${config.botName} Help`,
        `Use slash commands \`/\` for full functionality!\n\n**Categories:** ${categories.map(c => `\`${c}\``).join(', ')}`,
      );
      await message.reply({ embeds: [embed] }).catch(() => {});
    }
  },
};
