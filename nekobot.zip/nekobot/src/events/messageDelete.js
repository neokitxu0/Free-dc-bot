/**
 * Message Delete Event — Logging
 */

const Guild  = require('../models/Guild');
const logger = require('../utils/logger');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'messageDelete',
  once: false,

  async execute(client, message) {
    if (!message.guild || message.author?.bot) return;

    try {
      const guildDoc = await Guild.findOne({ guildId: message.guild.id });
      if (!guildDoc?.logging?.messageDelete || !guildDoc?.channels?.messageLog) return;

      const logCh = message.guild.channels.cache.get(guildDoc.channels.messageLog);
      if (!logCh) return;

      const embed = new EmbedBuilder()
        .setColor(0xE74C3C)
        .setTitle('🗑️ Message Deleted')
        .addFields(
          { name: 'Author', value: message.author ? `${message.author.tag} (${message.author.id})` : 'Unknown', inline: true },
          { name: 'Channel', value: `<#${message.channelId}>`, inline: true },
          { name: 'Content', value: message.content?.slice(0, 1000) || '*[No text content]*', inline: false },
        )
        .setTimestamp();

      if (message.attachments?.size > 0) {
        embed.addFields({ name: 'Attachments', value: message.attachments.map(a => a.url).join('\n').slice(0, 500) });
      }

      await logCh.send({ embeds: [embed] });
    } catch (err) {
      logger.error(`[messageDelete] ${err.message}`);
    }
  },
};
