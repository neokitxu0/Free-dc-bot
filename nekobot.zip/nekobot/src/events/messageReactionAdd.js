/**
 * Message Reaction Add — handles reaction roles.
 */

const { handleReactionRole } = require('../commands/autorole/reactionrole');
const logger = require('../utils/logger');

module.exports = {
  name: 'messageReactionAdd',
  once: false,

  async execute(client, reaction, user) {
    // Fetch partial reaction/message if needed
    if (reaction.partial) {
      try { await reaction.fetch(); } catch { return; }
    }
    if (reaction.message.partial) {
      try { await reaction.message.fetch(); } catch { return; }
    }

    try {
      await handleReactionRole(reaction, user, true);
    } catch (err) {
      logger.error(`[messageReactionAdd] ${err.message}`);
    }
  },
};
