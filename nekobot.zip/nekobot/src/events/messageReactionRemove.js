/**
 * Message Reaction Remove — handles reaction role removal.
 */

const { handleReactionRole } = require('../commands/autorole/reactionrole');
const logger = require('../utils/logger');

module.exports = {
  name: 'messageReactionRemove',
  once: false,

  async execute(client, reaction, user) {
    if (reaction.partial) {
      try { await reaction.fetch(); } catch { return; }
    }
    if (reaction.message.partial) {
      try { await reaction.message.fetch(); } catch { return; }
    }

    try {
      await handleReactionRole(reaction, user, false);
    } catch (err) {
      logger.error(`[messageReactionRemove] ${err.message}`);
    }
  },
};
