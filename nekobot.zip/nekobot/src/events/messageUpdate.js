/**
 * Message Update Event — Edit Logging
 */

const Guild  = require('../models/Guild');
const logger = require('../utils/logger');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'messageUpdate',
  once: false,

  async execute(client, oldMessage, newMessage) {
    if (!newMessage.guild || newMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return; // ignore embed-only updates

    try {
      const guildDoc = await Guild.findOne({ guildId: newMessage.guild.id });
      if (!guildDoc?.logging?.messageEdit || !guildDoc?.channels?.messageLog) return;

      const logCh = newMessage.guild.channels.cache.get(guildDoc.channels.messageLog);
      if (!logCh) return;

      const embed = new EmbedBuilder()
        .setColor(0xF39C12)
        .setTitle('✏️ Message Edited')
        .setURL(newMessage.url)
        .addFields(
          { name: 'Author', value: `${newMessage.author.tag} (${newMessage.author.id})`, inline: true },
          { name: 'Channel', value: `<#${newMessage.channelId}>`, inline: true },
          { name: 'Before', value: oldMessage.content?.slice(0, 500) || '*Unknown*', inline: false },
          { name: 'After', value: newMessage.content?.slice(0, 500) || '*Empty*', inline: false },
        )
        .setTimestamp();

      await logCh.send({ embeds: [embed] });
    } catch (err) {
      logger.error(`[messageUpdate] ${err.message}`);
    }
  },
};
