/**
 * Ready Event
 * Fires once when the bot successfully connects to Discord.
 */

const logger = require('../utils/logger');
const config = require('../../config');

module.exports = {
  name: 'ready',
  once: true,

  async execute(client) {
    logger.info('═══════════════════════════════════════════');
    logger.info(`  🐱 ${client.user.tag} is online!`);
    logger.info(`  📡 Serving ${client.guilds.cache.size} guilds`);
    logger.info(`  👥 ${client.users.cache.size} users cached`);
    logger.info(`  📝 ${client.commands.size} slash commands loaded`);
    logger.info('═══════════════════════════════════════════');

    // Set initial presence
    client.user.setPresence({
      status: config.presence.status,
      activities: [{ name: config.presence.activities[0].name, type: config.presence.activities[0].type }],
    });
  },
};
