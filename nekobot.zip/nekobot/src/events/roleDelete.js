/**
 * Role Delete Event — Security & Logging
 */

const Guild  = require('../models/Guild');
const logger = require('../utils/logger');
const { EmbedBuilder, AuditLogEvent, PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'roleDelete',
  once: false,

  async execute(client, role) {
    if (!role.guild) return;

    try {
      const guildDoc = await Guild.findOne({ guildId: role.guild.id });
      if (!guildDoc) return;

      // ── Anti-Role-Delete / Anti-Nuke ─────────────────────────────────────
      if (guildDoc.security?.antiRoleDelete || guildDoc.security?.antiNuke) {
        await new Promise(r => setTimeout(r, 500));
        const logs = await role.guild.fetchAuditLogs({ type: AuditLogEvent.RoleDelete, limit: 1 }).catch(() => null);
        const entry = logs?.entries.first();

        if (entry?.executor && !guildDoc.security.whitelist?.includes(entry.executor.id)) {
          const { isOwner } = require('../utils/permissions');
          if (!isOwner(entry.executor.id)) {
            // Recreate the role
            await role.guild.roles.create({
              name: role.name,
              color: role.color,
              hoist: role.hoist,
              mentionable: role.mentionable,
              permissions: role.permissions,
              reason: 'Anti-Nuke: Role recreation',
            }).catch(() => {});

            const member = await role.guild.members.fetch(entry.executor.id).catch(() => null);
            if (member) await member.ban({ reason: 'Anti-Nuke: Mass role deletion' }).catch(() => {});
          }
        }
      }

      // ── Role Log ──────────────────────────────────────────────────────────
      if (guildDoc.logging?.roleChanges && guildDoc.channels?.roleLog) {
        const logCh = role.guild.channels.cache.get(guildDoc.channels.roleLog);
        if (logCh) {
          const embed = new EmbedBuilder()
            .setColor(0xE74C3C)
            .setTitle('🗑️ Role Deleted')
            .addFields(
              { name: 'Name', value: role.name, inline: true },
              { name: 'ID', value: role.id, inline: true },
              { name: 'Color', value: role.hexColor, inline: true },
            )
            .setTimestamp();
          await logCh.send({ embeds: [embed] });
        }
      }
    } catch (err) {
      logger.error(`[roleDelete] ${err.message}`);
    }
  },
};
