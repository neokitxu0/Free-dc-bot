/**
 * Voice State Update Event — Voice logging
 */

const Guild  = require('../models/Guild');
const logger = require('../utils/logger');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'voiceStateUpdate',
  once: false,

  async execute(client, oldState, newState) {
    if (!newState.guild) return;

    try {
      const guildDoc = await Guild.findOne({ guildId: newState.guild.id });
      if (!guildDoc?.logging?.voiceState || !guildDoc?.channels?.voiceLog) return;

      const logCh = newState.guild.channels.cache.get(guildDoc.channels.voiceLog);
      if (!logCh) return;

      const member = newState.member || oldState.member;
      let action = '', color = 0x3498DB;

      if (!oldState.channelId && newState.channelId) {
        action = `📥 Joined **${newState.channel?.name}**`;
        color = 0x2ECC71;
      } else if (oldState.channelId && !newState.channelId) {
        action = `📤 Left **${oldState.channel?.name}**`;
        color = 0xE74C3C;
      } else if (oldState.channelId !== newState.channelId) {
        action = `🔀 Moved from **${oldState.channel?.name}** → **${newState.channel?.name}**`;
      } else if (oldState.mute !== newState.mute) {
        action = newState.mute ? '🔇 Server Muted' : '🔊 Server Unmuted';
      } else if (oldState.deaf !== newState.deaf) {
        action = newState.deaf ? '🙉 Server Deafened' : '👂 Server Undeafened';
      } else return;

      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle('🎙️ Voice State Update')
        .setDescription(`${member?.user.tag ?? 'Unknown'} — ${action}`)
        .setTimestamp();

      await logCh.send({ embeds: [embed] });
    } catch (err) {
      logger.error(`[voiceStateUpdate] ${err.message}`);
    }
  },
};
