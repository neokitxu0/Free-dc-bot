/**
 * Button Interaction Handler
 * Routes button interactions to the appropriate handler.
 * CustomId format: "handlerPrefix_data1_data2"
 */

const logger = require('../utils/logger');
const { errorEmbed } = require('../utils/embed');

// Import all button sub-handlers
const ticketButtons  = require('./buttons/ticketButtons');
const roleButtons    = require('./buttons/roleButtons');
const paginationBtns = require('./buttons/paginationButtons');
const confirmButtons = require('./buttons/confirmButtons');

// Route map: prefix → handler function(client, interaction)
const routes = {
  ticket:     ticketButtons.handle,
  role:       roleButtons.handle,
  page:       paginationBtns.handle,
  confirm:    confirmButtons.handle,
  cancel:     confirmButtons.handle,
};

async function handleButton(client, interaction) {
  if (!interaction.isButton()) return;

  const [prefix] = interaction.customId.split('_');

  const handler = routes[prefix];
  if (!handler) {
    logger.warn(`[ButtonHandler] No handler for prefix: ${prefix}`);
    return;
  }

  try {
    await handler(client, interaction);
  } catch (err) {
    logger.error(`[ButtonHandler] Error in ${interaction.customId}: ${err.message}`);
    const reply = { embeds: [errorEmbed('Error', 'Something went wrong processing this button.')], ephemeral: true };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(reply).catch(() => {});
    } else {
      await interaction.reply(reply).catch(() => {});
    }
  }
}

module.exports = { handleButton };
