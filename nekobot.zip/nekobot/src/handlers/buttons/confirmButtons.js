/**
 * Confirm/Cancel Button Handler
 * Used for destructive actions (nuke, ban, etc.)
 * CustomId: confirm_{action}_{data} or cancel_{action}_{data}
 */

const { successEmbed, errorEmbed } = require('../../utils/embed');

async function handle(client, interaction) {
  const parts = interaction.customId.split('_');
  const isConfirm = parts[0] === 'confirm';
  const action = parts[1];

  if (!isConfirm) {
    return interaction.update({
      embeds: [errorEmbed('Cancelled', 'Action has been cancelled.')],
      components: [],
    });
  }

  switch (action) {
    case 'nuke': {
      const channelId = parts[2];
      const channel = interaction.guild.channels.cache.get(channelId);
      if (!channel) return interaction.reply({ content: 'Channel not found.', ephemeral: true });

      const position = channel.position;
      const newChannel = await channel.clone({ reason: `Nuke by ${interaction.user.tag}` });
      await channel.delete(`Nuke by ${interaction.user.tag}`);
      await newChannel.setPosition(position);
      await newChannel.send({ embeds: [successEmbed('Channel Nuked', '💥 Channel has been nuked and recreated!')] });
      await interaction.update({ embeds: [successEmbed('Done', 'Channel nuked.')], components: [] });
      break;
    }
    default:
      await interaction.update({
        embeds: [errorEmbed('Unknown', 'Unknown action.')],
        components: [],
      });
  }
}

module.exports = { handle };
