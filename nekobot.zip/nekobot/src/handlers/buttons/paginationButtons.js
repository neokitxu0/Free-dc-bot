/**
 * Pagination Button Handler
 * Handles page_first, page_prev, page_next, page_last buttons.
 * These are stored in interaction.message.embeds[0] as JSON in footer.
 */

const { paginationRow } = require('../../utils/embed');

// In-memory pagination state: messageId → { pages: string[], current: number }
const paginationState = new Map();

function store(messageId, pages) {
  paginationState.set(messageId, { pages, current: 0 });
}

async function handle(client, interaction) {
  const state = paginationState.get(interaction.message.id);
  if (!state) {
    return interaction.reply({ content: 'This pagination session has expired.', ephemeral: true });
  }

  const action = interaction.customId; // page_first | page_prev | page_next | page_last
  const { pages } = state;
  let { current } = state;

  if (action === 'page_first') current = 0;
  else if (action === 'page_prev') current = Math.max(0, current - 1);
  else if (action === 'page_next') current = Math.min(pages.length - 1, current + 1);
  else if (action === 'page_last') current = pages.length - 1;

  state.current = current;

  await interaction.update({
    content: pages[current],
    components: [paginationRow(current, pages.length)],
  });
}

module.exports = { handle, store };
