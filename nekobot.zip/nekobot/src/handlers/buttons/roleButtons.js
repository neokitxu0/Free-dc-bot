/**
 * Role Button Handler
 * Handles button role toggle interactions.
 * CustomId: role_{roleId}
 */

const { successEmbed, errorEmbed } = require('../../utils/embed');

async function handle(client, interaction) {
  const roleId = interaction.customId.split('_')[1];
  if (!roleId) return;

  const role = interaction.guild.roles.cache.get(roleId);
  if (!role) {
    return interaction.reply({ embeds: [errorEmbed('Error', 'Role not found.')], ephemeral: true });
  }

  const member = interaction.member;
  const hasRole = member.roles.cache.has(roleId);

  try {
    if (hasRole) {
      await member.roles.remove(role);
      return interaction.reply({
        embeds: [successEmbed('Role Removed', `Removed **${role.name}** from you.`)],
        ephemeral: true,
      });
    } else {
      await member.roles.add(role);
      return interaction.reply({
        embeds: [successEmbed('Role Added', `Added **${role.name}** to you.`)],
        ephemeral: true,
      });
    }
  } catch (err) {
    return interaction.reply({
      embeds: [errorEmbed('Error', `Could not toggle role: ${err.message}`)],
      ephemeral: true,
    });
  }
}

module.exports = { handle };
