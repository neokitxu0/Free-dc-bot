/**
 * Ticket Button & Select Menu Handler
 */

const {
  ChannelType, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder,
  ButtonStyle, EmbedBuilder, StringSelectMenuBuilder, ModalBuilder,
  TextInputBuilder, TextInputStyle,
} = require('discord.js');
const Ticket = require('../../models/Ticket');
const Guild  = require('../../models/Guild');
const config = require('../../../config');
const { generateTranscript } = require('../../utils/transcript');
const { ticketEmbed, successEmbed, errorEmbed } = require('../../utils/embed');
const { nanoid } = require('nanoid').default ? require('nanoid') : { nanoid: () => Math.random().toString(36).slice(2,8) };
const logger = require('../../utils/logger');

async function handle(client, interaction) {
  const parts = interaction.customId.split('_'); // ticket_action_data
  const action = parts[1];

  switch (action) {
    case 'open':    return openTicketMenu(client, interaction);
    case 'close':   return closeTicket(client, interaction);
    case 'claim':   return claimTicket(client, interaction);
    case 'unclaim': return unclaimTicket(client, interaction);
    case 'delete':  return deleteTicket(client, interaction);
    default:
      logger.warn(`[TicketButtons] Unknown action: ${action}`);
  }
}

/** Show the ticket category select menu */
async function openTicketMenu(client, interaction) {
  const guildDoc = await Guild.findOne({ guildId: interaction.guild.id });
  const categories = guildDoc?.tickets?.categories?.length
    ? guildDoc.tickets.categories
    : config.tickets.categories;

  const menu = new StringSelectMenuBuilder()
    .setCustomId('ticket_create')
    .setPlaceholder('Select a ticket category...')
    .addOptions(categories.map(cat => ({
      label: cat.label,
      description: cat.description,
      value: cat.id,
      emoji: cat.emoji || '📋',
    })));

  return interaction.reply({
    embeds: [ticketEmbed('Create a Ticket', 'Please select the category that best fits your issue.')],
    components: [new ActionRowBuilder().addComponents(menu)],
    ephemeral: true,
  });
}

/** Create a ticket channel from select menu */
async function handleTicketCreate(client, interaction) {
  await interaction.deferReply({ ephemeral: true });

  const guildDoc = await Guild.findOne({ guildId: interaction.guild.id });
  const categoryId = interaction.values[0];

  // Check if user already has an open ticket
  const existing = await Ticket.findOne({
    guildId: interaction.guild.id,
    userId: interaction.user.id,
    status: { $in: ['open', 'claimed'] },
  });

  if (existing) {
    const ch = interaction.guild.channels.cache.get(existing.channelId);
    return interaction.editReply({
      embeds: [errorEmbed('Already Open', `You already have an open ticket: ${ch ? ch.toString() : 'unknown channel'}`)],
    });
  }

  // Increment counter
  guildDoc.tickets.counter = (guildDoc.tickets.counter || 0) + 1;
  await guildDoc.save();

  const ticketId = `ticket-${String(guildDoc.tickets.counter).padStart(4, '0')}`;

  // Permission overwrites
  const permOverwrites = [
    { id: interaction.guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
    {
      id: interaction.user.id,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    },
    {
      id: interaction.guild.members.me.id,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels],
    },
  ];

  // Add staff roles
  for (const roleId of guildDoc.tickets.staffRoles || []) {
    permOverwrites.push({
      id: roleId,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    });
  }

  const channel = await interaction.guild.channels.create({
    name: ticketId,
    type: ChannelType.GuildText,
    parent: guildDoc.tickets.categories.find(c => c.id === categoryId)?.categoryId || guildDoc.channels.ticketCategory || null,
    permissionOverwrites: permOverwrites,
    topic: `Ticket opened by ${interaction.user.tag} | Category: ${categoryId}`,
  });

  // Save to DB
  const ticket = await Ticket.create({
    ticketId,
    guildId: interaction.guild.id,
    channelId: channel.id,
    userId: interaction.user.id,
    category: categoryId,
  });

  // Send ticket embed
  const embed = ticketEmbed(
    `Ticket #${guildDoc.tickets.counter}`,
    `Welcome ${interaction.user}, our support team will be with you shortly.\n\n**Category:** ${categoryId}\n**Opened by:** ${interaction.user.tag}`,
  );

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_claim').setLabel('Claim').setEmoji('✋').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Close').setEmoji('🔒').setStyle(ButtonStyle.Danger),
  );

  await channel.send({ content: `${interaction.user} ${(guildDoc.tickets.staffRoles || []).map(r => `<@&${r}>`).join(' ')}`, embeds: [embed], components: [row] });

  // Log
  if (guildDoc.channels.ticketLog) {
    const logCh = interaction.guild.channels.cache.get(guildDoc.channels.ticketLog);
    if (logCh) {
      await logCh.send({
        embeds: [ticketEmbed('Ticket Opened', `**ID:** ${ticketId}\n**User:** ${interaction.user.tag}\n**Category:** ${categoryId}\n**Channel:** ${channel}`)],
      });
    }
  }

  return interaction.editReply({
    embeds: [successEmbed('Ticket Created', `Your ticket has been created: ${channel}`)],
  });
}

async function claimTicket(client, interaction) {
  const ticket = await Ticket.findOne({ channelId: interaction.channelId });
  if (!ticket) return interaction.reply({ content: 'This is not a ticket channel.', ephemeral: true });
  if (ticket.claimedBy) return interaction.reply({ content: `Already claimed by <@${ticket.claimedBy}>`, ephemeral: true });

  ticket.claimedBy = interaction.user.id;
  ticket.status = 'claimed';
  await ticket.save();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_unclaim').setLabel('Unclaim').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Close').setEmoji('🔒').setStyle(ButtonStyle.Danger),
  );

  await interaction.update({
    embeds: [ticketEmbed('Ticket Claimed', `This ticket has been claimed by ${interaction.user}`)],
    components: [row],
  });
}

async function unclaimTicket(client, interaction) {
  const ticket = await Ticket.findOne({ channelId: interaction.channelId });
  if (!ticket) return interaction.reply({ content: 'Not a ticket channel.', ephemeral: true });

  ticket.claimedBy = null;
  ticket.status = 'open';
  await ticket.save();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_claim').setLabel('Claim').setEmoji('✋').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Close').setEmoji('🔒').setStyle(ButtonStyle.Danger),
  );

  await interaction.update({
    embeds: [ticketEmbed('Ticket Unclaimed', 'Ticket is now available to be claimed.')],
    components: [row],
  });
}

async function closeTicket(client, interaction) {
  await interaction.deferReply({ ephemeral: false });

  const ticket = await Ticket.findOne({ channelId: interaction.channelId });
  if (!ticket) return interaction.editReply({ content: 'Not a ticket channel.' });

  // Generate transcript
  let transcriptPath;
  try {
    transcriptPath = await generateTranscript(interaction.channel);
  } catch { transcriptPath = null; }

  // Send transcript to log channel
  const guildDoc = await Guild.findOne({ guildId: interaction.guild.id });
  if (guildDoc?.channels?.ticketLog && transcriptPath) {
    const logCh = interaction.guild.channels.cache.get(guildDoc.channels.ticketLog);
    if (logCh) {
      const { AttachmentBuilder } = require('discord.js');
      const att = new AttachmentBuilder(transcriptPath, { name: `${ticket.ticketId}-transcript.html` });
      await logCh.send({
        embeds: [ticketEmbed('Ticket Closed', `**ID:** ${ticket.ticketId}\n**Closed by:** ${interaction.user.tag}`)],
        files: [att],
      });
    }
  }

  ticket.status = 'closed';
  ticket.closedBy = interaction.user.id;
  ticket.closedAt = new Date();
  await ticket.save();

  await interaction.editReply({ embeds: [successEmbed('Closing Ticket', 'Ticket will be deleted in 5 seconds...')] });
  setTimeout(() => interaction.channel.delete(`Ticket closed by ${interaction.user.tag}`).catch(() => {}), 5000);
}

async function deleteTicket(client, interaction) {
  await interaction.channel.delete(`Forced delete by ${interaction.user.tag}`).catch(() => {});
}

async function handleTicketModal(client, interaction) {
  // Placeholder for future modal-based ticket creation
  logger.info(`[TicketModal] ${interaction.customId} submitted`);
}

module.exports = { handle, handleTicketCreate, handleTicketModal };
