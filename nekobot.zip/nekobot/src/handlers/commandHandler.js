/**
 * Command Handler
 * Loads all slash commands from the commands/ directory recursively
 * and registers them on the Discord.js client.
 */

const { Collection } = require('discord.js');
const fs   = require('fs');
const path = require('path');
const logger = require('../utils/logger');

/**
 * Load all commands into client.commands (Collection).
 */
async function loadCommands(client) {
  client.commands = new Collection();
  client.commandArray = [];

  const commandsPath = path.join(__dirname, '..', 'commands');
  const categories = fs.readdirSync(commandsPath);

  let loaded = 0;
  let failed = 0;

  for (const category of categories) {
    const categoryPath = path.join(commandsPath, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;

    const files = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'));

    for (const file of files) {
      const filePath = path.join(categoryPath, file);
      try {
        // Clear require cache to allow hot-reloading
        delete require.cache[require.resolve(filePath)];
        const command = require(filePath);

        if (!command?.data || !command?.execute) {
          logger.warn(`[CommandHandler] Skipping ${file} — missing data or execute`);
          continue;
        }

        command.category = category;
        client.commands.set(command.data.name, command);
        client.commandArray.push(command.data.toJSON());
        loaded++;
      } catch (err) {
        logger.error(`[CommandHandler] Failed to load ${file}: ${err.message}`);
        failed++;
      }
    }
  }

  logger.info(`[CommandHandler] Loaded ${loaded} commands (${failed} failed) across ${categories.length} categories`);
}

/**
 * Reload a single command by name.
 */
async function reloadCommand(client, commandName) {
  const commandsPath = path.join(__dirname, '..', 'commands');
  const categories = fs.readdirSync(commandsPath);

  for (const category of categories) {
    const categoryPath = path.join(commandsPath, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;

    const file = fs.readdirSync(categoryPath).find(
      f => f === `${commandName}.js` || f.replace('.js', '') === commandName
    );
    if (!file) continue;

    const filePath = path.join(categoryPath, file);
    delete require.cache[require.resolve(filePath)];
    const command = require(filePath);

    if (!command?.data || !command?.execute) {
      throw new Error(`Command ${commandName} is missing data or execute`);
    }

    command.category = category;
    client.commands.set(command.data.name, command);
    return command.data.name;
  }

  throw new Error(`Command "${commandName}" not found`);
}

module.exports = { loadCommands, reloadCommand };
