/**
 * Event Handler
 * Loads all event files from events/ and registers them on the client.
 */

const fs   = require('fs');
const path = require('path');
const logger = require('../utils/logger');

async function loadEvents(client) {
  const eventsPath = path.join(__dirname, '..', 'events');
  const files = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'));

  let loaded = 0;

  for (const file of files) {
    const filePath = path.join(eventsPath, file);
    try {
      delete require.cache[require.resolve(filePath)];
      const event = require(filePath);

      if (!event?.name || !event?.execute) {
        logger.warn(`[EventHandler] Skipping ${file} — missing name or execute`);
        continue;
      }

      // Remove existing listeners to prevent duplicates on reload
      client.removeAllListeners(event.name);

      if (event.once) {
        client.once(event.name, (...args) => event.execute(client, ...args));
      } else {
        client.on(event.name, (...args) => event.execute(client, ...args));
      }

      loaded++;
    } catch (err) {
      logger.error(`[EventHandler] Failed to load ${file}: ${err.message}`);
    }
  }

  logger.info(`[EventHandler] Loaded ${loaded} events`);
}

/**
 * Reload all events (removes all existing listeners and reloads).
 */
async function reloadEvents(client) {
  client.removeAllListeners();
  await loadEvents(client);
}

module.exports = { loadEvents, reloadEvents };
