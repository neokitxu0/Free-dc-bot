/**
 * Modal Interaction Handler
 */

const logger = require('../utils/logger');
const { errorEmbed } = require('../utils/embed');

async function handleModal(client, interaction) {
  if (!interaction.isModalSubmit()) return;

  const [prefix] = interaction.customId.split('_');

  try {
    switch (prefix) {
      case 'ticket': {
        const { handleTicketModal } = require('./buttons/ticketButtons');
        await handleTicketModal(client, interaction);
        break;
      }
      case 'suggest': {
        // Suggestion submission
        const { handleSuggestModal } = require('../commands/utility/suggest');
        await handleSuggestModal(client, interaction);
        break;
      }
      default:
        logger.warn(`[ModalHandler] No handler for: ${interaction.customId}`);
    }
  } catch (err) {
    logger.error(`[ModalHandler] Error in ${interaction.customId}: ${err.message}`);
    const reply = { embeds: [errorEmbed('Error', 'Something went wrong processing this form.')], ephemeral: true };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(reply).catch(() => {});
    } else {
      await interaction.reply(reply).catch(() => {});
    }
  }
}

module.exports = { handleModal };
