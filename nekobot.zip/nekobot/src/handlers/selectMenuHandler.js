/**
 * Select Menu Interaction Handler
 */

const logger = require('../utils/logger');
const { errorEmbed } = require('../utils/embed');

async function handleSelectMenu(client, interaction) {
  if (!interaction.isAnySelectMenu()) return;

  const [prefix] = interaction.customId.split('_');

  try {
    switch (prefix) {
      case 'ticket': {
        // Ticket category selection
        const { handleTicketCreate } = require('./buttons/ticketButtons');
        await handleTicketCreate(client, interaction);
        break;
      }
      case 'shop': {
        // Economy shop item selection
        const { handleShopSelect } = require('../commands/economy/shop');
        await handleShopSelect(client, interaction);
        break;
      }
      default:
        logger.warn(`[SelectMenuHandler] No handler for: ${interaction.customId}`);
    }
  } catch (err) {
    logger.error(`[SelectMenuHandler] Error in ${interaction.customId}: ${err.message}`);
    const reply = { embeds: [errorEmbed('Error', 'Something went wrong.')], ephemeral: true };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(reply).catch(() => {});
    } else {
      await interaction.reply(reply).catch(() => {});
    }
  }
}

module.exports = { handleSelectMenu };
