/**
 * NekoBot — Main Entry Point
 * Initializes the Discord client, connects to MongoDB, loads all handlers,
 * and starts the dashboard API.
 */

require('dotenv').config();

const {
  Client, GatewayIntentBits, Partials, Collection,
} = require('discord.js');
const mongoose = require('mongoose');
const logger   = require('./utils/logger');
const config   = require('../config');

// ─── Create Client ────────────────────────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [
    Partials.Message,
    Partials.Channel,
    Partials.Reaction,
    Partials.User,
    Partials.GuildMember,
  ],
  allowedMentions: { parse: ['users', 'roles'], repliedUser: true },
});

// ─── Attach config to client for convenience ──────────────────────────────────
client.config = config;
client.commands = new Collection();
client.commandArray = [];
client.cooldowns = new Collection();

// ─── MongoDB Connection ────────────────────────────────────────────────────────
async function connectDatabase() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    logger.error('MONGODB_URI is not defined in environment. Please check your .env file.');
    process.exit(1);
  }
  try {
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 10_000,
    });
    logger.info(`[Database] Connected to MongoDB: ${mongoose.connection.host}`);
  } catch (err) {
    logger.error(`[Database] Connection failed: ${err.message}`);
    process.exit(1);
  }
}

// ─── Load All Handlers ────────────────────────────────────────────────────────
async function loadHandlers() {
  const { loadCommands } = require('./handlers/commandHandler');
  const { loadEvents }   = require('./handlers/eventHandler');

  await loadCommands(client);
  await loadEvents(client);

  logger.info('[Handlers] All handlers loaded successfully.');
}

// ─── Start Dashboard API ──────────────────────────────────────────────────────
async function startDashboard() {
  if (!config.dashboard.enabled) return;
  try {
    const dashboard = require('./dashboard');
    dashboard.start(client);
    logger.info(`[Dashboard] API running on port ${config.dashboard.port}`);
  } catch (err) {
    logger.warn(`[Dashboard] Could not start: ${err.message}`);
  }
}

// ─── Setup Music Player ───────────────────────────────────────────────────────
async function setupMusic() {
  try {
    const { Player } = require('discord-player');
    const { DefaultExtractors } = require('@discord-player/extractor');
    const player = new Player(client, {
      ytdlOptions: { quality: 'highestaudio', highWaterMark: 1 << 25 },
    });
    await player.extractors.loadMulti(DefaultExtractors);
    client.player = player;
    logger.info('[Music] Discord player initialized.');
  } catch (err) {
    logger.warn(`[Music] Could not initialize player: ${err.message}`);
  }
}

// ─── Status Rotation ──────────────────────────────────────────────────────────
function startStatusRotation() {
  const activities = config.presence.activities;
  let i = 0;
  setInterval(() => {
    if (!client.user) return;
    const act = activities[i % activities.length];
    client.user.setActivity(act.name, { type: act.type });
    i++;
  }, config.presence.activityRotationInterval);
}

// ─── Global Error Handling ────────────────────────────────────────────────────
process.on('unhandledRejection', (reason) => {
  logger.error(`[UnhandledRejection] ${reason?.stack || reason}`);
});

process.on('uncaughtException', (err) => {
  logger.error(`[UncaughtException] ${err.stack}`);
  process.exit(1);
});

process.on('SIGTERM', () => {
  logger.info('[Process] SIGTERM received. Shutting down gracefully...');
  client.destroy();
  mongoose.connection.close();
  process.exit(0);
});

// ─── Boot Sequence ────────────────────────────────────────────────────────────
(async () => {
  logger.info('═══════════════════════════════════════════');
  logger.info(`  🐱 ${config.botName} is starting up...`);
  logger.info('═══════════════════════════════════════════');

  await connectDatabase();
  await loadHandlers();
  await setupMusic();
  await startDashboard();

  // Login
  const token = process.env.DISCORD_TOKEN;
  if (!token) {
    logger.error('DISCORD_TOKEN is not defined. Aborting.');
    process.exit(1);
  }

  await client.login(token);
  startStatusRotation();
})();

module.exports = client;
