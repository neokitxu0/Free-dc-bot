/**
 * AutoRole Model — Button-role and reaction-role message tracking.
 */
const { Schema, model, models } = require('mongoose');

const autoRoleSchema = new Schema({
  guildId:   { type: String, required: true },
  type:      { type: String, enum: ['button', 'reaction', 'auto'], required: true },
  messageId: { type: String, default: null },
  channelId: { type: String, default: null },
  roles: [{
    roleId:     { type: String },
    label:      { type: String },
    emoji:      { type: String },
    style:      { type: String, default: 'Primary' },
    description:{ type: String },
  }],
  createdAt: { type: Date, default: Date.now },
});

autoRoleSchema.index({ guildId: 1 });

module.exports = models.AutoRole || model('AutoRole', autoRoleSchema);
