/**
 * Blacklist Model — Global user/guild blacklist.
 */
const { Schema, model, models } = require('mongoose');

const blacklistSchema = new Schema({
  id:      { type: String, required: true },
  type:    { type: String, enum: ['user', 'guild'], required: true },
  reason:  { type: String, default: 'No reason provided' },
  by:      { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

blacklistSchema.index({ id: 1, type: 1 }, { unique: true });

module.exports = models.Blacklist || model('Blacklist', blacklistSchema);
