/**
 * Economy Model — Per-user per-guild economy data.
 */
const { Schema, model, models } = require('mongoose');

const economySchema = new Schema({
  userId:  { type: String, required: true },
  guildId: { type: String, required: true },

  // ─── Balance ───────────────────────────────────────────────────────────────
  wallet: { type: Number, default: 0 },
  bank:   { type: Number, default: 0 },
  bankLimit: { type: Number, default: 10_000 },

  // ─── Stats ─────────────────────────────────────────────────────────────────
  totalEarned: { type: Number, default: 0 },
  totalSpent:  { type: Number, default: 0 },

  // ─── Inventory ─────────────────────────────────────────────────────────────
  inventory: [{
    itemId:    { type: String },
    name:      { type: String },
    quantity:  { type: Number, default: 1 },
    acquiredAt: { type: Date, default: Date.now },
  }],

  // ─── Cooldowns ─────────────────────────────────────────────────────────────
  cooldowns: {
    daily:   { type: Number, default: 0 },
    weekly:  { type: Number, default: 0 },
    monthly: { type: Number, default: 0 },
    work:    { type: Number, default: 0 },
    beg:     { type: Number, default: 0 },
    crime:   { type: Number, default: 0 },
    rob:     { type: Number, default: 0 },
  },

  // ─── Streaks ───────────────────────────────────────────────────────────────
  streaks: {
    daily:   { type: Number, default: 0 },
    weekly:  { type: Number, default: 0 },
    monthly: { type: Number, default: 0 },
  },
}, {
  timestamps: true,
  indexes: [{ unique: true, fields: ['userId', 'guildId'] }],
});

economySchema.index({ userId: 1, guildId: 1 }, { unique: true });

module.exports = models.Economy || model('Economy', economySchema);
