/**
 * Guild Model — Per-guild configuration stored in MongoDB.
 */
const { Schema, model, models } = require('mongoose');

const guildSchema = new Schema({
  guildId: { type: String, required: true, unique: true },
  prefix: { type: String, default: '.' },
  language: { type: String, default: 'en' },

  // ─── Channels ──────────────────────────────────────────────────────────────
  channels: {
    modLog:       { type: String, default: null },
    messageLog:   { type: String, default: null },
    memberLog:    { type: String, default: null },
    voiceLog:     { type: String, default: null },
    roleLog:      { type: String, default: null },
    channelLog:   { type: String, default: null },
    ticketLog:    { type: String, default: null },
    welcomeChannel: { type: String, default: null },
    leaveChannel:   { type: String, default: null },
    aiChannel:      { type: String, default: null },
    ticketCategory: { type: String, default: null },
    levelUpChannel: { type: String, default: null },
  },

  // ─── Roles ─────────────────────────────────────────────────────────────────
  roles: {
    muted:     { type: String, default: null },
    autoRole:  [{ type: String }],
    adminRole: { type: String, default: null },
    modRole:   { type: String, default: null },
    djRole:    { type: String, default: null },
    levelRoles: [{
      level:  { type: Number },
      roleId: { type: String },
    }],
  },

  // ─── Welcome & Leave ───────────────────────────────────────────────────────
  welcome: {
    enabled:   { type: Boolean, default: false },
    message:   { type: String, default: 'Welcome {user} to **{server}**! You are member #{count}.' },
    type:      { type: String, enum: ['text', 'card', 'embed'], default: 'card' },
    background: { type: String, default: null },
    embedColor: { type: String, default: '#9B59B6' },
  },
  leave: {
    enabled:  { type: Boolean, default: false },
    message:  { type: String, default: 'Goodbye **{username}**, we hope to see you again!' },
  },

  // ─── AutoMod ───────────────────────────────────────────────────────────────
  automod: {
    antiSpam:        { type: Boolean, default: false },
    antiLink:        { type: Boolean, default: false },
    antiBadWords:    { type: Boolean, default: false },
    antiRaid:        { type: Boolean, default: false },
    antiMentionSpam: { type: Boolean, default: false },
    antiBot:         { type: Boolean, default: false },
    antiWebhook:     { type: Boolean, default: false },
    badWords:        [{ type: String }],
    linkWhitelist:   [{ type: String }],
    whitelistRoles:  [{ type: String }],
    whitelistUsers:  [{ type: String }],
  },

  // ─── Security ──────────────────────────────────────────────────────────────
  security: {
    antiNuke:          { type: Boolean, default: false },
    antiChannelDelete: { type: Boolean, default: false },
    antiRoleDelete:    { type: Boolean, default: false },
    antiBan:           { type: Boolean, default: false },
    antiKick:          { type: Boolean, default: false },
    whitelist:         [{ type: String }],
  },

  // ─── Tickets ───────────────────────────────────────────────────────────────
  tickets: {
    enabled:        { type: Boolean, default: false },
    panelChannelId: { type: String, default: null },
    panelMessageId: { type: String, default: null },
    counter:        { type: Number, default: 0 },
    staffRoles:     [{ type: String }],
    categories:     [{
      id:          { type: String },
      label:       { type: String },
      emoji:       { type: String },
      description: { type: String },
      categoryId:  { type: String },
    }],
  },

  // ─── Reaction Roles ────────────────────────────────────────────────────────
  reactionRoles: [{
    messageId: { type: String },
    channelId: { type: String },
    emoji:     { type: String },
    roleId:    { type: String },
  }],

  // ─── Button Roles ──────────────────────────────────────────────────────────
  buttonRoles: [{
    messageId: { type: String },
    channelId: { type: String },
    roleId:    { type: String },
    label:     { type: String },
  }],

  // ─── Leveling ──────────────────────────────────────────────────────────────
  leveling: {
    enabled:       { type: Boolean, default: true },
    levelUpMsg:    { type: Boolean, default: true },
    noXpChannels:  [{ type: String }],
    noXpRoles:     [{ type: String }],
  },

  // ─── Logging ───────────────────────────────────────────────────────────────
  logging: {
    messageDelete: { type: Boolean, default: false },
    messageEdit:   { type: Boolean, default: false },
    memberJoin:    { type: Boolean, default: false },
    memberLeave:   { type: Boolean, default: false },
    voiceState:    { type: Boolean, default: false },
    roleChanges:   { type: Boolean, default: false },
    channelChanges:{ type: Boolean, default: false },
    bans:          { type: Boolean, default: false },
  },

  // ─── Maintenance ───────────────────────────────────────────────────────────
  maintenance: { type: Boolean, default: false },

  // ─── Premium ───────────────────────────────────────────────────────────────
  isPremium: { type: Boolean, default: false },
  premiumTier: { type: Number, default: 0 },

  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
}, { timestamps: true });

module.exports = models.Guild || model('Guild', guildSchema);
