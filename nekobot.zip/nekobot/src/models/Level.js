/**
 * Level Model — XP and level data per user per guild.
 */
const { Schema, model, models } = require('mongoose');

const levelSchema = new Schema({
  userId:      { type: String, required: true },
  guildId:     { type: String, required: true },
  xp:          { type: Number, default: 0 },
  level:       { type: Number, default: 0 },
  totalXp:     { type: Number, default: 0 },
  lastMessage: { type: Number, default: 0 }, // timestamp for cooldown
  messages:    { type: Number, default: 0 },
});

levelSchema.index({ guildId: 1, userId: 1 }, { unique: true });
levelSchema.index({ guildId: 1, totalXp: -1 }); // for leaderboard

module.exports = models.Level || model('Level', levelSchema);
