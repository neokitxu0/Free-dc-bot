/**
 * Premium Model — Premium subscription tracking for users and guilds.
 */
const { Schema, model, models } = require('mongoose');

const premiumSchema = new Schema({
  userId:    { type: String, default: null },
  guildId:   { type: String, default: null },
  tier:      { type: Number, default: 1 },
  expiresAt: { type: Number, required: true }, // Unix timestamp ms
  addedBy:   { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

module.exports = models.Premium || model('Premium', premiumSchema);
