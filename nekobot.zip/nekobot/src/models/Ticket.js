/**
 * Ticket Model — Support ticket records.
 */
const { Schema, model, models } = require('mongoose');

const ticketSchema = new Schema({
  ticketId:    { type: String, required: true, unique: true },
  guildId:     { type: String, required: true },
  channelId:   { type: String, required: true },
  userId:      { type: String, required: true },
  category:    { type: String, default: 'general' },
  subject:     { type: String, default: 'Support Ticket' },
  status:      { type: String, enum: ['open', 'claimed', 'closed'], default: 'open' },
  claimedBy:   { type: String, default: null },
  addedUsers:  [{ type: String }],
  closedBy:    { type: String, default: null },
  closedAt:    { type: Date, default: null },
  transcript:  { type: String, default: null }, // URL or path
  createdAt:   { type: Date, default: Date.now },
});

ticketSchema.index({ guildId: 1, userId: 1 });

module.exports = models.Ticket || model('Ticket', ticketSchema);
