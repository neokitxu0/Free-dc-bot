/**
 * User Model — Per-user global data (blacklist, premium, AI memory, etc.)
 */
const { Schema, model, models } = require('mongoose');

const userSchema = new Schema({
  userId:    { type: String, required: true, unique: true },
  username:  { type: String, default: 'Unknown' },
  blacklisted: { type: Boolean, default: false },
  blacklistReason: { type: String, default: null },

  // ─── AI Conversation Memory ────────────────────────────────────────────────
  aiMemory: [{
    role:    { type: String, enum: ['user', 'assistant'] },
    content: { type: String },
    at:      { type: Date, default: Date.now },
  }],

  // ─── Cooldowns ────────────────────────────────────────────────────────────
  cooldowns: {
    type: Map,
    of:   Number,
    default: {},
  },

  // ─── Settings ─────────────────────────────────────────────────────────────
  settings: {
    dmNotifications: { type: Boolean, default: true },
    language:        { type: String, default: 'en' },
  },

  createdAt: { type: Date, default: Date.now },
}, { timestamps: true });

module.exports = models.User || model('User', userSchema);
