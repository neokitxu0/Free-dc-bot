/**
 * Warn Model — Warning records per user per guild.
 */
const { Schema, model, models } = require('mongoose');

const warnSchema = new Schema({
  warnId:      { type: String, required: true, unique: true },
  guildId:     { type: String, required: true },
  userId:      { type: String, required: true },
  moderatorId: { type: String, required: true },
  reason:      { type: String, default: 'No reason provided' },
  active:      { type: Boolean, default: true },
  createdAt:   { type: Date, default: Date.now },
});

warnSchema.index({ guildId: 1, userId: 1 });

module.exports = models.Warn || model('Warn', warnSchema);
