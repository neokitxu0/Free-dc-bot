/**
 * NekoBot Auto Setup Script
 * Guides users through initial configuration and tests the setup.
 */

require('dotenv').config();
const readline = require('readline');
const fs       = require('fs');
const path     = require('path');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise(res => rl.question(q, res));

async function main() {
  console.log('\n╔══════════════════════════════════════════╗');
  console.log('║        🐱 NekoBot Setup Wizard           ║');
  console.log('╚══════════════════════════════════════════╝\n');

  const env = {};

  env.DISCORD_TOKEN = await ask('📌 Enter your Discord Bot Token: ');
  env.DISCORD_CLIENT_ID = await ask('📌 Enter your Discord Client ID: ');
  env.OWNER_ID = await ask('📌 Enter your Discord User ID (Owner): ');
  env.MONGODB_URI = await ask('📌 Enter your MongoDB URI (or press Enter for localhost): ')
    || 'mongodb://localhost:27017/nekobot';

  const wantAI = await ask('📌 Enable AI features? (yes/no): ');
  if (wantAI.toLowerCase().startsWith('y')) {
    env.OPENAI_API_KEY = await ask('📌 Enter your OpenAI API Key: ');
  }

  const wantSpotify = await ask('📌 Enable Spotify music support? (yes/no): ');
  if (wantSpotify.toLowerCase().startsWith('y')) {
    env.SPOTIFY_CLIENT_ID = await ask('📌 Enter your Spotify Client ID: ');
    env.SPOTIFY_CLIENT_SECRET = await ask('📌 Enter your Spotify Client Secret: ');
  }

  const wantWeather = await ask('📌 Enable Weather command? (yes/no): ');
  if (wantWeather.toLowerCase().startsWith('y')) {
    env.OPENWEATHER_API_KEY = await ask('📌 Enter your OpenWeatherMap API Key: ');
  }

  env.JWT_SECRET = randomString(32);
  env.DASHBOARD_SECRET = randomString(32);

  // Write .env
  const envContent = Object.entries(env)
    .map(([k, v]) => `${k}=${v}`)
    .join('\n');
  fs.writeFileSync(path.join(process.cwd(), '.env'), envContent, 'utf8');

  console.log('\n✅ .env file written successfully!');

  // Test MongoDB connection
  console.log('\n🔄 Testing MongoDB connection...');
  try {
    const mongoose = require('mongoose');
    await mongoose.connect(env.MONGODB_URI, { serverSelectionTimeoutMS: 5000 });
    console.log('✅ MongoDB connection successful!');
    await mongoose.connection.close();
  } catch (err) {
    console.log(`⚠️  MongoDB connection failed: ${err.message}`);
    console.log('   Please check your MONGODB_URI and ensure MongoDB is running.');
  }

  console.log('\n📋 Next steps:');
  console.log('  1. Run: npm install');
  console.log('  2. Deploy commands: node src/deploy-commands.js');
  console.log('  3. Start the bot: npm start');
  console.log('\n🐱 Setup complete! Enjoy NekoBot!\n');

  rl.close();
}

function randomString(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
}

main().catch(err => { console.error(err); process.exit(1); });
