/**
 * NekoBot Anti-Spam System
 * Tracks user message rates per guild and issues punishments.
 */

const config = require('../../config');
const { modEmbed } = require('./embed');
const ms = require('ms');

// In-memory spam tracker: Map<guildId, Map<userId, { count, timer, warned }>>
const spamTracker = new Map();

// In-memory raid tracker: Map<guildId, { joins: [], timer }>
const raidTracker = new Map();

// In-memory link/badword/mention violators: Map<guildId+userId, violations>
const violationTracker = new Map();

/**
 * Check and handle anti-spam for a message.
 * Returns true if spam was detected.
 */
async function checkAntiSpam(message) {
  if (!message.guild || message.author.bot) return false;

  const cfg = config.moderation.antiSpam;
  const guildId = message.guild.id;
  const userId = message.author.id;

  // Load guild settings from DB
  const Guild = require('../models/Guild');
  const guildDoc = await Guild.findOne({ guildId });
  if (!guildDoc?.automod?.antiSpam) return false;

  if (!spamTracker.has(guildId)) spamTracker.set(guildId, new Map());
  const guildTracker = spamTracker.get(guildId);

  if (!guildTracker.has(userId)) {
    guildTracker.set(userId, { count: 0, timer: null });
  }

  const userTrack = guildTracker.get(userId);
  userTrack.count++;

  // Clear counter after interval
  if (userTrack.timer) clearTimeout(userTrack.timer);
  userTrack.timer = setTimeout(() => {
    guildTracker.delete(userId);
  }, cfg.interval);

  if (userTrack.count >= cfg.maxMessages) {
    guildTracker.delete(userId);
    await punishUser(message.guild, message.member, message.channel, 'Anti-Spam', cfg.punishment, cfg.muteDuration);
    return true;
  }
  return false;
}

/**
 * Check if message contains a link (and should be blocked).
 */
async function checkAntiLink(message) {
  if (!message.guild || message.author.bot) return false;

  const Guild = require('../models/Guild');
  const guildDoc = await Guild.findOne({ guildId: message.guild.id });
  if (!guildDoc?.automod?.antiLink) return false;

  const urlRegex = /(https?:\/\/|discord\.gg\/|discord\.com\/invite\/)\S+/gi;
  if (!urlRegex.test(message.content)) return false;

  // Check whitelist
  const whitelist = guildDoc.automod.linkWhitelist || [];
  const matched = message.content.match(urlRegex);
  for (const url of matched) {
    if (whitelist.some(w => url.includes(w))) return false;
  }

  await message.delete().catch(() => {});
  const reply = await message.channel.send({ content: `${message.author}, links are not allowed in this server!` });
  setTimeout(() => reply.delete().catch(() => {}), 5000);
  return true;
}

/**
 * Check if message contains bad words.
 */
async function checkAntiBadWords(message) {
  if (!message.guild || message.author.bot) return false;

  const Guild = require('../models/Guild');
  const guildDoc = await Guild.findOne({ guildId: message.guild.id });
  if (!guildDoc?.automod?.antiBadWords) return false;

  const wordList = guildDoc.automod.badWords?.length
    ? guildDoc.automod.badWords
    : config.moderation.antiBadWords.defaultWords;

  const lowerContent = message.content.toLowerCase();
  const hasBadWord = wordList.some(w => lowerContent.includes(w.toLowerCase()));
  if (!hasBadWord) return false;

  await message.delete().catch(() => {});
  const reply = await message.channel.send({ content: `${message.author}, that word is not allowed here!` });
  setTimeout(() => reply.delete().catch(() => {}), 5000);
  return true;
}

/**
 * Check for mention spam.
 */
async function checkAntiMentionSpam(message) {
  if (!message.guild || message.author.bot) return false;

  const Guild = require('../models/Guild');
  const guildDoc = await Guild.findOne({ guildId: message.guild.id });
  if (!guildDoc?.automod?.antiMentionSpam) return false;

  const cfg = config.moderation.antiMentionSpam;
  const mentionCount = message.mentions.users.size + message.mentions.roles.size;
  if (mentionCount < cfg.maxMentions) return false;

  await punishUser(message.guild, message.member, message.channel, 'Anti-Mention Spam', 'mute', cfg.muteDuration);
  return true;
}

/**
 * Check for anti-raid (rapid join detection).
 */
async function checkAntiRaid(guild, member) {
  const Guild = require('../models/Guild');
  const guildDoc = await Guild.findOne({ guildId: guild.id });
  if (!guildDoc?.automod?.antiRaid) return false;

  const cfg = config.moderation.antiRaid;
  const guildId = guild.id;

  if (!raidTracker.has(guildId)) raidTracker.set(guildId, { joins: [], timer: null });
  const tracker = raidTracker.get(guildId);

  const now = Date.now();
  tracker.joins.push(now);
  tracker.joins = tracker.joins.filter(t => now - t < cfg.joinInterval);

  if (tracker.joins.length >= cfg.joinThreshold) {
    // Raid detected — kick/ban recent joiners
    const recent = guild.members.cache.filter(m =>
      tracker.joins.includes(m.joinedTimestamp) || now - m.joinedTimestamp < cfg.joinInterval
    );
    for (const [, m] of recent) {
      if (cfg.punishment === 'ban') await m.ban({ reason: 'Anti-Raid: Raid detected' }).catch(() => {});
      else await m.kick('Anti-Raid: Raid detected').catch(() => {});
    }
    tracker.joins = [];

    // Send alert to mod-log channel
    await sendModLog(guild, {
      action: '🚨 Raid Detected',
      description: `Kicked ${recent.size} members during suspected raid.`,
      color: 0xFF0000,
    });
    return true;
  }
  return false;
}

/**
 * Apply a moderation punishment.
 */
async function punishUser(guild, member, channel, reason, punishment, duration) {
  try {
    switch (punishment) {
      case 'mute':
      case 'timeout':
        await member.timeout(duration, reason);
        break;
      case 'kick':
        await member.kick(reason);
        break;
      case 'ban':
        await member.ban({ reason, deleteMessageSeconds: 60 });
        break;
      case 'delete':
      default:
        break;
    }
    // Notify
    const reply = await channel.send({
      content: `⚠️ **${member.user.tag}** has been **${punishment}d** for: ${reason}`,
    });
    setTimeout(() => reply.delete().catch(() => {}), 8000);

    // Log
    await sendModLog(guild, {
      action: `AutoMod: ${reason}`,
      target: member.user,
      punishment,
    });
  } catch { /* member may have left */ }
}

/**
 * Send an entry to the guild's mod-log channel.
 */
async function sendModLog(guild, { action, target, description, punishment, color }) {
  const Guild = require('../models/Guild');
  const guildDoc = await Guild.findOne({ guildId: guild.id });
  if (!guildDoc?.channels?.modLog) return;

  const ch = guild.channels.cache.get(guildDoc.channels.modLog);
  if (!ch) return;

  const { EmbedBuilder } = require('discord.js');
  const embed = new EmbedBuilder()
    .setColor(color || 0xE74C3C)
    .setTitle(`🛡️ ${action}`)
    .setTimestamp();

  if (target) embed.addFields({ name: 'User', value: `${target.tag} (${target.id})` });
  if (punishment) embed.addFields({ name: 'Punishment', value: punishment });
  if (description) embed.setDescription(description);

  await ch.send({ embeds: [embed] }).catch(() => {});
}

module.exports = {
  checkAntiSpam, checkAntiLink, checkAntiBadWords,
  checkAntiMentionSpam, checkAntiRaid, sendModLog,
};
