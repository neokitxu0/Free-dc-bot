/**
 * Economy Utilities
 * Helpers for balance operations, cooldown checks, and reward calculations.
 */

const Economy = require('../models/Economy');
const config = require('../../config');

/**
 * Get or create economy doc for a user in a guild.
 */
async function getEconomy(userId, guildId) {
  let doc = await Economy.findOne({ userId, guildId });
  if (!doc) {
    doc = await Economy.create({ userId, guildId });
  }
  return doc;
}

/**
 * Add coins to a user's wallet.
 */
async function addCoins(userId, guildId, amount) {
  const doc = await getEconomy(userId, guildId);
  doc.wallet += amount;
  doc.totalEarned += amount;
  await doc.save();
  return doc;
}

/**
 * Remove coins from a user's wallet.
 * Returns false if insufficient funds.
 */
async function removeCoins(userId, guildId, amount) {
  const doc = await getEconomy(userId, guildId);
  if (doc.wallet < amount) return false;
  doc.wallet -= amount;
  doc.totalSpent += amount;
  await doc.save();
  return doc;
}

/**
 * Transfer coins between two users.
 */
async function transferCoins(fromId, toId, guildId, amount) {
  const removed = await removeCoins(fromId, guildId, amount);
  if (!removed) return false;
  await addCoins(toId, guildId, amount);
  return true;
}

/**
 * Check if a cooldown has expired.
 * Returns ms remaining (0 if ready).
 */
function checkCooldown(doc, type) {
  const last = doc.cooldowns[type] || 0;
  const cooldowns = {
    daily:   86_400_000,
    weekly:  604_800_000,
    monthly: 2_592_000_000,
    work:    config.economy.work.cooldown * 1000,
    beg:     config.economy.beg.cooldown * 1000,
    crime:   config.economy.crime.cooldown * 1000,
    rob:     config.economy.rob.cooldown * 1000,
  };
  const cd = cooldowns[type] || 0;
  const remaining = cd - (Date.now() - last);
  return remaining > 0 ? remaining : 0;
}

/**
 * Set cooldown timestamp.
 */
async function setCooldown(userId, guildId, type) {
  await Economy.findOneAndUpdate(
    { userId, guildId },
    { $set: { [`cooldowns.${type}`]: Date.now() } },
    { upsert: true }
  );
}

/**
 * Format duration from ms to human-readable.
 */
function formatDuration(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  if (d > 0) return `${d}d ${h % 24}h ${m % 60}m`;
  if (h > 0) return `${h}h ${m % 60}m ${s % 60}s`;
  if (m > 0) return `${m}m ${s % 60}s`;
  return `${s}s`;
}

/**
 * Get top N users for a guild leaderboard.
 */
async function getLeaderboard(guildId, limit = 10) {
  return Economy.find({ guildId })
    .sort({ wallet: -1 })
    .limit(limit)
    .lean();
}

/**
 * Deposit to bank.
 */
async function deposit(userId, guildId, amount) {
  const doc = await getEconomy(userId, guildId);
  const space = doc.bankLimit - doc.bank;
  const actual = Math.min(amount, space, doc.wallet);
  if (actual <= 0) return { success: false, reason: 'No space or funds' };
  doc.wallet -= actual;
  doc.bank += actual;
  await doc.save();
  return { success: true, amount: actual, doc };
}

/**
 * Withdraw from bank.
 */
async function withdraw(userId, guildId, amount) {
  const doc = await getEconomy(userId, guildId);
  const actual = Math.min(amount, doc.bank);
  if (actual <= 0) return { success: false, reason: 'No funds in bank' };
  doc.bank -= actual;
  doc.wallet += actual;
  await doc.save();
  return { success: true, amount: actual, doc };
}

/**
 * Random int between min and max (inclusive).
 */
function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

module.exports = {
  getEconomy, addCoins, removeCoins, transferCoins,
  checkCooldown, setCooldown, formatDuration,
  getLeaderboard, deposit, withdraw, randInt,
};
