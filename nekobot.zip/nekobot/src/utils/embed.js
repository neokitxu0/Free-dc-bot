/**
 * NekoBot Embed Utilities
 * Consistent, themed embed builders for all bot responses.
 */

const { EmbedBuilder } = require('discord.js');
const config = require('../../config');

/**
 * Create a base embed with bot branding.
 * @param {string} color - Key from config.colors
 */
function baseEmbed(color = 'primary') {
  return new EmbedBuilder()
    .setColor(config.colors[color] ?? config.colors.primary)
    .setTimestamp()
    .setFooter({ text: config.botName });
}

/** ✅ Success embed */
function successEmbed(title, description, fields = []) {
  const embed = baseEmbed('success')
    .setTitle(`${config.emojis.success} ${title}`)
    .setDescription(description);
  if (fields.length) embed.addFields(fields);
  return embed;
}

/** ❌ Error embed */
function errorEmbed(title, description) {
  return baseEmbed('error')
    .setTitle(`${config.emojis.error} ${title}`)
    .setDescription(description);
}

/** ⚠️ Warning embed */
function warningEmbed(title, description) {
  return baseEmbed('warning')
    .setTitle(`${config.emojis.warning} ${title}`)
    .setDescription(description);
}

/** ℹ️ Info embed */
function infoEmbed(title, description, fields = []) {
  const embed = baseEmbed('info')
    .setTitle(`${config.emojis.info} ${title}`)
    .setDescription(description);
  if (fields.length) embed.addFields(fields);
  return embed;
}

/** 🛡️ Moderation embed */
function modEmbed({ action, target, moderator, reason, duration, guildIcon } = {}) {
  const embed = baseEmbed('moderation')
    .setTitle(`${config.emojis.shield} ${action}`)
    .addFields(
      { name: 'Target', value: target ? `${target.tag} (${target.id})` : 'Unknown', inline: true },
      { name: 'Moderator', value: moderator ? `${moderator.tag}` : 'Unknown', inline: true },
      { name: 'Reason', value: reason || 'No reason provided', inline: false },
    );
  if (duration) embed.addFields({ name: 'Duration', value: duration, inline: true });
  if (guildIcon) embed.setThumbnail(guildIcon);
  return embed;
}

/** 💰 Economy embed */
function economyEmbed(title, description, fields = []) {
  const embed = baseEmbed('economy')
    .setTitle(`${config.emojis.coin} ${title}`)
    .setDescription(description);
  if (fields.length) embed.addFields(fields);
  return embed;
}

/** 🎵 Music embed */
function musicEmbed(title, description, fields = []) {
  const embed = baseEmbed('music')
    .setTitle(`${config.emojis.music} ${title}`)
    .setDescription(description);
  if (fields.length) embed.addFields(fields);
  return embed;
}

/** 📊 Level embed */
function levelEmbed(title, description, fields = []) {
  const embed = baseEmbed('level')
    .setTitle(`${config.emojis.chart} ${title}`)
    .setDescription(description);
  if (fields.length) embed.addFields(fields);
  return embed;
}

/** 🎫 Ticket embed */
function ticketEmbed(title, description, fields = []) {
  const embed = baseEmbed('primary')
    .setTitle(`${config.emojis.ticket} ${title}`)
    .setDescription(description);
  if (fields.length) embed.addFields(fields);
  return embed;
}

/** 🤖 AI embed */
function aiEmbed(description) {
  return baseEmbed('primary')
    .setTitle(`${config.emojis.robot} NekoBot AI`)
    .setDescription(description);
}

/** 📊 Logging embed */
function logEmbed(event, fields = []) {
  const embed = baseEmbed('warning')
    .setTitle(`📋 ${event}`)
    .addFields(fields);
  return embed;
}

/** Pagination helpers */
function paginationRow(currentPage, totalPages) {
  const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('page_first')
      .setEmoji('⏮️')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(currentPage === 0),
    new ButtonBuilder()
      .setCustomId('page_prev')
      .setEmoji('◀️')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(currentPage === 0),
    new ButtonBuilder()
      .setCustomId('page_label')
      .setLabel(`${currentPage + 1} / ${totalPages}`)
      .setStyle(ButtonStyle.Primary)
      .setDisabled(true),
    new ButtonBuilder()
      .setCustomId('page_next')
      .setEmoji('▶️')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(currentPage >= totalPages - 1),
    new ButtonBuilder()
      .setCustomId('page_last')
      .setEmoji('⏭️')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(currentPage >= totalPages - 1),
  );
}

module.exports = {
  baseEmbed, successEmbed, errorEmbed, warningEmbed,
  infoEmbed, modEmbed, economyEmbed, musicEmbed,
  levelEmbed, ticketEmbed, aiEmbed, logEmbed, paginationRow,
};
