/**
 * Leveling Utilities
 * XP calculation, level-up detection, rank card generation.
 */

const Level = require('../models/Level');
const config = require('../../config');
const { levelEmbed } = require('./embed');

/**
 * Calculate XP required to reach the NEXT level from current level.
 */
function xpForLevel(level) {
  return config.leveling.xpFormula(level);
}

/**
 * Calculate total XP needed to reach a specific level from 0.
 */
function totalXpForLevel(level) {
  let total = 0;
  for (let i = 0; i < level; i++) total += xpForLevel(i);
  return total;
}

/**
 * Determine what level a given total XP corresponds to.
 */
function getLevelFromXp(totalXp) {
  let level = 0;
  let xp = totalXp;
  while (xp >= xpForLevel(level)) {
    xp -= xpForLevel(level);
    level++;
  }
  return { level, remainingXp: xp };
}

/**
 * Get or create a Level doc.
 */
async function getLevelData(userId, guildId) {
  let doc = await Level.findOne({ userId, guildId });
  if (!doc) doc = await Level.create({ userId, guildId });
  return doc;
}

/**
 * Add XP to a user. Returns { leveled: bool, newLevel, doc } .
 */
async function addXp(userId, guildId, xpGain) {
  const doc = await getLevelData(userId, guildId);

  const now = Date.now();
  const cooldown = config.leveling.xpCooldown;
  if (now - doc.lastMessage < cooldown) return { leveled: false, newLevel: doc.level, doc };

  doc.xp += xpGain;
  doc.totalXp += xpGain;
  doc.messages++;
  doc.lastMessage = now;

  const required = xpForLevel(doc.level);
  let leveled = false;

  if (doc.xp >= required) {
    doc.xp -= required;
    doc.level++;
    leveled = true;
  }

  await doc.save();
  return { leveled, newLevel: doc.level, doc };
}

/**
 * Get server leaderboard.
 */
async function getLevelLeaderboard(guildId, limit = 10) {
  return Level.find({ guildId }).sort({ totalXp: -1 }).limit(limit).lean();
}

/**
 * Handle level-up rewards (role grants).
 */
async function handleLevelRewards(guild, member, newLevel) {
  const Guild = require('../models/Guild');
  const guildDoc = await Guild.findOne({ guildId: guild.id });
  if (!guildDoc?.roles?.levelRoles?.length) return;

  for (const reward of guildDoc.roles.levelRoles) {
    if (reward.level === newLevel) {
      const role = guild.roles.cache.get(reward.roleId);
      if (role) await member.roles.add(role).catch(() => {});
    }
  }
}

/**
 * Generate a text-based rank card (canvas-based rank cards require canvas setup).
 * Returns an embed with level info (fallback if canvas not available).
 */
async function getRankEmbed(member, guildId) {
  const doc = await getLevelData(member.id, guildId);
  const required = xpForLevel(doc.level);
  const percentage = Math.min(100, Math.floor((doc.xp / required) * 100));

  // Rank position
  const allUsers = await Level.find({ guildId }).sort({ totalXp: -1 }).lean();
  const rank = allUsers.findIndex(u => u.userId === member.id) + 1;

  // Progress bar
  const filled = Math.round(percentage / 10);
  const bar = '█'.repeat(filled) + '░'.repeat(10 - filled);

  return levelEmbed(
    `${member.user.username}'s Rank`,
    `**Rank:** #${rank} | **Level:** ${doc.level}\n**XP:** ${doc.xp.toLocaleString()} / ${required.toLocaleString()} XP\n\`[${bar}]\` ${percentage}%`,
    [
      { name: 'Total XP', value: doc.totalXp.toLocaleString(), inline: true },
      { name: 'Messages', value: doc.messages.toLocaleString(), inline: true },
    ]
  ).setThumbnail(member.user.displayAvatarURL({ dynamic: true }));
}

module.exports = {
  xpForLevel, totalXpForLevel, getLevelFromXp,
  getLevelData, addXp, getLevelLeaderboard,
  handleLevelRewards, getRankEmbed,
};
