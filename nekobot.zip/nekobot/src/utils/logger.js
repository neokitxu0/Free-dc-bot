/**
 * NekoBot Logger
 * Winston-based logger with colorized console output and file rotation.
 */

const { createLogger, format, transports } = require('winston');
const { combine, timestamp, printf, colorize, errors } = format;
const path = require('path');
const fs = require('fs');

// Ensure logs directory exists
const logsDir = path.join(process.cwd(), 'logs');
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });

// Custom log format for console
const consoleFormat = printf(({ level, message, timestamp, stack }) => {
  const ts = timestamp.replace('T', ' ').replace(/\..+/, '');
  return `[${ts}] [${level}] ${stack || message}`;
});

// Custom log format for files (no color codes)
const fileFormat = printf(({ level, message, timestamp, stack }) => {
  const ts = timestamp.replace('T', ' ').replace(/\..+/, '');
  return `[${ts}] [${level.toUpperCase()}] ${stack || message}`;
});

const logger = createLogger({
  level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
  format: combine(
    errors({ stack: true }),
    timestamp(),
  ),
  transports: [
    // Console transport with colors
    new transports.Console({
      format: combine(
        colorize({ all: true }),
        timestamp(),
        consoleFormat,
      ),
    }),
    // Combined log file
    new transports.File({
      filename: path.join(logsDir, 'combined.log'),
      format: combine(timestamp(), fileFormat),
      maxsize: 10 * 1024 * 1024, // 10MB
      maxFiles: 5,
      tailable: true,
    }),
    // Error-only log file
    new transports.File({
      filename: path.join(logsDir, 'error.log'),
      level: 'error',
      format: combine(timestamp(), fileFormat),
      maxsize: 10 * 1024 * 1024,
      maxFiles: 5,
      tailable: true,
    }),
  ],
  exitOnError: false,
});

module.exports = logger;
