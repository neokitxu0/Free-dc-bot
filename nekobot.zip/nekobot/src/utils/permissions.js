/**
 * NekoBot Permission Utilities
 * Centralized permission and role checks used across all commands.
 */

const config = require('../../config');

/**
 * Check if a user is a bot owner.
 * @param {string} userId
 */
function isOwner(userId) {
  return config.ownerIds.includes(userId);
}

/**
 * Check if a member has a given Discord permission.
 * @param {GuildMember} member
 * @param {PermissionResolvable} permission
 */
function hasPermission(member, permission) {
  return member.permissions.has(permission);
}

/**
 * Check if the bot has a required permission in a channel.
 * @param {TextChannel} channel
 * @param {PermissionResolvable} permission
 */
function botHasPermission(channel, permission) {
  return channel.permissionsFor(channel.guild.members.me).has(permission);
}

/**
 * Check if user has a role higher than the target member in hierarchy.
 * Returns true if executor can moderate the target.
 */
function canModerate(executor, target) {
  if (executor.guild.ownerId === executor.id) return true;
  if (executor.guild.ownerId === target.id) return false;
  return executor.roles.highest.comparePositionTo(target.roles.highest) > 0;
}

/**
 * Validate a command's required permissions before execution.
 * Returns { allowed: bool, reason: string }
 */
function validateCommandPermissions(interaction, command) {
  const { member, guild } = interaction;

  // Owner-only check
  if (command.ownerOnly && !isOwner(member.id)) {
    return { allowed: false, reason: '👑 This command is restricted to bot owners.' };
  }

  // Guild-only check
  if (command.guildOnly && !guild) {
    return { allowed: false, reason: '🏠 This command can only be used in a server.' };
  }

  // Required user permissions
  if (command.userPermissions?.length) {
    for (const perm of command.userPermissions) {
      if (!hasPermission(member, perm)) {
        return {
          allowed: false,
          reason: `🔒 You need the **${perm}** permission to use this command.`,
        };
      }
    }
  }

  // Required bot permissions
  if (command.botPermissions?.length) {
    for (const perm of command.botPermissions) {
      if (!botHasPermission(interaction.channel, perm)) {
        return {
          allowed: false,
          reason: `🔒 I need the **${perm}** permission to execute this command.`,
        };
      }
    }
  }

  return { allowed: true };
}

/**
 * Check if a user is premium.
 * @param {string} userId
 * @param {Guild} guild
 */
async function isPremium(userId, guild) {
  const Premium = require('../models/Premium');
  const doc = await Premium.findOne({ userId });
  if (doc && doc.expiresAt > Date.now()) return true;
  // Check premium roles
  const member = await guild?.members.fetch(userId).catch(() => null);
  if (!member) return false;
  const premiumRoles = Object.values(config.premium.roles).filter(Boolean);
  return premiumRoles.some(rid => member.roles.cache.has(rid));
}

/**
 * Check if a guild is blacklisted.
 */
async function isBlacklisted(userId) {
  const Blacklist = require('../models/Blacklist');
  const doc = await Blacklist.findOne({ id: userId, type: 'user' });
  return !!doc;
}

module.exports = {
  isOwner, hasPermission, botHasPermission,
  canModerate, validateCommandPermissions, isPremium, isBlacklisted,
};
