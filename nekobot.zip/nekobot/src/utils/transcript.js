/**
 * Ticket Transcript Generator
 * Generates an HTML transcript of a ticket channel.
 */

const fs = require('fs');
const path = require('path');

/**
 * Generate an HTML transcript from a ticket channel's messages.
 * @param {TextChannel} channel
 * @returns {string} filePath
 */
async function generateTranscript(channel) {
  const messages = [];
  let lastId;

  // Fetch all messages (up to 500)
  while (true) {
    const fetched = await channel.messages.fetch({ limit: 100, before: lastId }).catch(() => null);
    if (!fetched || fetched.size === 0) break;
    messages.push(...fetched.values());
    lastId = fetched.last()?.id;
    if (fetched.size < 100) break;
  }

  messages.reverse(); // chronological order

  const rows = messages.map(msg => {
    const time = new Date(msg.createdTimestamp).toLocaleString('en-US', { timeZone: 'UTC' });
    const avatar = msg.author.displayAvatarURL({ format: 'png', size: 32 });
    const content = msg.content
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/`(.*?)`/g, '<code>$1</code>')
      || '<em class="no-content">[embed / attachment]</em>';

    const embeds = msg.embeds.map(e =>
      `<div class="embed" style="border-left:4px solid #${e.color?.toString(16).padStart(6,'0')||'9B59B6'}">
        ${e.title ? `<div class="embed-title">${e.title}</div>` : ''}
        ${e.description ? `<div class="embed-desc">${e.description}</div>` : ''}
      </div>`
    ).join('');

    const attachments = msg.attachments.map(a =>
      a.contentType?.startsWith('image/')
        ? `<img class="attachment" src="${a.url}" alt="attachment" />`
        : `<a href="${a.url}" class="file-link">📎 ${a.name}</a>`
    ).join('');

    return `
      <div class="message">
        <img class="avatar" src="${avatar}" alt="avatar" />
        <div class="content-wrap">
          <div class="meta">
            <span class="username ${msg.author.bot ? 'bot' : ''}">${msg.author.tag}${msg.author.bot ? ' <span class="bot-badge">BOT</span>' : ''}</span>
            <span class="timestamp">${time} UTC</span>
          </div>
          <div class="content">${content}</div>
          ${embeds}${attachments}
        </div>
      </div>`;
  }).join('');

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Transcript — #${channel.name}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', sans-serif; background: #1e1f22; color: #dcddde; padding: 20px; }
  header { background: #2b2d31; padding: 16px 20px; border-radius: 8px; margin-bottom: 24px; }
  header h1 { color: #9B59B6; font-size: 20px; margin-bottom: 4px; }
  header p  { color: #949ba4; font-size: 13px; }
  .message { display: flex; gap: 12px; padding: 8px 12px; border-radius: 4px; margin-bottom: 4px; }
  .message:hover { background: #2b2d31; }
  .avatar { width: 40px; height: 40px; border-radius: 50%; flex-shrink: 0; }
  .content-wrap { flex: 1; }
  .meta { display: flex; align-items: baseline; gap: 8px; margin-bottom: 4px; }
  .username { font-weight: 700; color: #fff; font-size: 15px; }
  .username.bot { color: #5865F2; }
  .bot-badge { background: #5865F2; color: #fff; font-size: 9px; padding: 1px 4px; border-radius: 3px; margin-left: 4px; }
  .timestamp { color: #949ba4; font-size: 12px; }
  .content { color: #dcddde; font-size: 14px; line-height: 1.5; word-break: break-word; }
  .no-content { color: #72767d; }
  code { background: #1e1f22; padding: 2px 4px; border-radius: 3px; font-family: monospace; font-size: 13px; }
  .embed { background: #2b2d31; border-radius: 4px; padding: 8px 12px; margin-top: 6px; }
  .embed-title { font-weight: 700; color: #fff; margin-bottom: 4px; }
  .embed-desc { color: #dcddde; font-size: 14px; }
  .attachment { max-width: 400px; border-radius: 4px; margin-top: 8px; }
  .file-link { color: #00b0f4; text-decoration: none; font-size: 14px; }
</style>
</head>
<body>
<header>
  <h1>📋 Ticket Transcript — #${channel.name}</h1>
  <p>Generated on ${new Date().toUTCString()} &nbsp;|&nbsp; ${messages.length} messages</p>
</header>
${rows}
</body>
</html>`;

  // Save to temp file
  const dir = path.join(process.cwd(), 'transcripts');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  const filePath = path.join(dir, `${channel.id}-${Date.now()}.html`);
  fs.writeFileSync(filePath, html, 'utf8');
  return filePath;
}

module.exports = { generateTranscript };
